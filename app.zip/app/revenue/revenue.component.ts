import { Component, OnInit } from '@angular/core';
import { Chart } from 'angular-highcharts';

import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  template: `
  <div class ="BodyWrapper BookingBox revenue_pg">
  <div class="col-lg-12 col-md-12 col-sm-12 col-12">
    <h4>{{pageData.revenues}}</h4>
  </div>
<div class="col-lg-6 col-md-6 col-sm-6 col-12">
     <ul class="revenue-list">
        <li>
            <h5>{{pageData.week}}</h5>
            <p>{{weekly}}</p>
        </li>
        <li>
            <h5>{{pageData.month}}</h5>
            <p>{{monthly}}</p>
        </li>
        <li>
            <h5>{{pageData.year}}</h5>
            <p>{{yearly}}</p>
        </li>
    </ul>
</div>
<div class="col-lg-6 col-md-6 col-sm-6 col-12">
  <div class="chartcls">
	<div [chart]="chart"></div>
   </div>
</div>
</div>`
})


/*
@Component({
  selector: 'app-revenue',
  templateUrl: './revenue.component.html',
  styleUrls: ['./revenue.component.css']
})*/





export class RevenueComponent implements OnInit {



  public TOKEN: string;
  public user_type:string="driver";
  public config: any;
  public BaseUrl: string;
  public base_url: string;
  public headers: any = {};
  public BASE_URL: string = ''
  public weekly: string = ''
  public yearly: string = ''
  public monthly: string = ''
  error = new Subject<string>();

  public pageData: any = { week: 'Weekly Total', month: 'Monthly Total', year: 'Yearly Total', revenues: 'Revenues' };
  chart = new Chart({});

  public tmpSeries: any = [
    {
      name: 'Weekly',
      data: [1]
    },
    {
      name: 'Monthly',
      data: [2]
    },
    {
      name: 'Yearly',
      data: [3]
    }
  ];

  /*
   // add point to chart serie
   add() {
     this.chart.addPoint(Math.floor(Math.random() * 10));
   }*/
  constructor(public global: Globals, private http: HttpClient, private cookieService: CookieService, private router: Router) {
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;
    console.log(JSON.parse(localStorage.getItem('user')).user_info);
    this.user_type = JSON.parse(localStorage.getItem('user')).user_info;

    this.BaseUrl = this.global.APIURL;
    this.base_url = this.global.APIURL;

    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });
  }

  ngOnInit() {
    
    this.getPageData();
    this.getRevenueInfo();
  }

  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "driver-revenue" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
         
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
         
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;
          
          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
          this.global.setPageData(this.pageData);
          console.log(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }


  getRevenueInfo() {
    
    let api_section = "drivers";
    if(this.user_type == "company")
    {
      api_section = "companies";
    }
    this.http.get(this.BASE_URL + 'api/'+api_section+'/service/getRevenueInfo', {
      headers: this.headers
    }).
      subscribe(
        response => {
        
          let tmpResponse: any = response;
           tmpResponse = tmpResponse.data;
          
          this.yearly = tmpResponse[0];
          this.monthly = tmpResponse[1];
          this.weekly = tmpResponse[2];
          var d = new Date();
          var n = d.getFullYear();
          this.tmpSeries = [
            {
              name: 'Weekly',
              data: [parseFloat(this.weekly)]
            },
            {
              name: 'Monthly',
              data: [parseFloat(this.monthly)]
            },
            {
              name: 'Yearly',
              data: [parseFloat(this.yearly)]
            }
          ];

          this.chart = new Chart({
            chart: { type: 'column' },
            title: { text: this.user_type+' revenue ' + n.toString() },
            credits: { enabled: true },
            yAxis: { min: 0, title: { text: 'Earnings' } },
            series: this.tmpSeries,
            tooltip: {
              headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
              pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
              footerFormat: '</table>',
              shared: true,
              useHTML: true
            },
            plotOptions: {
              column: {
                pointPadding: 0.2,
                borderWidth: 0
              }
            },
          });

         

        },
        error => {
          if(error.error.error == "Token Expired")
          {
            this.router.navigate(['logout']);
          }
          return false;
        });

  };



}
