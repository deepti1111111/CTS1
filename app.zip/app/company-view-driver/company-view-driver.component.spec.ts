import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyViewDriverComponent } from './company-view-driver.component';

describe('CompanyViewDriverComponent', () => {
  let component: CompanyViewDriverComponent;
  let fixture: ComponentFixture<CompanyViewDriverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanyViewDriverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyViewDriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
