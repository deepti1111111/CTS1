import { Component, OnInit, ViewChild, ElementRef, OnDestroy, Directive, Input } from '@angular/core';
import { Globals } from '../global';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject, Observable, throwError, VirtualTimeScheduler } from 'rxjs';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

import { CookieService } from 'ngx-cookie-service';
import * as moment from 'moment';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';

import { NotifierService } from "angular-notifier";

import { Chart } from 'angular-highcharts';
import { error } from 'protractor';
declare var $: any;

@Component({
  selector: 'app-company-view-driver',
  templateUrl: './company-view-driver.component.html',
  styleUrls: ['./company-view-driver.component.css']
})
export class CompanyViewDriverComponent implements OnInit {

  public TOKEN: string = "";
  
  error = new Subject<string>();
  public p:number  = 1;
  public config: any;
  public BaseUrl: string;
  public subscribed: boolean = false;
  public headers: any = {};
  public is_edit: boolean = false;
  public BASE_URL: string = '';
  public subsciptionStatusmessage: string;
  public country: string;
  public user = { email: "", password: "", fcm_key: "pwa" };
  public pageDriverRegData = { autonom_mode: "Autonom", back_button: "Back", business_conection_type: "Business Connection (Rental Car Driver, Counter/Service Provider)", business_connection: "Business Connection (selfemployeed - Rental Car Driver, Counter/Service Provider)", city: "City / Municipality", combustion: "Combustion", country: "Country", date_of_change: "Date of Change", date_of_create: "Date of Create", dialing_code: "Dialing Code", driver_company: "Driver - Company", driver_company_busness_lic: "Driver Company - Business License", driver_company_vat: "Driver Company - VAT, tax number", driver_emp_no: "Driver Employee Number", driver_mode: "Driver", driver_number: "Driver Number ( Automatic Generated)", driver_taxi_lic_no: "Driver - Taxi License No.", driving_mode: "Driving Mode", email: "Driver-Email", email_verification_link: "Email Verification Link", first_name: "Driver Given Name", floor: "Address Driver -Floor", form_title: "Licensed Company Driver Registration", fullemp: "Full Electric", further_information: "Address Driver - Further Information", house: "Address Driver - House / Apartment No.", hybrid: "Hybrid", id_card: "Driver ID Card Number", id_verification_text: "Upload An IDUnlock Account (Fingerprint / gestures / Private Information)", last_name: "Driver Family Name", license_plate: "Driver Car - License Plate", location_of_change: "Location of Change", location_of_create: "Location of Create", make_type: "Vehicle Brand Type", manpower: "Man Power", mobile_number: "Driver-Mobile Number", mobile_verification_code: "Mobile Verification Code", nationality: "Nationality", password: "Password", password_repeat: "Password-Repeat", payment_methods: "Select Payment Methods", powertrain: "Powertrain", social_ins_num: "Driver Social Insurance Number", state: "Province / Federal State", street_name: "Driver Address - Street Name ", street_number: "Street Number", submit_button: "Submit", take_a_picture: "Take A Picture", take_an_id: "Take An ID", time_of_change: "Time of Change", time_of_create: "Time of Create", upload_a_picture: "Upload A Picture", upload_an_id: "Upload An ID", upload_picture: "Upload Picture", username: "Username", vehicle_make: "Vehicle Make", vehicle_type: "Vehicle Type", verification: "Verification", zip: "ZIP" };
  public content_ride: any = { rides: 'Rides', search_btn: 'Search', search_placeholder: 'Seach', ride_list: 'List Of Rides', start_date: 'Start Date', end_date: 'End Date', show_item: 'Show Item', select_all: 'Select All', sno: 'Sr. No', pick_up: 'Pickup Location', drop: 'Drop Location', date: 'Date', fare: 'Fare', driver_name: 'Driver Name', car_no: 'Car Number', action: 'Action', ride_detial: 'Ride Detail', drivername: "Driver's Name", customername: "Customer's Name", pickup: 'Pick-up Location', vehicletype: 'Vehicle Type', series: 'Series', tip: 'Offered Tip', datetime: 'Booking Date & Time', feedback: 'Feedbacks', rating: 'Rating' };
  public content_revenue: any = { week: 'Weekly Total', month: 'Monthly Total', year: 'Yearly Total', revenues: 'Revenues' };
  public businessConnection: any;
  public response: any;
  public tmp: any;
  public countryList: any;
  public driver_id: string = "";
  public message: string;
  public mobileOTP: string = "";
  public user_id: string = "";
  public divTarget1:boolean = false;
  public divTarget2:boolean = false;
  public divTarget3:boolean = false;
  public vehicleTypeList: any;
  public vehicleMakeList: any;
  public vehicleModelList: any;
  public vehicleModelListAll: any;
  public isNew: boolean = true;
  public password_err: string = "";
  public password_err1: string = "";
  public business_connection_list: any = [];
  public yearly: string = "";
  public monthly: string = "";
  public weekly: string = "";
  public msg:string="";
  public mobile_verification_code: string = "";
  public fileToUpload: File = null;
  public tmpSeries: any = [
    {
      name: 'Weekly',
      data: [1]
    },
    {
      name: 'Monthly',
      data: [2]
    },
    {
      name: 'Yearly',
      data: [3]
    }
  ];
  //========== Chart ============//
  chart = new Chart({});

  public general = {
    id: '',
    image: 'face-image.png',
    id_proof_image: 'identity-image.png',
    business_connection_type: '8',
    driver_number: '',
    first_name: '',
    last_name: '',
    username: '',
    id_card: '',
    password: '',
    password_repeat: '',
    country: 'CN China',
    state: '',
    city: '',
    zip: '',
    street_number: '',
    street_name: '',
    house: '',
    floor: '',
    further_information: '',
    email: '',
    dialing_code: '',
    mobile_number: '',
    driver_taxi_lic_no: '',
    driver_emp_no: '',
    social_ins_num: '',
    email_verification_link: true,
    mobile_verification_code: true,
    is_mobile_verified: true,
    date_of_create: '',
    time_of_create: '',
    location_of_create: '',
    date_of_change: '',
    time_of_change: '',
    location_of_change: '',
    role: 'driver',
    company_id: "",
    driver_company: '',
    driver_company_busness_lic: '',
    driver_company_vat: '', vehicle_type: '1', vehicle_make: '1', make_type: '', powertrain: 'Combustion', driving_mode: 'Driver',
    payment_methods: false
  };
  public general_rides: any = {
    id: false,
    customer_id: '',
    driver_id: '',
    company_id: '',
    vehicle_id: '',
    pick_up: '',
    drop_to: '',
    latitude: '',
    longitude: '',
    distance: '',
    tip: '',
    total_amount: '',
    pay_status: '',
    booking_datetime: '',
    feedback: '',
    rating: ''

  };
  public general_booking: any = [];
  public business_connection_type_list: any = [];
  public mcities: any = [];
  disabled = false;
  showFilter = false;
  limitSelection = false;
  selectedItems: any = [];
  dropDownSettings: any = {};
  constructor(public global: Globals, private activeroute: ActivatedRoute, private modalService: BsModalService, private http: HttpClient, private cookieService: CookieService, private router: Router, notifierService: NotifierService) {
    this.divTarget1 = true;
    this.divTarget2 = false;
    this.divTarget3 = false;
    
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;
    this.user_id = JSON.parse(localStorage.getItem('user')).user_ID;
    this.driver_id = this.activeroute.snapshot.paramMap.get('user_id');

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });
    this.getCountry();
    if (this.driver_id) {
      this.isNew = false;
      this.getDriverManagementInfo();
    }
  }
  ngOnInit() {
    
    this.getCountry();
    this.getDriverRegPageData();
    this.getRevenuePageConetnt();
    this.getBookingPageConetnt();

    this.getBusinessConnection();
    this.getRevenueInfo();
    this.getDriverBookingInfo();
    

  }

  getDriverRegPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "Licensed Company Employee Driver Registration" }
    )
      .subscribe(
        responseData => {

          this.tmp = responseData;
          var cookie = JSON.parse(this.cookieService.get('language_code'));
          this.global.country = cookie.language;

          if (this.global.country == 'en') {
            this.pageDriverRegData = this.tmp.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageDriverRegData = this.tmp.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageDriverRegData = this.tmp.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageDriverRegData = this.tmp.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageDriverRegData = this.tmp.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageDriverRegData = this.tmp.data.content_es;
          }

        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getRevenuePageConetnt() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "driver-revenue" }
    )
      .subscribe(
        responseData => {

          this.tmp = responseData;
          var cookie = JSON.parse(this.cookieService.get('language_code'));
          this.global.country = cookie.language;

          if (this.global.country == 'en') {
            this.content_revenue = this.tmp.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.content_revenue = this.tmp.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.content_revenue = this.tmp.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.content_revenue = this.tmp.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.content_revenue = this.tmp.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.content_revenue = this.tmp.data.content_es;
          }

        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getBookingPageConetnt() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "company-ride" }
    )
      .subscribe(
        responseData => {

          this.tmp = responseData;
          var cookie = JSON.parse(this.cookieService.get('language_code'));
          this.global.country = cookie.language;

          if (this.global.country == 'en') {
            this.content_ride = this.tmp.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.content_ride = this.tmp.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.content_ride = this.tmp.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.content_ride = this.tmp.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.content_ride = this.tmp.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.content_ride = this.tmp.data.content_es;
          }

        },
        error => {
          this.error.next(error.message);
        }
      );
  }


  //Licensed Company Employee Driver Registration
  getCountry() {
    this.http.get(this.global.APIURL + "api/general/languageList").subscribe(
      responseData => {
        this.global.setCountryList(responseData);
        this.countryList = responseData;
        this.countryList = this.countryList.data;

      },
      error => {
        this.error.next(error.message);
      }
    );

  }

  getDriverManagementInfo() {
    let formadata: any = { ID: this.driver_id };
    console.log(this.BASE_URL + 'api/companies/service/getDriver');
    this.http.post(this.BASE_URL + 'api/companies/service/getDriver', formadata, {
      headers: this.headers
    }).subscribe(
      response => {
        let tmpResponse: any = response;
        this.general = tmpResponse.data;
        console.log(this.general);
      }, error => {
        return false;
      });
  };

  getBusinessConnection() {
    var formdata = { connection_for: 'company_driver' };
    this.http.post(this.BASE_URL + 'api/general/businessConnection', formdata, {})
      .subscribe(response => {
        let tmpResponse: any = response;
        return false;

      }, error => {

        return false;

      });



  };

  getRevenueInfo() {
    this.user_id = "7ec53d8c33f790145a875579735ae8bf_XwPplMNBVCX4ZAQ4Z4d4XwPplMXwPplMX-X000000PQZbnhj-wPplM8S4HkAeT_" + this.driver_id + "_APIh7ec53d8c33f790145a875579735ae8bfi";
    this.http.post(this.BASE_URL + 'api/companies/service/getDriverRevenueInfo', 
    { ID: this.user_id }, {
      headers: this.headers
    }).subscribe(response => {


        
      let tmpResponse: any = response;
      tmpResponse = tmpResponse.data;
     
     this.yearly = tmpResponse[0];
     this.monthly = tmpResponse[1];
     this.weekly = tmpResponse[2];
     var d = new Date();
     var n = d.getFullYear();
     this.tmpSeries = [
       {
         name: 'Weekly',
         data: [parseFloat(this.weekly)]
       },
       {
         name: 'Monthly',
         data: [parseFloat(this.monthly)]
       },
       {
         name: 'Yearly',
         data: [parseFloat(this.yearly)]
       }
     ];

     this.chart = new Chart({
       chart: { type: 'column' },
       title: { text: 'Driver revenue ' + n.toString() },
       credits: { enabled: true },
       yAxis: { min: 0, title: { text: 'Earnings' } },
       series: this.tmpSeries,
       tooltip: {
         headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
         pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
           '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
         footerFormat: '</table>',
         shared: true,
         useHTML: true
       },
       plotOptions: {
         column: {
           pointPadding: 0.2,
           borderWidth: 0
         }
       },
     });



      console.log(response);
    }, error => {
      return false;
    });
  };


  getDriverBookingInfo() {
    this.user_id = "7ec53d8c33f790145a875579735ae8bf_XwPplMNBVCX4ZAQ4Z4d4XwPplMXwPplMX-X000000PQZbnhj-wPplM8S4HkAeT_" + this.driver_id + "_APIh7ec53d8c33f790145a875579735ae8bfi";

    this.http.post(this.BASE_URL +
      'api/companies/service/getDriverBooking',
      { ID: this.user_id }, {
      headers: this.headers
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.general_booking = tmpResponse.data;
      console.log(this.general_booking);
    }, error => {

      return false;

    });
  };

  public tab1:string = "active";
  public tab2:string = "";
  public tab3:string = "";
  

  openDiv(index:number)
  {
    console.log(index);
    if(index ==1)
    {
      this.divTarget1 = true;
      this.divTarget2 = false;
      this.divTarget3 = false;

      this.tab1 = "active";
      this.tab2 = "";
      this.tab3 = "";
      

      
    }
    if(index == 2)
    {
      this.divTarget1 = false;
      this.divTarget2 = true;
      this.divTarget3 = false;

      this.tab1 = "";
      this.tab2 = "active";
      this.tab3 = "";
      
    }
    if(index == 3)
    {
      this.divTarget1 = false;
      this.divTarget2 = false;
      this.divTarget3 = true;

      this.tab1 = "";
      this.tab2 = "";
      this.tab3 = "active";
      
    }
  }


}
