import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

import { NotifierService } from "angular-notifier";
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';


@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {

//================================================//

  // toggle webcam on/off
  public showWebcamProfileImage = false;
  public showWebcamIdImage = false;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];
  // latest snapshot
  public webcamImage: WebcamImage = null;

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();
//================================================//


  public country: string;
  public user = { email: "", password: "", fcm_key: "pwa" };
  public pageCustomerRegData = { About: "About", Bookings: "Bookings", Home: "Home", Profile: "Profile", Revenue: "Revenue", Subscription: "Subscription", change_password: "Change Password", contact_us: "Contact Us", create_new_ac: "Create New Account", driver_mgmt: "Driver's Management", email_address: "Email Address", forget_pass_btn: "Forget Password", i_am_not_robot: "I am not a Robot", login: "Login", login_btn: "Login", logout: "Logout", my_vehicles: "My Vehicles", password: "Password", payment_method: "Payment Method", privacy_policy: "Privacy Policy", register_btn: "Register With Us", rides: "Rides", service: "Service", vehicle_mgmt: "Vehicle's Management" };
  public response: any;
  public tmp: any;
  public countryList: any;
  public mobileError: string;
  public message: string;
  public mobileOTP: string = "";
  public mobile_verification_code: string = "";
  public fileToUpload: File = null;
  public general = { payment_methodss: '', image: "face-image.png", id_proof_image: "identity-image.png", payment_methods: [1], user_type: "Adhoc", first_name: "", last_name: "", nationality: "", username: "", id_card: "", password: "", password_repeat: "", country: "", state: "", city: "", zip: "", street_number: "", street_name: "", house: "", floor: "", further_information: "", email: "", dialing_code: "", mobile_number: "", email_verification_code: true, mobile_verification_code: true, role: "user" };
  public pageData = {
    delete:'',
    upload_a_picture: '',
    take_a_picture:"",
    upload_an_id: '',
    business_connection: '',
    first_name: '',
    last_name: '',
    nationality: '',
    street_number: '',
    street_name: '',
    floor: '',
    house: '',
    further_information: '',
    customer_number: '',
    id_card: '',
    country: '',
    state: '',
    zip: '',
    mobile_number: '',
    payment_methods: '',
    dialing_code: '',
    city: ''
  };
  public TOKEN: string = "";
  error = new Subject<string>();
  public config: any;
  public BaseUrl: string;

  public headers: any = {};
  public is_edit: boolean = false
  public BASE_URL: string = '';
  public paymentMethodDetails: any;
  public paymentMethods: any;
  public first_nameErr:string = "";
  public last_nameErr:string = "";
  public email_alert:string = "";
  public mobile_number_alert:string = "";
  public imageErr:string = "";

  
  public id_proof_imageErr:string = "";
  public id_cardErr:string = "";
  

  private readonly notifier: NotifierService;

  public mcities: any = [];
  disabled = false;
  showFilter = false;
  limitSelection = false;
  selectedItems: any = [];
  dropDownSettings: any = {};

  constructor( notifierService: NotifierService,public global: Globals, private http: HttpClient, private cookieService: CookieService, private router: Router) {
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;
    this.notifier = notifierService;
    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });
    //this.getPaymentMethods();

  }

  ngOnInit() {

    let conn = JSON.parse(this.cookieService.get('pay'));
    this.getPaymentMethods();

    this.mcities = conn;

    // console.log(this.mcities);

    // console.log(this.selectedItems);

    console.log(this.general);

    this.dropDownSettings = {
      singleSelection: false,
      id_field: 'id',
      textField: 'payment_method_name',
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: this.showFilter
    };

    this.getPageData();
    this.getUserData();

  }


  //========= web cam codes================//

  openCam(imageType: string) {
    if (imageType == 'profile_picture') {
      this.showWebcamProfileImage = true;
      this.showWebcamIdImage = false;
    }
    else {
      this.showWebcamProfileImage = false;
      this.showWebcamIdImage = true;
    }
  }

  saveTofile(snapshotData: any, uploadfr: any) {

    var formdata = { data: snapshotData, user_type: 'user' };

    this.http.post(this.BASE_URL + 'api/general/base64Tojpeg', formdata, {
    }).
      subscribe(
        response => {
          let tmpResponse: any = response;

          if (uploadfr == "image") {
            this.general.image = tmpResponse.data;
            this.showWebcamProfileImage = false;
          }
          else {
            this.general.id_proof_image = tmpResponse.data;
            this.showWebcamIdImage = false;
          }
          //$scope.general.location_of_change  = response.data.location;
          return false;

        },
        error => {

          return false;
        });
  }

  public triggerSnapshot(): void {
    this.trigger.next();
  }


  public handleInitError(error: WebcamInitError): void {
    this.errors.push(error);
  }

  public showNextWebcam(directionOrDeviceId: boolean | string): void {
    // true => move forward through devices
    // false => move backwards through devices
    // string => move to device with given deviceId
    this.nextWebcam.next(directionOrDeviceId);
  }

  public handleImage(webcamImage: WebcamImage): void {
    this.webcamImage = webcamImage;
    if (this.showWebcamProfileImage) {
      this.saveTofile(this.webcamImage.imageAsDataUrl, 'image');
      //triggerObservable
    }
    else {
      this.saveTofile(this.webcamImage.imageAsDataUrl, 'id');
    }
  }

  public cameraWasSwitched(deviceId: string): void {

    this.deviceId = deviceId;
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public get nextWebcamObservable(): Observable<boolean | string> {
    return this.nextWebcam.asObservable();
  }



  getPaymentMethods = function () {
    this.http.get(this.global.APIURL + 'api/general/getPaymentMethods').
      subscribe(
        response => {
          console.log(response);

          this.msg = response.data.message;
          this.paymentMethodDetails = response.data1;
          let paymentMethods = response.data;
          console.log(this.paymentMethods);
          console.log("Setting payment methodssbn");
        },
        error => {
          return false;
        });
  };


  public ngAfterViewInit() {
    console.log("I am ngFterAinihuguhuhkj");
  }
  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "Customer Registration" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          console.log(responseData);
          console.log("Local Storage");
          //console.log(JSON.parse(localStorage.getItem('user')));
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
          //console.log(LOCALSTORAGE);
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;
          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getUserData() {


    this.http.get(
      this.global.APIURL + 'api/user/profile', {
      headers: this.headers
    })
      .subscribe(
        responseData => {

          var userdata: any = responseData;
          this.general = userdata.data;
          var tempPaymentMethods: any = [];
          let tmpSelectedItems: any = [];
          //
          //this.selectedItems = [this.mcities[0]];
          for (let i = 0; i < this.general.payment_methods.length; i++) {
            let pay = this.general.payment_methods[i];//3
            console.log(pay);

            tmpSelectedItems.push(this.paymentMethodDetails[pay]);
            tempPaymentMethods.push(this.paymentMethodDetails[pay].payment_method_name);
          }
          this.selectedItems = tmpSelectedItems;
          this.general.payment_methodss = tempPaymentMethods;
        },
        error => {
          this.error.next(error.message);

          if (error.error.error.trim() == "Token Expired") {
            this.router.navigate(['logout']);
          }
        }
      );
  }

  delete(user_type: any) {
    var confirmers = confirm("Are you sure, you want to delete it?");

    if (confirmers) {
      console.log(user_type);
      var formdata = {
        user_type: user_type,
        user_detail: localStorage.getItem('user_id')
      };
      this.http.post(this.BASE_URL + 'api/user/deactivateuser', formdata,
        {
          headers: this.headers
        }).
        subscribe(
          response => {
            this.router.navigate(['logout']);

            return false;

          },
          error => {
            //  console.log(response);
            // $scope.errMessage = response.data.message;
            return false;
          });
    }
    else {

    }

    return false;


  };



  setprofile = function () {
    let TOKEN = this.TOKEN;

    if (!TOKEN) {
      return false;
    }
    if (!this.formValidated()) {
      return false;
    }

    this.http.post(this.BASE_URL + 'api/driver/profile', this.general, {
      headers: this.headers
    })
      .subscribe(
        response => {
          console.log(response.data.message);
          this.getUserData();
          return false;
        },
        error => {
          this.error.next(error.message);
          console.log(error);
          return false;
        });
  };


  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    console.log(items);
  }



  handleFileInput(files: FileList, FileName: string) {
    //console.log(FileName);
    this.fileToUpload = files.item(0);
    const formData: FormData = new FormData();
    formData.append('file', this.fileToUpload, this.fileToUpload.name);
    formData.append('data', 'user');
    this.http.post(
      this.global.APIURL + "api/users/auth/uploadImage",
      formData
    )
      .subscribe(
        responseData => {
          //console.log(responseData);    
          this.tmp = responseData;
          if (FileName == 'image') {
            this.general.image = this.tmp.file_name;
          }
          else if (FileName == 'id_proof_image') {
            this.general.id_proof_image = this.tmp.file_name;
          }
          //console.log(this.general); 
        },
        error => {
          //console.log(error.message)
          this.error.next(error.message);
        }
      );
  }

  
  

  formValidateCheck()
  {
    this.first_nameErr = "";
    this.last_nameErr = "";
    this.email_alert = "";
    this.mobile_number_alert = "";
    this.imageErr = "";
    this.id_proof_imageErr = "";
    this.id_cardErr = "";
    
    let result :boolean=true;
    if(this.general.id_card=='')
    {
      this.id_cardErr = "Please enter ID Card";
      result =  false;
    }
    if(this.general.first_name=='')
    {
      this.first_nameErr = "Please enter first name";
      result =  false;
    }
    if(this.general.last_name=='')
    {
      this.last_nameErr = "Please enter last name";
      result =  false;
    }
   
    
    if( this.general.image== "face-image.png")
    {
      this.imageErr = "Please upload picture";
      result =  false;
    }
    if( this.general.id_proof_image== "identity-image.png")
    {
      this.id_proof_imageErr = "Please upload ID proof";
      result =  false;
    }
    return result;
  
  }
  

  onSubmit() {
    let tmpSelectedItems: any = [];
    let tmpSelectedItemsName: any = [];
    for (let i = 0; i < this.selectedItems.length; i++) {
      tmpSelectedItems.push(this.selectedItems[i].id);
      tmpSelectedItemsName.push(this.selectedItems[i].payment_method_name);
    }
    this.general.payment_methods = tmpSelectedItems;
    this.general.payment_methodss = tmpSelectedItemsName;
    
    //return false;
    this.mobileError = "";
    if (!this.formValidateCheck()) {
     return false;
    }
    else{

      delete this.general.payment_methodss;
      this.http.post(
        this.global.APIURL + "api/user/profile",
        this.general,
        { headers: this.headers }
      )
        .subscribe(
          responseData => {
            var res: any=responseData;           
            this.message = res.message;
            if(res.message)
          {
            this.notifier.notify("success", res.message);
            //alert(res.message);
            setTimeout(
              ()=>{
                this.router.navigate(['/user-profile']).then(() => {
                  //window.location.reload();
                 });
              }, 5000
            );
          }
          },
          error => {
            console.log(error.message)
            this.error.next(error.message);
          }
        );
    }
  }


}
