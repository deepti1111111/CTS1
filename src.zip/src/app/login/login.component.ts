import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Globals } from '../global';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { RecaptchaModule } from 'ng-recaptcha';

import { CookieService } from 'ngx-cookie-service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [ Globals ]
})
export class LoginComponent implements OnInit {
  error = new Subject<string>();
  res:any;
  public country: string;
  public tmp:any;
  public config:any;
  private captchaValid: boolean = false;
  public user = {email:"",password:"",fcm_key:"pwa",ISUsers:true};
  public pageData ={About: "About",Bookings: "Bookings",Home: "Home",Profile: "Profile",Revenue: "Revenue",Subscription: "Subscription",change_password: "Change Password",contact_us: "Contact Us",create_new_ac: "Create New Account",driver_mgmt: "Driver's Management",email_address: "Email Address",forget_pass_btn: "Forget Password",i_am_not_robot: "I am not a Robot",login: "Login",login_btn: "Login",logout: "Logout",my_vehicles: "My Vehicles",password: "Password",payment_method: "Payment Method",privacy_policy: "Privacy Policy",register_btn: "Register With Us",rides: "Rides",service: "Service",vehicle_mgmt: "Vehicle's Management"};
  
  public errMessage :string='';
  public response :any;

  constructor(public global: Globals,private http: HttpClient,private router: Router,public cookieService:CookieService) {  
     // console.log(JSON.parse(cookieService.get('language_code')));
  }

  ngOnInit() {
     //this.pageData = this.global.pageData;
    this.getHeader() ;
  }

  getHeader() {
    
    this.http.post(
      this.global.APIURL+'api/general/getPageScreen',
      {id:false,screen:"header"}
    )
    .subscribe(
      responseData => {
        this.config = responseData;
        //console.log(responseData);
        //console.log("Local Storage");
        //console.log(JSON.parse(localStorage.getItem('user')));
      var LOCALSTORAGE  = JSON.parse(localStorage.getItem('user'));
      //console.log(LOCALSTORAGE);
    //
    var cookie = JSON.parse(this.cookieService.get('language_code'));
        this.global.country = cookie.language;
        console.log(this.global.country);
        if(this.global.country == 'en')
        {
          this.pageData = this.config.data.content_en;
        }
        else if(this.global.country == 'cn')
        {
          this.pageData = this.config.data.content_cn;
        }
        else if(this.global.country == 'de')
        {
          this.pageData = this.config.data.content_de;
        }
        else if(this.global.country == 'fr')
        {
          this.pageData = this.config.data.content_fr;
        }
        else if(this.global.country == 'hi')
        {
          this.pageData = this.config.data.content_hi;
        }
        else if(this.global.country == 'es')
        {
          this.pageData = this.config.data.content_es;
        }
        this.global.setPageData(this.pageData);
      },
      error => {
        this.error.next(error.message);
      }
    );
  }


  onSubmit(){
    console.log(this.captchaValid);
    if(this.captchaValid == false)
    {
      alert("Please validate captcha!!!");
    }
    else
    {
      console.log(this.user);
      this.http.post(
        this.global.APIURL+"api/auth/signin",
        this.user
      )
      .subscribe(
        responseData => {
          console.log(responseData);
          this.response = responseData;
           
          this.global.setUserData(this.response.userDetail);
          console.log(this.global);          
          localStorage.setItem('user', JSON.stringify(this.response) );          
          console.log(localStorage.getItem('user'));
          
         this.router.navigate(['/'+JSON.parse(localStorage.getItem('user')).user_info]).then(() => {
          window.location.reload();
          });
        },
        error => {
          console.log(error.error.message)
          this.errMessage= error.error.message;
          
          
        }
      );
    }
    
  }

  resolved(captchaResponse: string) {
      this.captchaValid = true;
  }

}
