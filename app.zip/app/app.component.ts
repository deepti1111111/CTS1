import { Component, OnInit } from '@angular/core';
import { Globals } from './global';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';

export interface IImage {
  url: string | null;
  href?: string;
  clickAction?: Function;
  caption?: string;
  title?: string;
  backgroundSize?: string;
  backgroundPosition?: string;
  backgroundRepeat?: string;
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  public is_ad_available :boolean = false;
  imageUrls: (string | IImage)[] = [];
  height: string = '400px';
  minHeight: string;
  arrowSize: string = '30px';
  showArrows: boolean = true;
  disableSwiping: boolean = false;
  autoPlay: boolean = true;
  autoPlayInterval: number = 3333;
  stopAutoPlayOnSlide: boolean = true;
  debug: boolean = false;
  backgroundSize: string = 'cover';
  backgroundPosition: string = 'center center';
  backgroundRepeat: string = 'no-repeat';
  showDots: boolean = true;
  dotColor: string = '#FFF';
  showCaptions: boolean = true;
  captionColor: string = '#FFF';
  captionBackground: string = 'rgba(0, 0, 0, .35)';
  lazyLoad: boolean = false;
  hideOnNoSlides: boolean = false;
  width: string = '100%';
  fullscreen: boolean = false;
  enableZoom: boolean = false;
  enablePan: boolean = false;
  noLoop: boolean = false;
  public BaseUrl: string = "";
  public AD_URL: string = "";

  constructor(public global: Globals, private http: HttpClient, private router: Router, private cookieService: CookieService, ) {

    this.BaseUrl = this.global.APIURL;
    this.AD_URL = this.global.AD_URL;

  }



  ngOnInit() {
    this.getAdRequest();
  }

  testEvent(event) {
  }
  getAdRequest() {
    this.http.get(
      this.global.APIURL + 'api/general/getAdvertisementRequest')
      .subscribe(
        responseData => {

          let tmpresponse: any = responseData;
          this.is_ad_available = tmpresponse.status;
          
          for (let i = 0; i < tmpresponse.data.length; i++) {
            let tmpImgUrls: any = tmpresponse.data[i];
            let tmp_obj: any = {
              url: this.AD_URL + tmpImgUrls.image,
              caption: tmpImgUrls.title,
              target: "_blank",
              href: tmpImgUrls.link_url
            };
          
            this.imageUrls.push(tmp_obj);
          }
        },
        error => {
       
        }
      );
  }
  closeAd()
  {
    this.is_ad_available = false;
  }

}