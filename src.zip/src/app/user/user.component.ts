import { Component, OnInit, TemplateRef, ViewChild, ElementRef, ComponentFactoryResolver } from '@angular/core';
// import { StarRatingComponent } from 'ng-starrating';
import { Globals } from '../global';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Subject } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { resolve } from 'url';
import { BehaviorSubject, Observable, interval } from 'rxjs';
import { RatingModule } from "ngx-rating";

declare var H: any;
declare var $: any;

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],

})
export class UserComponent implements OnInit {
  modalRef: BsModalRef;

  keyword = 'name';
  // public data:any = [];
  public data1: any = [];
  public data: any = [];
  private platform: any;
  public radius:number = 100;
  public config: any;
  error = new Subject<string>();
  public BASE_URL: string;
  public subscription_status: boolean = false;
  public pageDataSubscription: any = { standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public TOKEN: any;
  public ui: any;
  public pageData = { 'pick_up_from': 'Pick Up From', 'destination': 'Destination', 'provided_service': 'Provided Service', 'all_btn': 'All', 'service': 'Service', 'taxi_platform': 'Taxi Platform', 'tip': 'TIP (in total currency equal on top the transport fare)' };
  public base_url: string;
  public BaseUrl: string;
  public headers: any;
  public driverList: any;
  public countrydata: any = { label: '' };
  public geolocation: any;
  public valid: any;
  public addressListObjects: any;
  public vehicle_filter: any = { autonom: false, eco: false, taxi: false, chauffeur: false, rental_car: false, self_employed: false, transport: false, };
  public vehicle_active_option: any = { autonom: 'no', eco: 'no', taxi: 'no', chauffeur: 'no', rental_car: 'no', self_employed: 'no', transport: 'no', };
  public vehicle_filter_option: any = { autonom: false, eco: false, taxi: false, chauffeur: false, rental_car: false, self_employed: false, transport: false };
  public request_info: any = {};
  public distance_unit = 'km';
  public startLocationListHide: boolean = false;
  public endLocationListHide: boolean = false;
  public bookingTempStore: any = {};
  public selectedTip: number = 0;
  public errAlreadyOnRide: string = '';
  public currency_code: string = 'EUR';
  public bookedDriverId: string = '';
  public vehicleTypeList: any = {};
  public errMessage: string = '';
  public booking_possibility: boolean = true;
  public ifsubscribed: boolean = true;
  public inforButtonText: string = "Book Now";
  public booking_id: string = "";
  public booking_status: string = "";
  public tmpDriverBookRideBtn: string = '';
  public payment_mode: any = [];
  public msg: string = '';
  public rideStatusId: string = "";
  public isadhoc: boolean = true;
  public subsciptionStatusmessage: string = "";
  public rideStart: boolean = false;
  public feedbackRevert: string = "";
  public bookingData: any;
  public rideFeedback: string = "";
  public rideRate: string = "5";
  public chatText: string = "";
  public chatSessionId: string = "";
  public ChatId: string = "";
  public driverMsg; string = "";
  public value: string = '';
  public customerMsg: string = "";
  public driver_id: string = "";

  public driverChatCountId: string = "";
  public customerChatCountId: string = "";


  @ViewChild("map", { static: true }) public mapElement: ElementRef;
  @ViewChild("deeptimap", { static: true }) public deeptimapElement: ElementRef;

  @ViewChild('templateRating', { static: true }) templateRating: ElementRef;
  @ViewChild('templateProgressBar', { static: true }) templateProgressBar: ElementRef;

  private map: any;
  private deeptimap: any;
  public general_location: any = {
    start_location: '', start_latlng: { 'lat': 23.33, 'lng': 72.44 }, end_location: '', end_latlng: { 'lat': '', 'lng': '' }
  };
  constructor(
    private modalService: BsModalService,
    private router: Router,
    public global: Globals, private http: HttpClient, private cookieService: CookieService) {
    this.platform = new H.service.Platform({
      "app_id": this.global.HAppId,
      "app_code": this.global.HAppCode,
      useHTTPS: true
    })
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;
    this.selectedTip = 0;
    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });
    this.base_url = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;

  }

  ngOnInit() {
    this.getPageData();
    this.getVehicleTypeDetails().then(response => {
      this.getRecentRideStatus();
    });
    this.getSubscriptionStatus();
    this.getSubscriptionInfo();

    this.getPageDataSubscription();
    this.getPosition().then(pos => {
      this.general_location.start_latlng.lat = pos.coords.latitude;
      this.general_location.start_latlng.lng = pos.coords.longitude;
      this.getAddressFromCoordinates(this.general_location.start_latlng.lat, this.general_location.start_latlng.lng, 'start');
      this.getDriverOnLocation(pos.coords.latitude, pos.coords.longitude);
    });

    this.getPageDataSubscription();
    this.getIntervalFunction();

  }

  onEnter(value: string) {
    this.chatText = "";
    this.value = value;
    this.appenMessage(this.value);
  }

  getRecentRideStatus() {

    this.http.get(this.BASE_URL + 'api/users/booking/recentRide', {
      headers: this.headers
    }).subscribe(
      response => {
        //console.log("request STATUS ");
        // console.log(response.data.data);
        // console.log(response.data.data);
        let tmpResponse: any = response;
        
        var booking_detail = tmpResponse.data;
        console.log(booking_detail);
        if (!booking_detail || booking_detail.booking_status=="0") {
          return false;
        }
        this.booking_status = "";

        this.general_location.end_latlng.lat = booking_detail.end_latitude;
        this.general_location.end_latlng.lng = booking_detail.end_longitude;
        this.general_location.end_location = booking_detail.drop_to;

        if (booking_detail.booking_status == "4") {

          this.booking_status = '4';
          this.booking_id = booking_detail.booking_id;
          this.driver_id = booking_detail.driver_id;
          this.inforButtonText == "Cancel Ride";
          console.log(this.booking_id+" This I got from getrecentride status");
          console.log(this.driverList);


          this.drawRouteHereMap(this.general_location.start_latlng.lat, this.general_location.start_latlng.lng, this.general_location.end_latlng.lat, this.general_location.end_latlng.lng, this.distance_unit);
          let driver: any = tmpResponse.driver;
          
          let tmpDriverList: any = [];
          tmpDriverList.push(driver);
          this.addInfoBubble(tmpDriverList);

          //addInfoBubble(user_detail: any) 
          this.chatSessionId = booking_detail.chat_session_id;
        }
        if (booking_detail.booking_status == "1") {
          this.rideStart = true;
          //this.booking_status = 4;
          this.booking_id = tmpResponse.data.booking_id;
          this.driver_id = booking_detail.driver_id;
          this.booking_possibility = false;
          this.drawRouteHereMap(this.general_location.start_latlng.lat, this.general_location.start_latlng.lng, this.general_location.end_latlng.lat, this.general_location.end_latlng.lng, this.distance_unit);
          let driver: any = tmpResponse.driver;
          console.log("driver");
          console.log(driver);
          let tmpDriverList: any = [];
          tmpDriverList.push(driver);
          this.addInfoBubble(tmpDriverList);

          //this.inforButtonText == "Cancel Ride";
        }
        if (booking_detail.booking_status == "2") {
          this.errMessage = "Ride is Completed, Please Pay!";
          this.rideStart = true;
          if (booking_detail.pay_status == 1 || booking_detail.pay_status == '1') {
            this.errMessage = "Thank you.";

            setTimeout(function () {
              this.errMessage = '';
              this.inforButtonText = "Book Now";
              this.booking_id = false;
            }, 2000);
          }

          //this.booking_status = 4;
          this.booking_id = tmpResponse.data.booking_id;
          this.driver_id = booking_detail.driver_id;
          this.chatSessionId = "";
          this.modalRef = this.modalService.show(this.templateRating);
          //this.inforButtonText == "Cancel Ride";
        }

      }, error => {

        if (error.error.error == "Token Expired") {
          this.router.navigate(['/logout']);
        }
        return false;
      });
  };


  submitRatingFeedback(booking_id: string, rideRate: any, rideFeedback: string) {

    //console.log(rideRate + ", " + rideFeedback + ", " + booking_id);
    if(rideRate<1)
    {
      rideRate =1;
    }

    var formdata = {
      feedback: rideFeedback,
      rating: rideRate,
      booking_id: booking_id
    };
    this.http.post(this.BASE_URL + 'api/users/booking/ratingFeedbackBookingRide', formdata, {
      headers: this.headers
    }).subscribe(
      response => {
        let tmpResponse: any = response;
        this.feedbackRevert = tmpResponse.message;
        setTimeout(() => {
          this.modalRef.hide();

        }, 3000);
        this.booking_id = '';
        window.location.reload();

      },
      error => {
        var message = error.error.error;
      });

  };


  getVehicleTypeDetails(): Promise<any> {
    return new Promise((resolve, reject) => {
      var api_method = 'vehicleTypeList';
      this.http.get(this.BASE_URL + 'api/vehicle/' + api_method, {
        headers: this.headers
      }).subscribe(
        response => {
          let tmpResponse: any = response;
          this.vehicleTypeList = tmpResponse.dataList;
          /// console.log(this.vehicleTypeList);
          resolve(response);
          return false;
        },
        error => {
          console.log(error.error.error);
          if (error.error.error == "Token Expired") {
            this.router.navigate(['logout']);
          }
          reject(error);
          return false;
        });

    });


  };

  getChatTextByUser(chatSessionId: string, chatCountId: string) {
    var message = "";
    if (!this.ChatId) {
      this.ChatId = '0';
    }
    var formdata = {
      // user: user,
      chat_session_id: chatSessionId,
      id: this.ChatId
    };
    console.log(this.booking_id );

    this.http.post(this.BASE_URL + 'api/users/booking/chatInfo', formdata, {
      headers: this.headers
    }).subscribe(
      response => {
        // console.log("ChatINfo");
        let tmpResponse: any = response;
        if (tmpResponse.success) {
          console.log(tmpResponse);
          console.log(tmpResponse.success);
          var user = tmpResponse.data.user_type;
          console.log(user);
          console.log(" Found Customers " + user + " tesxt");

          var yaz = "<div class='o'>" + this.driverMsg;
          var yazi = "<div class='sen'>" + img + this.customerMsg;
          var output = $('.mesaj-gecmisi');
          var sil = "<div class='sil'></div>";


          //$("#sonuc").append("<div class='sen'>" + img + yazi + sil + "</div>" + sil + yaz + sil + "</div>");



          var img = '<i class="fa fa-user" aria-hidden="true"></i>';
          var driverimg = "<img align='right' src='" + this.BASE_URL + "images/taxi-driver.svg' width='30px'>";

          if (user == 'driver') {
            this.ChatId = tmpResponse.data.id;
            this.driverMsg = tmpResponse.data.chat_text;

            var yaz = "<div class='o'>" + this.driverMsg;
            var yazi = "<div class='sen'>" + img + this.customerMsg;
            var output = $('.mesaj-gecmisi');
            var sil = "<div class='sil'></div>";

            $("#sonuc").append("<div class='sen'>");
            $("#sonuc").append("</div>");

            $("#sonuc").append(yaz + driverimg + sil);
            $("#sonuc").append("</div>");
          }
          if (user == 'customer') {
            this.ChatId = tmpResponse.data.id;
            this.customerMsg = tmpResponse.data.chat_text;


            var yaz = "<div class='o'>" + this.driverMsg;
            var yazi = "<div class='sen'>" + img + this.customerMsg;
            var output = $('.mesaj-gecmisi');
            var sil = "<div class='sil'></div>";


            $("#sonuc").append("<div class='sen'>");
            $("#sonuc").append("</div>");
            $("#sonuc").append(yazi + sil);
            //$("#sonuc").append(yazi + sil);
            $("#sonuc").append("</div>");

          }

          output.scrollTop(
            output[0].scrollHeight - output.height()
          );

        }
        else {
          this.driverMsg = "";
          this.customerMsg = "";
          //                console.log("================   NOT  Found Customers " + user + " tesxt");
        }


      }, error => {
        message = error.error.error;
      });
  };

  getChatInfo() {
    if (!this.chatSessionId) {
      this.ChatId = "";
      return false;

    }
    this.getChatTextByUser(this.chatSessionId, this.ChatId);

  };

  /**
     * Add two markers showing the position of Liverpool and Manchester City football clubs.
     * Clicking on a marker opens an infobubble which holds HTML content related to the marker.
     * @param  {H.Map} map      A HERE Map instance within the application
     */

  addInfoBubble(user_detail: any) {
    var group = new H.map.Group();
    this.map.addObject(group);
    console.log("user_detail in Add Info Bubble");
    console.log(user_detail);

    var bubble: any;
    // add 'tap' event listener, that opens info bubble, to the group
    group.addEventListener('tap', (evt: { target: { getGeometry: () => any; getData: () => any; }; }) => {
      // event target is the marker itself, group is a parent event target
      // for all objects that it contains
      bubble = new H.ui.InfoBubble(evt.target.getGeometry(), {

        // read custom data
        content: evt.target.getData()
      });
      //console.log(evt.target.getData());
      this.ui.addBubble(bubble);


      let btn = document.getElementById("booking_btn");

      let userHiddentTextField: any = document.getElementById('userid');
      console.log("btn.innerText");
      console.log(btn.innerText);
      //  btn.innerText = "Kuch bhi";
      btn.addEventListener("click", (e: Event) => this.bookRide(userHiddentTextField.value));

    }, false);

    var latu = this.general_location.start_latlng.lat;
    var lngu = this.general_location.start_latlng.lng;
    this.addMarkerToGroup(group, { lat: latu, lng: lngu }, '', 'user');

    var routeApiLog = this.distanceCalc(this.general_location.start_latlng.lat, this.general_location.start_latlng.lng, this.general_location.end_latlng.lat, this.general_location.end_latlng.lng);
    if (!routeApiLog) {

      return false;
    }
    // console.log(this.vehicleTypeList);
    //    console.log(this.selectedTip);
    let tmpTip = this.selectedTip;
    let tmpVehicleTypeList: any = this.vehicleTypeList;
    let tmpbookedDriverId: any = this.bookedDriverId;
    let tmpBASE_URL = this.BASE_URL;
    let tmpcurrency_code = this.currency_code;

    routeApiLog.then(
      response => {
        // console.log(this.vehicleTypeList);
        // console.log(tmpVehicleTypeList);

        // console.log(this.vehicleTypeList);
        distance = Math.ceil((response.response.route[0].summary.distance) / 1000);
        var time = Math.ceil((response.response.route[0].summary.baseTime) / 60);
        console.log("Driver Count" + user_detail.length);
        if (user_detail) {
          for (var i = 0; i < user_detail.length; i++) {

            var dLat = user_detail[i].latitude;
            var dLng = user_detail[i].longitude;

            var driver = user_detail[i];
            var tipDiv = '<div>';

            tipDiv += '<span> <input type="number" name="tip" [(model)]="selectedTip" min="0" />  </span>';

            tipDiv += '</div>';
            var vehicleTypeId = driver.vehicle_type_id;
            //            console.log("VehicleTypeId    " + vehicleTypeId);
            console.log(tmpVehicleTypeList);
            let fare_rate: number = tmpVehicleTypeList[vehicleTypeId].fare_rate;
            //this.fareRate = this.fare_rate;
            var minDistance = parseFloat(tmpVehicleTypeList[vehicleTypeId].min_distance);
            tmpTip = 0;

            if (distance <= minDistance) {
              distance = minDistance;
            }
            else {
              distance = distance + minDistance;
            }
            if (tmpTip) {
              tmpTip = 0;
            }
            var amount = parseFloat(tmpVehicleTypeList[vehicleTypeId].min_fare) + (distance * fare_rate) + tmpTip;
            amount = Math.ceil(amount);
            // console.log(distance);
            var distance = Math.ceil(distance);

            this.bookingTempStore = {
              distance: distance,
              amount: amount,
              eta: time,
              driver: driver

            };
            let errAlreadyOnRide = false;
            if ((tmpbookedDriverId) && tmpbookedDriverId != driver.user_id) {
              errAlreadyOnRide = true;
            }
            else {
              errAlreadyOnRide = false;
            }
            //console.log(errAlreadyOnRide+","+tmpbookedDriverId);            
            if (this.booking_status == '4') {
              this.inforButtonText = "Cancel Ride";
            }
            var backtick = `<ng-container>
            <div  class="form-group" id="strInforWindow_div"> 
            <span class="driver-image" id="strInforWindow_img">
            <input type="hidden" value="${driver.user_id}" id="userid" name ="user"/>
            <img src="${this.BASE_URL}uploads/driver/${driver.image}" height="20" width="20"></span>
            <ul class="infoWindowStyle">
            <li><i class="fa fa-user" aria-hidden="true"></i> ${driver.first_name}  ${driver.last_name} </li>
            <li><i class="fa fa-car" aria-hidden="true"></i> ${driver.license_plate_no}</li>
            <li><i class="fa fa-phone" aria-hidden="true"></i>${driver.mobile_number}  </li>
            <li><i class="fa fa-clock-o" aria-hidden="true"></i>${this.bookingTempStore.eta} Minute </li>
            <li><i class="fa fa-road" aria-hidden="true"></i> ${this.bookingTempStore.distance} KM  </li>
            <li><i class="fa fa-money" aria-hidden="true"></i>${this.bookingTempStore.amount}  ${tmpcurrency_code} </li>
            <li><lable>Tip: ${tipDiv} </lable> </li>
            `;
           
            if (this.booking_possibility) {
              if(this.ifsubscribed)
              {
                if (this.booking_id) {
                  backtick += `<li><button id="booking_btn" >Cancel Ride </button></li>`;
                }
                else {
                  backtick += `<li><button id="booking_btn"  >${this.inforButtonText} </button></li>`;
                }
              }
              else{
                backtick += `<li><a href="user-subscription" class="c-menu__link"><span class="messageSub">Current plan Expired! Please upgrade.</span></a></li>`;
              }
             

            }
            else {
              backtick += `<li>Booking not possible until you finish your already running ride</li>`;
            }

            backtick += `</ul><div style="clear:both"></div>`;
            backtick += ` <div class="DrMsg"><span class="alertDanger" id="errMessage">${this.errMessage}</span></div>`;

            if (this.errAlreadyOnRide) {
              backtick += `<span>You are already on a ride</span>`;
            }
            backtick += `</div></ng-container>`;
            this.addMarkerToGroup(group, { lat: dLat, lng: dLng }, backtick, 'driver');
          }
        }

      },
      () => {
        //// console.log('Failed: ');
        //// console.log(reason);
      });


  }

  bookRide(driver_id: string) {
    console.log(driver_id);

    console.log("subscription Status: " + this.subscription_status);

    console.log("book Ride");
    // console.log(driver_id);


    let driver: any = {};
    for (var i = 0; i < this.driverList.length; i++) {
      if (this.driverList[i].user_id == driver_id) {
        driver = this.driverList[i];
      }
    }


    //console.log(driver);
    // return false;
    if (this.inforButtonText == "Book Now") {

      this.postBookingRequest(driver).then(
        response => {
          console.log(response);
          let tmpResponse: any = response;
          console.log(tmpResponse);
          this.msg = tmpResponse.message;
          var booking_id = tmpResponse.data;
          this.bookedDriverId = tmpResponse.driver_id;
          this.booking_id = booking_id;
          console.log("this.booking_id       --->   " + this.booking_id);
          //booking_btn
          // $("#booking_btn").attr("disabled", 'true');
          this.modalRef = this.modalService.show(this.templateProgressBar);
          setTimeout(() => {
            this.checkDriverResponse(booking_id);
            let btn = document.getElementById("booking_btn");
            btn.innerText = "Cancel Ride";
            // this.modalRef.hide();
          }, 15000);
          // $('#booking_btn').removeAttr("disabled");

        },
        error => {
          console.log(error);
        }
      );
      //this.inforButtonText = "Cancel Ride";
    }
    if (this.inforButtonText == "Cancel Ride") {

      this.cancelRequestedRide(this.booking_id);
   //   window.location.reload();
      //this.inforButtonText = "Cancel Ride";
    }



  }

  //================ Booking functionality =====//


  checkDriverResponse(booking_id: any) {
    console.log(booking_id);
    this.booking_id = booking_id;
    var message = "";
    var formdata = { booking_id: booking_id };
    this.http.post(this.BASE_URL + 'api/users/service/requestReplyByDriver', formdata, {
      headers: this.headers
    }).subscribe(
      response => {
        let tmpResponse: any = response;
        if (this.modalRef) {
          this.modalRef.hide();
        }
        /// console.log(tmpResponse);
        if (tmpResponse.data == "4" || tmpResponse.data == "1") {
          this.inforButtonText = "Cancel Ride";
          let btn = document.getElementById("booking_btn");
          btn.innerText = this.inforButtonText;
          message = tmpResponse.message;
          let span = document.getElementById('errMessage');
          span.innerHTML = message;
          this.errMessage = message;

        }
        else if (tmpResponse.data == "3") {
          console.log(tmpResponse.message);
          console.log(tmpResponse.data)
          this.inforButtonText = "Book Ride";
          let btn = document.getElementById("booking_btn");
          btn.innerText = this.inforButtonText;
          message = tmpResponse.message;
          let span = document.getElementById('errMessage');
          span.innerHTML = message;
          this.errMessage = message;
        }
        return message;
      },
      error => {
        message = error.error.message;
      });

    return message;
  };

  postBookingRequest(driver: any): Promise<any> {
    return new Promise((resolve, reject) => {

      var customerDetails = JSON.parse(localStorage.getItem("user"));
      console.log(customerDetails);
      //  console.log(this.general_location);

      var today = new Date();
      var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
      var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
      var dateTime = date + ' ' + time;
      var payment_mode = this.payment_mode;
      // console.log(this.bookingTempStore);
      if (!this.selectedTip) {
        this.selectedTip = 0;
      }

      var formdata = {
        customer_id: customerDetails.userDetail.user_id,
        customer_name: customerDetails.userDetail.first_name + " " + customerDetails.userDetail.last_name,
        customer_email: customerDetails.userDetail.email,
        driver_id: driver.user_id,
        driver_name: driver.first_name + " " + driver.last_name,
        driver_contact: driver.mobile_number,
        driver_email: driver.email,
        company_id: driver.company_id,
        company_name: (driver.company_firstname) ? driver.company_firstname + " " + driver.company_lastname : '',
        vehicle_id: driver.vehicle_id,
        vehicle_type: driver.vehicle_type,
        vehicle_make: driver.vehicle_make,
        vehicle_model: driver.vehicle_model,
        pick_up: this.general_location.start_location,
        drop_to: this.general_location.end_location.name,
        latitude: this.general_location.start_latlng.lat,
        longitude: this.general_location.start_latlng.lng,
        end_latitude: this.general_location.end_latlng.lat,
        end_longitude: this.general_location.end_latlng.lng,
        requested_payment_mode_id: "1",
        requested_payment_mode: "Cash",
        distance: this.bookingTempStore.distance,
        distance_unit: this.distance_unit,
        amount: this.bookingTempStore.amount,
        tip: this.selectedTip,
        total_amount: this.bookingTempStore.amount + this.selectedTip,
        currency_code: this.currency_code,
        booking_status: 3,
        create_date: dateTime,
        booking_datetime: dateTime
      };

      this.http.post(this.BASE_URL + 'api/users/service/request', formdata, { headers: this.headers }).subscribe(response => {
        resolve(response);
      }, error => {
        reject;
      });

    });

  };

  cancelRequestedRide(booking_id: string) {
   // this.booking_id = booking_id;
    console.log(this.booking_id);
    //return false;
    var message = "";
    var formdata = { booking_id: this.booking_id };
    this.http.post(this.BASE_URL + 'api/users/service/cancelRide', formdata, {
      headers: this.headers
    }).subscribe(response => {
      let tmpResponse: any = response;
      console.log(tmpResponse);
      this.errMessage = tmpResponse.message;
      let span = document.getElementById('errMessage');
      span.innerText = this.errMessage;
      // errMessage
      this.inforButtonText = "Book Now";
      let btn = document.getElementById("booking_btn");
      btn.innerText = this.inforButtonText;
    },
      error => {
        message = error.error.error.message;
      });

    return message;
  };

  getSubscriptionStatus() {

    var api_method = 'subsciptionStatus';

    this.http.get(this.BASE_URL + 'api/user/' + api_method, {
      headers: this.headers
    }).
      subscribe(
        (response: any) => {
          //            console.log(tmptmpResponse);
          let tmpResponse: any = response;
          this.vehicle_active_option = tmpResponse.vehicle_active_option;
          this.isadhoc = tmpResponse.isadhoc;
          this.subsciptionStatusmessage = tmpResponse.message;

          this.subscription_status = tmpResponse.status;
          return false;
        },
        () => {
          return false;
        });
  };

  public ngAfterViewInit() {

    let pixelRatio = window.devicePixelRatio || 1;
    let defaultLayers = this.platform.createDefaultLayers();
    this.map = new H.Map(this.mapElement.nativeElement, defaultLayers.normal.map, { pixelRatio: pixelRatio });
    this.ui = H.ui.UI.createDefault(this.map, defaultLayers);
    let behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(this.map));
    this.map.setCenter({ lat: this.general_location.start_latlng.lat, lng: this.general_location.start_latlng.lng });
    this.map.setZoom(14);
  }

  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "user" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          //console.log(LOCALSTORAGE);
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;
          console.log(this.global.country);
          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
          //  console.log(this.pageData);
          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getPageDataSubscription() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "user-subscription" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          //console.log(LOCALSTORAGE);
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;
          // console.log(this.global.country);
          if (this.global.country == 'en') {
            this.pageDataSubscription = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageDataSubscription = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageDataSubscription = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageDataSubscription = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageDataSubscription = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageDataSubscription = this.config.data.content_es;
          }
          //   console.log(this.pageDataSubscription);
          this.global.setPageData(this.pageDataSubscription);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }


  HgetAutocompleteAddressSugestion(searchKeyWord: any) {

    var http_url = "  https://autocomplete.geocoder.api.here.com/6.2/suggest.json?query=" + searchKeyWord + "&app_id=" + this.global.HAppId + "&app_code=" + this.global.HAppCode + "";
    this.http.get(http_url).subscribe(
      response => {
        var tmpResponse: any = response;
        this.data = [];
        // this.addressListObjects = tmpResponse.suggestions;
        let tmpAddressList: any = tmpResponse.suggestions;
        //console.log(tmpAddressList);
        if (tmpAddressList) {
          for (let i = 0; i < tmpAddressList.length; i++) {
            this.data.push({ id: i + 1, name: tmpAddressList[i].label });
          }
        }
      },
      () => {
        console.log("Unable to perform get request");
      }
    );
    // console.log(http_url);
  };

  Hmapfunction(type: any) {
    if (type == "start") {
      this.map.setCenter({ lat: this.general_location.start_latlng.lat, lng: this.general_location.start_latlng.lng });
      var n_marker = new H.map.DomMarker({ lat: this.general_location.start_latlng.lat, lng: this.general_location.start_latlng.lng });
      this.map.addObject(n_marker);
    }
  }

  fillTextbox(address: string, type: string) {
    if (type == "start") {
      this.general_location.start_location = address;
      this.startLocationListHide = true;
    }
    if (type == "end") {
      this.general_location.end_location = address;
      this.endLocationListHide = true;
    }

    var http_url = "https://geocoder.api.here.com/6.2/geocode.json?app_id=" + this.global.HAppId + "&app_code=" + this.global.HAppCode + "&searchtext=" + address;

    this.http.get(http_url).subscribe(
      response => {

        let tmpResponse: any = response;

        var location = tmpResponse.Response.View[0].Result[0].Location.DisplayPosition;
        if (type == "start") {
          this.general_location.start_latlng.lat = location.Latitude;
          this.general_location.start_latlng.lng = location.Longitude;
        }
        if (type == "end") {
          this.general_location.end_latlng.lat = location.Latitude;
          this.general_location.end_latlng.lng = location.Longitude;
          this.drawRouteHereMap(this.general_location.start_latlng.lat, this.general_location.start_latlng.lng, this.general_location.end_latlng.lat, this.general_location.end_latlng.lng, this.distance_unit);
          this.Hmapfunction(type);
          this.getDriverOnLocation(this.general_location.end_latlng.lat, this.general_location.end_latlng.lng);
        }
 
      },
      () => {
        console.log("Unable to perform get request");
      }
    );
  };

  getDriverOnLocation(lat: string, lng: string) {
    var formdata = { latitude: lat, longitude: lng, booking_status: [0, 2], radius: this.radius, unit_type: this.distance_unit, business_connection_type: [10, 11], vehicle_filter: this.vehicle_filter };
    var api_method = 'getDriversByLocation';
    this.http.post(this.BASE_URL + 'api/users/service/' + api_method,
      formdata, {
      headers: this.headers
    }).
      subscribe(
        (resposne: any) => {
          var tmpResponse = resposne;
          this.driverList = tmpResponse.data;
          console.log("driver list");
          console.log(this.driverList);
          if (this.driverList) {
            this.createheremap(lat, lng, this.driverList);
          }
          return false;
        },
        (error: { error: { error: string; }; }) => {
          if (error.error.error == 'Token Expired') {
            this.router.navigate(['logout']);
          }
          return false;
        });

  };

  createheremap(maplat: string, maplang: string, user_detail: any) {
    this.map.setCenter({ lat: maplat, lng: maplang });
    this.map.setZoom(14);
    //this.map.removeObjects(this.map.getObjects());
    if (this.general_location.end_latlng.lat && this.general_location.end_latlng.lng) {
      this.drawRouteHereMap(this.general_location.start_latlng.lat, this.general_location.start_latlng.lng, this.general_location.end_latlng.lat, this.general_location.end_latlng.lng, this.distance_unit);
    }
    this.addInfoBubble(user_detail);

  }

  addMarkerToGroup(group: any, coordinate: any, html: string, user_type: any) {
    if (user_type == 'user') {
      var svgMarkup = '<svg width="125" height="125" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><circle cx="8" cy="8" r="8" fill="#1A5E03 " stroke="white" stroke-width="2" /></svg>';
      var icon = new H.map.Icon(svgMarkup);
      var marker = new H.map.Marker(coordinate, { icon: icon });
      //marker.setData(html);
      group.addObject(marker);
    }
    else {

      var marker = new H.map.Marker(coordinate);
      marker.setData(html);
      group.addObject(marker);
    }

  }


  drawRouteHereMap(request_start_latitude: string, request_start_longitude: string, driver_start_latitude: string, driven_start_longitude: string, distance_unit: string) {

    var routeApiLog = this.distanceCalc(request_start_latitude, request_start_longitude, driver_start_latitude, driven_start_longitude);
    if (!routeApiLog) {
      return false;
    }
    routeApiLog.then((response: any) => {

      this.draw(response);
    }, (reason: any) => {
      console.log('Failed: ');
      console.log(reason);
    });
  };


  draw(response: any) {
    var route = response.response.route[0];                    // Pick the route's shape:
    var routeShape = route.shape;                              // Create a linestring to use as a point source for the route line
    var linestring = new H.geo.LineString();                    // Push all the points in the shape into the linestring:
    routeShape.forEach(function (point: string) {
      var parts = point.split(',');
      linestring.pushLatLngAlt(parts[0], parts[1]);
    });        // Retrieve the mapped positions of the requested waypoints:
    var startPoint = route.waypoint[0].mappedPosition;
    var endPoint = route.waypoint[1].mappedPosition;           // Create a polyline to display the route:
    var routeLine = new H.map.Polyline(linestring, {
      style: { strokeColor: 'green', lineWidth: 3 }
    });
    var svgMarkup = '<svg width="24" height="24" xmlns="http://www.w3.org/2000/svg"><rect stroke="white" fill="#1b468d" x="1" y="1" width="22" height="22" /><text x="12" y="18" font-size="12pt" font-family="Arial" font-weight="bold" text-anchor="middle" fill="white">.</text></svg>';
    var icon = new H.map.Icon(svgMarkup);                    // Create a marker for the start point:
    var startMarker = new H.map.Marker({
      lat: startPoint.latitude,
      lng: startPoint.longitude
    },
      { icon: icon });                    // Create a marker for the end point:
    var endMarker = new H.map.Marker({
      lat: endPoint.latitude,
      lng: endPoint.longitude
    }, { icon: icon }
    );                    // Add the route polyline and the two markers to the map:
    this.map.addObjects([routeLine, startMarker, endMarker]);                    //  this.map.addObjects([routeLine]);                    // Set the map's viewport to make the whole route visible:
    //this.map.getViewModel().setLookAtData({ bounds: routeLine.getBoundingBox() });
    this.map.setCenter({
      lat: startPoint.latitude,
      lng: startPoint.longitude
    });
    this.map.setZoom(14);
    // this.map.setZoom(14);
  }

  distanceCalc(lat1: string, lon1: string, lat2: string, lon2: string): Promise<any> {
    return new Promise((resolve, reject) => {
      let url: string = 'https://route.api.here.com/routing/7.2/calculateroute.json?app_id=' + this.global.HAppId + '&app_code=' + this.global.HAppCode + '&waypoint0=geo!' + lat1 + ',' + lon1 + '&waypoint1=geo!' + lat2 + ',' + lon2 + '&routeattributes=wp,sm,sh,sc&mode=fastest;car';
      url = "https://route.ls.hereapi.com/routing/7.2/calculateroute.json?apiKey=" + this.global.HAPIKEY + "&waypoint0=geo!" + lat1 + "," + lon1 + "&waypoint1=geo!" + lat2 + "," + lon2 + "&routeattributes=wp,sm,sh,sc&mode=fastest;car";
      this.http.get(url).
        subscribe(response => {
          resolve(response);
        },
          error => {
            reject(error);
          });
    });
  };

  updateUserLocation(value: any) {
    this.http.post(this.BASE_URL + 'api/user/editLocation', { tmp_country: value }, { headers: this.headers }).subscribe(() => { return false; }, () => { return false; });
  };

  getPosition(): Promise<any> {
    return new Promise((resolve) => {
      var geolocation = require('geolocation');
      geolocation.getCurrentPosition(function (err: any, position: any) {
        if (err) throw err
        resolve(position);
      })
    });
  };

  getAddressFromCoordinates(lat: string, lng: string, state: string) {
    var http_rest_api_url = "https://reverse.geocoder.api.here.com/6.2/reversegeocode.json?prox=" + lat + "," + lng + "&mode=retrieveAddresses&maxresults=1&app_id=" + this.global.HAppId + "&app_code=" + this.global.HAppCode;
    this.http.get(http_rest_api_url).
      subscribe(
        response => {
          var tmpResponse: any;
          tmpResponse = response;
          tmpResponse = tmpResponse.Response.View[0].Result[0].Location.Address.Label;
          var address = tmpResponse;
          if (state == 'start') {
            this.general_location.start_latlng.lat = lat;
            this.general_location.start_latlng.lng = lng;
            this.general_location.start_location = address;
          }
          return address;
        },
        error => {
          console.log(error);
          console.log("Unable to perform get request");
        }
      );
  };

  selectEvent(item: any, type: any) {
    this.fillTextbox(item.name, type);
  }

  onChangeSearch(val: string, type: string) {
    this.HgetAutocompleteAddressSugestion(val);
  }

  onFocused(e: any) {
    // do something when input is focused
    //console.log(e);
  }

  public openModal(template: TemplateRef<any>) {
    console.log(template);
    this.modalRef = this.modalService.show(template);
  }


  appenMessage(text: string) {
    //console.log(this.chatText);
    var message = "";
    this.http.post(this.BASE_URL + 'api/users/booking/saveChat', { text: text, chatSessionId: this.chatSessionId },
      {
        headers: this.headers
      }).subscribe(
        response => {
          let tmpResponse: any = response;
          console.log(tmpResponse.data);


        }, error => {
          message = error.error.error;
        });
    this.chatText = "";

  };


  getRideRequestStatus(booking_id: string) {
    if (!this.booking_id) {
      return false;
    }
    console.log(this.booking_id);
    this.http.get(this.BASE_URL + 'api/drivers/booking/requestStatus/' + this.booking_id, {
      headers: this.headers
    }).subscribe(
      response => {

        let tmpResponse: any = response;
        console.log(tmpResponse);
        let message = tmpResponse.message;
        let booking_details: any = tmpResponse.dataList;
        this.bookingData = booking_details;
        this.booking_id = booking_details.booking_id;
        this.request_info = booking_details;
        var booking_status = booking_details.booking_status;
        if (booking_status == '0' || booking_status == 0) {
          this.inforButtonText = "Book Now";
          let btn = document.getElementById("booking_btn");
          btn.innerText = this.inforButtonText;
          let span = document.getElementById('errMessage');
          span.innerHTML = "Ride is cancelled";
          this.errMessage = "Ride is ongoing, Enjoy";

        }
        if (booking_status == '1' || booking_status == 1) {
          let span = document.getElementById('errMessage');
          span.innerHTML = "Ride is ongoing, Enjoy";
          this.errMessage = "Ride is ongoing, Enjoy";
          console.log(message);
          this.chatSessionId = booking_details.chat_session_id;
          document.getElementById("booking_btn").style.visibility = "hidden";


        }

        if (booking_status == '2' || booking_status == 2) {
          this.errMessage = "Ride is Completed, Please Pay!";
          this.rideStart = true;
          let span = document.getElementById('errMessage');
          span.innerHTML = "Ride is complete now";
          this.errMessage = "Ride is complete now. Please pay";
          console.log("Ride is complete now");

          document.getElementById("booking_btn").style.visibility = "hidden";

          if (booking_details.pay_status == 1 || booking_details.pay_status == '1') {
            this.errMessage = "Thank you.";


            setTimeout(function () {
              if (this.isBaidu) {
                this.inforWindowMap.closeInfoWindow();
              }
              else {
                $('.H_ui').css("display", "none");
              }
              this.errMessage = '';
              this.inforButtonText = "Book Now";
            }, 2000);
            this.modalRef = this.modalService.show(this.templateRating);


            this.booking_id = '';
            //   $('#chat').css("display", "none");
            //  this.chatSessionId = false;
            // this.chatSessionId = false;
          }
        }

        if (booking_status == '4' || booking_status == 4) {

          if (this.modalRef) {
            this.modalRef.hide();
          }
          this.chatSessionId = booking_details.chat_session_id;
        }

        if (booking_status == '5' || booking_status == 5) {
          this.inforButtonText = "Book Now";
          let btn = document.getElementById("booking_btn");
          btn.innerText = this.inforButtonText;
          this.booking_id = "";
        }

      }, error => {
        return false;
      });
  };

  getIntervalFunction() {
    interval(5000).subscribe(x => {
      if (this.booking_id) {
        this.getRideRequestStatus(this.booking_id);

      }
    });

    interval(1000).subscribe(x => {
      if (this.chatSessionId) {
        if(this.booking_id)
        {
          this.getChatInfo();
        }
        
      }
    });
  }
  getSubscriptionInfo = function () {
    var api_method = "subscriptionInfo";
    this.http.get(this.BASE_URL + 'api/users/account/' + api_method, {
      headers: this.headers
    })
      .subscribe(
        response=> {
          let tmpResponse:any = response;
          console.log(tmpResponse);
          this.subscription_info = tmpResponse.data;
          this.ifsubscribed = tmpResponse.subscription_status;
          this.isadhoc = response.adhoc;

          if (response.success == "true") {
            this.subscribed = true;
            this.subscriptionMessage = response.message;
          }
          else {
            this.subscribed = false;
            this.subscriptionMessage = response.message;
          }


          return false;
        },
        error => {
          return false;
        });
  };




}