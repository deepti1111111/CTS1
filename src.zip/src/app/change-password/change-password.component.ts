import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { typeWithParameters } from '@angular/compiler/src/render3/util';


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  public isadhoc: boolean = false;
  public rS1: string = "_21164968305007015906";
  public rS2: string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_000X690979_";

  public country: string;
  public user = { email: "", password: "", fcm_key: "pwa" };
  public pageCustomerRegData = { About: "About", Bookings: "Bookings", Home: "Home", Profile: "Profile", Revenue: "Revenue", Subscription: "Subscription", change_password: "Change Password", contact_us: "Contact Us", create_new_ac: "Create New Account", driver_mgmt: "Driver's Management", email_address: "Email Address", forget_pass_btn: "Forget Password", i_am_not_robot: "I am not a Robot", login: "Login", login_btn: "Login", logout: "Logout", my_vehicles: "My Vehicles", password: "Password", payment_method: "Payment Method", privacy_policy: "Privacy Policy", register_btn: "Register With Us", rides: "Rides", service: "Service", vehicle_mgmt: "Vehicle's Management" };
  public response: any;
  public tmp: any;
  public countryList: any;
  public mobileError: string;
  public message: string;
  public mobileOTP: string = "";
  public mobile_verification_code: string = "";
  public fileToUpload: File = null;
  public general = { payment_methodss: '', image: "face-image.png", id_proof_image: "identity-image.png", payment_methods: [1], user_type: "Adhoc", first_name: "", last_name: "", nationality: "", username: "", id_card: "", password: "", password_repeat: "", country: "", state: "", city: "", zip: "", street_number: "", street_name: "", house: "", floor: "", further_information: "", email: "", dialing_code: "", mobile_number: "", email_verification_code: true, mobile_verification_code: true, role: "user" };
  public pageData = { current_password: 'Standard', password: 'Exclusive', password_repeat: 'Premium', current_password_msg: 'Free', match_password_msg: '' };
  public TOKEN: string = "";
  error = new Subject<string>();
  public config: any;
  public BaseUrl: string;
  public subscribed: boolean = false;
  public headers: any = {};
  public is_edit: boolean = false;
  public BASE_URL: string = '';
  public current_password: string;
  public re_password: string;
  public new_password: string;
  public current_password_msg: string;
  public match_password_msg: string;
  constructor(public global: Globals, private http: HttpClient, private cookieService: CookieService, private router: Router) {
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });
  }

  ngOnInit() {
  
    let user = JSON.parse(localStorage.getItem('user')).user_info;
    if(!user)
    {
      this.router.navigate(['/']);
    }
    this.getPageData();
  }


  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "user" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          console.log(responseData);
          //console.log("Local Storage");
          //console.log(JSON.parse(localStorage.getItem('user')));
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
          //console.log(LOCALSTORAGE);
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;
          console.log(this.global.country);
          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
          console.log(this.pageData);
          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }


  //======================CHANGE PASSWORD-===========//
  checkPassword  () {
    let ctrlName = JSON.parse(localStorage.getItem('user')).user_info;
    if(this.current_password =='')
    {
      this.current_password_msg = "Please enter current password";
      return false;
    }
    var formdata = { password: this.current_password };
   
    this.http.post(this.BASE_URL + 'api/'+ctrlName+'/getPassword',
      formdata,
      {
        headers: this.headers
      }).subscribe(
        response => {
          console.log(response);
          this.current_password_msg = '';
          return false;

        },
        error => {
          this.current_password_msg = error.error.message;
          this.current_password = '';

          return false;
        });

  };
  matchPssword () {
   
    if (this.new_password !== this.re_password) {

      this.match_password_msg = "Password is not matched with new password";
      this.new_password = '';
      this.re_password = '';
    }
    else {

      this.match_password_msg = '';

    }
  };
  beforesend()
  {
    console.log("gello");
    this.checkPassword();
    this.matchPssword();
  }
  changePassword  () {

    let ctrlName = JSON.parse(localStorage.getItem('user')).user_info;
    this.checkPassword();
    this.matchPssword();

    if (this.current_password_msg=="" || this.new_password == '' || this.re_password == '') {
      this.message = "Please enter password";
      return false;
    }
    else {
      this.message = "";
    }
    

    this.http.post(this.BASE_URL + 'api/'+ctrlName+'/setPassword',
      { 'password': this.new_password },
      {
        headers: this.headers
      }).
      subscribe(
        response => {
          console.log(response);
          let tmpResponse:any = response;
          this.message = tmpResponse.message;
          this.router.navigate(['logout']);
        },
        error => {
          return false;
        });

  };






}
