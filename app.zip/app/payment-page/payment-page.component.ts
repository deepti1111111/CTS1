import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { NotifierService } from "angular-notifier";

/**
 * 
 * {"term_yearly":"318.84",
 * "subscription_type":
 * "Standard","subscription_term":"monthly",
 * "total_fee":"318.84",
 * "Subject":"monthly subsciption for usrss",
 * "user_type":"this.user_type",
 * "term":"one"}
 * 
 * 
 */
@Component({
  selector: 'app-payment-page',
  templateUrl: './payment-page.component.html',
  styleUrls: ['./payment-page.component.css']
})
export class PaymentPageComponent implements OnInit {

  private readonly notifier: NotifierService;

  public pageData: any = { msg:'',card_number: 'Rides', exp_month: 'Search', exp_year: 'Seach', cvv: 'List Of Rides', name_on_card: 'Start Date', email: 'End Date', term_condition: 'Show Item', submit: 'Select All', cancel: 'Cancel', description: 'Description', amount: 'Amount', currency: 'Currency' };
  public subscriptionRouteData: any = {};
  public subscribed: boolean = false;
  public payment_mode = "Credit card";
  public TOKEN: string = "";
  error = new Subject<string>();
  public config: any;
  public BaseUrl: string;
  public user_type = "";

  public headers: any = {};
  public is_edit: boolean = false;
  public BASE_URL: string = '';
  public paymentMethodDetails: any;
  public paymentMethods: any;
  public subscriptionMessage: string = '';

  //=========== card entry-=================//
  public card_number: string = "4242424242424242";
  public exp_month: string = "02";
  public exp_year: string = "2025";
  public cvv: string = "185";
  public name_on_card: string = "METRO TAXI";
  public email: string = "deepti@chawtechsolutions.com";
  public term_condition: string = "";
  public alipay_subscription_desc: string = "";
  public alipay_amount: string = "";
  public currency: string = "";
  public alipay_transaction_link: string = "";
  public alipay_transaction: any = "";
  public msg: string


  constructor(public global: Globals,
    private http: HttpClient,
    private cookieService: CookieService,
    public _router: ActivatedRoute,
    public router: Router,
    notifier: NotifierService) {
    this.notifier = notifier;
    this.subscriptionRouteData = JSON.parse(this._router.snapshot.params['info']);
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;
    this.user_type = JSON.parse(localStorage.getItem('user')).user_info;  

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });
  }
  
  
  ngOnInit() {
    this.alipay_transaction_details();

  }

  public showSpecificNotification(type: string, message: string): void {
    this.notifier.notify(type, message);
  }

  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "payment_page" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          console.log(responseData);
          //console.log("Local Storage");
          //console.log(JSON.parse(localStorage.getItem('user')));
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
          //console.log(LOCALSTORAGE);
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;
          console.log(this.global.country);
          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
          console.log(this.pageData);
          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  alipay_transaction_details = function () {

    this.alipay_subscription_desc = this.subscriptionRouteData.Subject;
    this.term = this.subscriptionRouteData.subscription_term;
    this.currency = this.subscriptionRouteData.currency;
    this.alipay_amount = Math.round(this.subscriptionRouteData.term_yearly);
    this.subscription_type = this.subscriptionRouteData.subscription_type;
    this.subscription_term = this.subscriptionRouteData.subscription_term;
    let car_range:string = "";
    if(this.subscriptionRouteData.car_range)
    {
      car_range = this.subscriptionRouteData.car_range;
    }

    console.log("subscriptionRouteData");
    console.log(this.subscriptionRouteData);
    let formdata: any = {
      body: "Subcription plan",
      currency: this.currency,
      subscription_type: this.subscription_type,
      subscription_term: this.subscription_term,
      total_fee: this.alipay_amount,
      subject: this.alipay_subscription_desc,
      user_type: this.user_type,
      term: this.subscription_term,
      portal:'pwa',
      car_range:car_range
    };



    console.log(formdata)

    this.http.post(this.BASE_URL + 'api/payment/alipayTransactiion', formdata, {
      headers: this.headers
    }).
      subscribe(
        response => {
          console.log(response);
          this.alipay_transaction_link = response.data;
          return false;

        },
        error => {
          console.log(error);
          return false;
        });


  };

  submitForm = function () {
    let car_range:string = "";
    if(this.subscriptionRouteData.car_range)
    {
      car_range = this.subscriptionRouteData.car_range;
    }
    var formdata = {
      card_number: this.card_number,
      name_on_card: this.name_on_card,
      cvv: this.cvv,
      expiry_month: this.exp_month,
      expiry_year: this.exp_year,
      //term_condition: this.term_condition,
      payment_mode: this.payment_mode,
      email: this.email,
      amount: this.alipay_amount,
      total_amount: this.alipay_amount,
      currency: this.currency,
      subscription_term: this.subscription_term,
      subscription_type: this.subscription_type,
      car_range:car_range
    };

    //console.log(formdata); return false;
    var api_method = "stripeCardPayment";

    this.http.post(this.BASE_URL + 'api/payment/' + api_method, formdata, {
      headers: this.headers
    }).
      subscribe(
        response => {
          this.msg = response.message;
          this.showSpecificNotification('success', "Payment is successful");
          this.router.navigate([this.user_type+'-subscription']);
          
          
        }, function errorCallback(response) {
          this.showSpecificNotification('error', 'Something went wrong');
          return false;
        });
  };


  

  isNumberKey(idx: any, val: any) {
    console.log(val);
    var regex = /^[0-9]*(?:\.\d{1,2})?$/;    // allow only numbers [0-9] 
    if (!regex.test(val)) {

      if (idx == 'card_number') {
        this.card_number = '';
      }
      else if (idx == 'expiry_month') {
        this.exp_month = '';
      }
      else if (idx == 'expiry_year') {
        this.exp_year = '';
      }
      else if (idx == 'cvv') {
        this.cvv = '';
      }


    }
  }


}
