import { Component, OnInit ,ViewChild,ElementRef} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Globals } from '../global';
import { FormsModule, FormControl, Validators } from '@angular/forms';
import { Subject, throwError, Observable } from 'rxjs';
import { $ } from 'protractor';
import { NavComponent } from '../nav/nav.component';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { NotifierService } from "angular-notifier";
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-registration-controlcenter',
  templateUrl: './registration-controlcenter.component.html',
  styleUrls: ['./registration-controlcenter.component.css']
})
export class RegistrationControlcenterComponent implements OnInit {
  
  modalRef: BsModalRef; 
  @ViewChild('mobileVerification', { static: true }) mobileVerification: ElementRef;
  
  //===============================================//


  // toggle webcam on/off
  public showWebcamProfileImage = false;
  public showWebcamIdImage = false;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];
  // latest snapshot
  public webcamImage: WebcamImage = null;

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();

  private readonly notifier: NotifierService;


  //================================================//
  public country: string;
  public user = { email: "", password: "", fcm_key: "pwa" };
  public pageCompanyRegData = {company_vat_tax:'',company_business_lic_no:'',company_taxi_lic_no:'',company_name:'', back_button: "Retour", business_connection: "Relation d'affaires", city: "Ville / municipalité", country: "Pays", customer_number: "Numéro de client (généré automatiquement)", date_of_change: "Date de changement", date_of_create: "Date de création", dialing_code: "Code de composition", email: "Email", email_verification_code: "Lien de vérification de courrier électronique", first_name: "Prénom", fisrt_name: "First Name", floor: "Sol", form_title: "Formulaire d'inscription Adhésion client / sur demande", further_information: "Informations complémentaires", house: "Numéro de maison / appartement", id_card: "Carte d'identité", last_name: "Nom de famille", location_of_change: "Lieu de changement", location_of_create: "Lieu de création", mobile_number: "Numéro de portable", mobile_verification_code: "Code de vérification mobile", nationality: "Nationalité", password: "Mot de passe", password_repeat: "Répéter le mot de passe", payment_methods: "Sélectionnez les modes de paiement", state: "Province / État fédéral", street_name: "Nom de rue", street_number: "Numéro de rue", submit_button: "Soumettre", take_a_picture: "Prendre une photo", take_an_id: "Prendre un identifiant", time_of_change: "Temps de changement", time_of_create: "Temps de création", upload_a_picture: "Télécharger une image", upload_an_id: "Télécharger un identifiant", upload_picture: "Charger une photo", username: "Nom d'utilisateur", verification: "Vérification", zip: "zip", };
  public response: any;
  public tmp: any;
  public countryList: any;
  public mobileError: string;
  public message: string;
  public mobileOTP: string = "";

  public password_err: string = "";
  public password_err1: string = "";

  public zipErr:string = "";
  public first_nameErr:string = "";
  public last_nameErr:string = "";
  public license_plateErr:string = "";
  public company_nameErr:string="";
  
  public dialing_codeErr:string = "";
  public imageErr:string = "";
  public id_proof_imageErr:string = "";
  public id_cardErr:string = "";
  public driver_emp_noErr:string = "";
  public stateErr:string= "";
  public cityErr:string="";

  public mobile_verification_code: string = "";

  public businessConnection: any = {};
  public businessConnectionlist: any;
  public fileToUpload: File = null;
  public regForm = {
    id: '',
    image: 'APAAkAA920200602203543.jpg',
    id_proof_image: '9AAkPAAA20200602203544.jpg',
    business_connection_type:'1',
    company_name: 'ABC company',
    first_name: 'Deepti',
    last_name: 'Srivastava',
    username: '',
    id_card: 'DP001',
    password: 'Test@123',
    password_repeat: 'Testt@123',
    country: 'CN China',
    nationality: 'Chinese',
    state: 'Uttar Pradesh',
    city: 'Noida',
    zip: '201301',
    street_number: '3',
    street_name: 'ABBB',
    house: '2',
    floor: '4r',
    further_information: 'Description is the pattern of narrative development that aims to make vivid a place, object, character, or group. Description is one of four rhetorical modes, along with exposition, argumentation, and narration. In practice it would be difficult to writ',
    email: 'pwatestcompany01@yopmail.com',
    dialing_code: '+91',
    mobile_number: '8922080680',
    company_vat_tax: 'wss',
    driver_emp_no: '1wwww',
    social_ins_num: 'fd2233',
    license_plate: 'AD3332',
    vehicle_type: '1',
    company_business_lic_no: 'dsffg',
    company_taxi_lic_no: '2222',
    email_verification_link: false,
    mobile_verification_code: true,
    is_mobile_verified: '1',
    date_of_create: '',
    time_of_create: '',
    location_of_create: '',
    date_of_change: '',
    time_of_change: '',
    location_of_change: '',
    role: 'company',
    payment_methods: ['1']
  };

  public email_alert: any = '';
  public mobile_number_alert: any = '';

  public BaseUrl: any = '';
  public BASE_URL: any = '';
  public company_vat_taxErr:string = "";
  public company_business_lic_noErr:string = "";
  public company_taxi_lic_noErr:string = "";
  

  constructor( private modalService: BsModalService,notifierService: NotifierService,private router: Router, public global: Globals, private http: HttpClient, private cookieService: CookieService) {

    //this.getCountry();
    this.notifier = notifierService;
    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
  }
  error = new Subject<string>();
  ngOnInit() {
    this.getCompanyRegPageData();
    this.getBusinessConnection();
  }

  getCompanyRegPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "Company Registration" }
    )
      .subscribe(
        responseData => {
          this.tmp = responseData;
          var cookie = JSON.parse(this.cookieService.get('language_code'));
          this.global.country = cookie.language;
         
          if (this.global.country == 'en') {
            this.pageCompanyRegData = this.tmp.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageCompanyRegData = this.tmp.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageCompanyRegData = this.tmp.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageCompanyRegData = this.tmp.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageCompanyRegData = this.tmp.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageCompanyRegData = this.tmp.data.content_es;
          }
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  handleFileInput(files: FileList, FileName: string) {
    //console.log(FileName);
    this.fileToUpload = files.item(0);
    const formData: FormData = new FormData();
    formData.append('file', this.fileToUpload, this.fileToUpload.name);
    formData.append('data', 'company');
    this.http.post(
      this.global.APIURL + "api/companies/auth/uploadImage",
      formData
    )
      .subscribe(
        responseData => {
          //console.log(responseData);    
          this.tmp = responseData;
          if (FileName == 'image') {
            this.regForm.image = this.tmp.file_name;
          }
          else if (FileName == 'id_proof_image') {
            this.regForm.id_proof_image = this.tmp.file_name;
          }
          //console.log(this.regForm); 
        },
        error => {
          //console.log(error.message)
          this.error.next(error.message);
        }
      );
  }
  verifyOTP() {
   
    this.mobileError = "";
    this.message = "";
    if(this.mobile_verification_code.length == 5 )
    {
       if (this.mobileOTP.trim() != this.mobile_verification_code.trim()) {
        this.mobileError = "Code does not matched";       
       
      }
      else
      {        
        this.message = "Mobile number verified successfully";
       
        this.modalRef.hide(); 
        this.onSubmit();
      }
    }
    
  }
  checkPasswords(pass: string, confirmPass: string) { // here we have the 'passwords' group
    return pass === confirmPass ? null : { notSame: true }
  }

  validationInputPwdText(value: string) {
    this.password_err = "";
    var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
    if (value.match(decimal)) {
      this.password_err = "";

    } else {
      this.regForm.password = '';
      this.password_err = "Passwords must contain at least 8 characters, including uppercase, lowercase letters, special characters and numbers.Password";
    }
  };

  confirmPass(value1: string, value2: string) {

    this.password_err1 = "";

    if (value1 == value2) {
      this.password_err1 = "";
      console.log(value1 + "," + value2);

    } else {
      this.password_err1 = "Passwords must be matched";
    }
  };
  
  getBusinessConnection() {
    var formdata = { connection_for: 'company' };

    this.http.post(this.BASE_URL + 'api/general/businessConnection', formdata, {}).
      subscribe(
        response => {
          let tmpResponse: any = response;

          this.businessConnection = tmpResponse.data;
        //  this.regForm.business_connection_type = this.businessConnection[0].id;
          this.businessConnectionlist = tmpResponse.data1;

          if (this.regForm.id) {
          }
          return false;
        }, err=> {
          return false;
        });
  };

  

  formValidateCheck()
  {  
  
    this.first_nameErr = "";
    this.license_plateErr="";
    this.last_nameErr = "";
    this.email_alert = "";
    this.mobile_number_alert = "";
    this.dialing_codeErr = "";
    this.imageErr = "";
    this.id_proof_imageErr = "";
    this.id_cardErr = "";
    this.company_nameErr="";
    this.company_vat_taxErr = "";
    this.company_business_lic_noErr = "";
    this.company_taxi_lic_noErr = "";
   
    
    
    this.zipErr = "";
    
    let result :boolean=true;

    this.password_err = "";
    if(this.regForm.company_name.trim()=='')
    {
      this.company_nameErr = "Please enter company name";
      result =  false;
    }
    if(this.regForm.password.trim()=='')
    {
      this.password_err = "Please enter password";
      result =  false;
    }
    
    this.password_err1 = "";
    if(this.regForm.password_repeat=='')
    {
      this.password_err1 = "Please enter password repeat";
      result =  false;
    }
    this.stateErr ="";
    if(this.regForm.state=='')
    {
      this.stateErr = "Please enter Province / Federal State";
      result =  false;
    }
    this.cityErr ="";
    if(this.regForm.city=='')
    {
      this.cityErr = "Please enter City / Municipality";
      result =  false;
    }
    this.first_nameErr = "";
    if(this.regForm.first_name=='')
    {
      this.first_nameErr = "Please enter first name";
      result =  false;
    }
    if(this.regForm.last_name=='')
    {
      this.last_nameErr = "Please enter last name";
      result =  false;
    }
    if(this.regForm.id_card=='')
    {
      this.id_cardErr = "Please enter ID card number";
      result =  false;
    }
   
    if(this.regForm.email=='')
    {
      this.email_alert = "Please enter valid email ID";
      result =  false;
    }
    if(this.regForm.mobile_number=='')
    {
      this.mobile_number_alert = "Please enter mobile number";
      result =  false;
    }
    if(this.regForm.dialing_code=='')
    {
      this.dialing_codeErr = "Please enter dialing code";
      result =  false;
    }
    if(this.regForm.zip=='')
    {
      this.zipErr = "Please enter Zip/Postal code";
      result =  false;
    }
    /** image: 'face-image.png',
    id_proof_image: 'identity-image.png', */
    if( this.regForm.image== "face-image.png")
    {
      this.imageErr = "Please upload picture";
      result =  false;
    }
    if( this.regForm.id_proof_image == "identity-image.png")
    {
      this.id_proof_imageErr = "Please upload ID proof";
      result =  false;
    }
    if(this.regForm.company_taxi_lic_no == "")
    {
      this.company_taxi_lic_noErr = "Please enter company taxi license no ";
      result = false;
    }
    
     if(this.regForm.company_business_lic_no == "")
    {
      this.company_business_lic_noErr = "Please enter company business lic No";
      result = false;
    }
     if(this.regForm.company_vat_tax == "")
    {
      this.company_vat_taxErr = "Please enter company vat tax";
      result = false;
    }
    return result;
  
  }


  onSubmit() {
    if (  this.mobile_verification_code.trim() == "") {
      this.modalRef = this.modalService.show(this.mobileVerification,{backdrop:'static', keyboard:false});
  
    }
    else{
      //this.modalRef.hide();
    }
    
    if (!this.formValidateCheck()) {
      return false;
    }
    else if (this.regForm.mobile_verification_code == true  && this.mobileOTP == "") {
      console.log();

      this.http.post(
        this.global.APIURL + "api/general/sendSms",
        { dialing_code: this.regForm.dialing_code, mobile_number: this.regForm.mobile_number }
      )
        .subscribe(
          responseData => {
            var res: any;
            res = responseData;
            var data = JSON.parse((res.data));
            console.log(data);
            if (data.errors) {
              this.mobileError = data.errors[0].description;
            }
            else if (data.body) {
              this.mobileOTP = data.body;
              console.log(this.mobileOTP);
             /// this.message = "Verified successfully";

            }
          },
          error => {
            this.mobileError=error.error.error;
            console.log(error.message)
            this.error.next(error.message);
            return false;

          }
        );
    }
    else if (this.regForm.mobile_verification_code == true && this.mobileOTP == this.mobile_verification_code) {
      this.http.post(
        this.global.APIURL + "api/companies/auth/signup",
        this.regForm
      )
        .subscribe(
          responseData => {
            var res: any;
            res = responseData;
            if (res.message) {
              this.notifier.notify("success", res.message);
              //alert(res.message);
              setTimeout(()=>{
                  this.router.navigate(['/login']).then(() => {
                   });
                }, 5000
              );
            }
          },
          error => {
            console.log(error.message)
            this.error.next(error.message);
          }
        );
    }
  }


  search = function (idx: any, value: any) {
    var ins = idx;
    this.email_alert = '';
    this.mobile_number_alert = "";
    var formdata: any = {};
    if (idx == "email") {
      if (value == '') {
        this.email_alert = 'Please enter valid email address';
        return false;
      }
      if (!this.global.ValidateEmail(value)) {
        this.email_alert = 'Please enter  a valid email address';
        this.regForm.email = '';
        return false;
      }
      formdata = { email: value, user_type: "user" };
    }
    else if (idx == "mobile_number") {
      if (value == '') {
        this.mobile_number_alert = 'Please enter valid Mobile number';
        return false;
      }
      formdata = { mobile_number: value, user_type: "user" };
    }
    var api_method = 'search';
    this.http.post(this.BASE_URL + 'api/general/' + api_method, formdata, {
    }).
      subscribe(
        response => {

          if (idx == "email") {
            this.email_alert = 'Email already exists';
            this.regForm.email = '';
          }
          else if (idx == "mobile_number") {
            this.mobile_number_alert = 'Mobile number already exists';
            this.regForm.mobile_number = '';
          }
          this.mobile_number_alert
          return false;

        },
        error => {
          return false;
        });

  }



  isNumberKey(idx: any, val: any) {
    // console.log(val);
    var regex = /^[0-9]*(?:\.\d{1,2})?$/;    // allow only numbers [0-9] 
    if (!regex.test(val)) {
      //console.log(this.regForm);
      if (idx == 'zip') {
        this.regForm.zip = '';
      }
      else if (idx = 'mobile_number') {
        this.regForm.mobile_number = '';
      }

    }
  }



  //========= web cam codes================//

  openCam(imageType: string) {
    if (imageType == 'profile_picture') {
      this.showWebcamProfileImage = true;
      this.showWebcamIdImage = false;
    }
    else {
      this.showWebcamProfileImage = false;
      this.showWebcamIdImage = true;
    }
  }
  saveTofile(snapshotData: any, uploadfr: any) {    
    var formdata = { data: snapshotData, user_type: 'user' };
    this.http.post(this.BASE_URL + 'api/general/base64Tojpeg', formdata, {
    }).
      subscribe(
        response => {
          let tmpResponse: any = response;
          if (uploadfr == "image") {
            this.regForm.image = tmpResponse.data;
            this.showWebcamProfileImage = false;
          }
          else {
            this.regForm.id_proof_image = tmpResponse.data;
            this.showWebcamIdImage = false;
          }
          //this.regForm.location_of_change  = response.data.location;
          return false;

        },
        error => {
          console.log(error);
          return false;
        });
  }


  public triggerSnapshot(): void {
    this.trigger.next();
  }


  public handleInitError(error: WebcamInitError): void {
    this.errors.push(error);
  }

  public showNextWebcam(directionOrDeviceId: boolean | string): void {
    // true => move forward through devices
    // false => move backwards through devices
    // string => move to device with given deviceId
    this.nextWebcam.next(directionOrDeviceId);
  }

  public handleImage(webcamImage: WebcamImage): void {
    console.info('received webcam image', webcamImage);
    this.webcamImage = webcamImage;
    if (this.showWebcamProfileImage) {
      this.saveTofile(this.webcamImage.imageAsDataUrl, 'image');
      //triggerObservable
    }
    else {
      this.saveTofile(this.webcamImage.imageAsDataUrl, 'id');
    }
  }

  public cameraWasSwitched(deviceId: string): void {
    console.log('active device: ' + deviceId);
    this.deviceId = deviceId;
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public get nextWebcamObservable(): Observable<boolean | string> {
    return this.nextWebcam.asObservable();
  }




}
