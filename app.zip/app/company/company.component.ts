import { Component, OnInit, Directive, Input, ViewChild, ElementRef, TemplateRef, ContentChild } from '@angular/core';
import { BehaviorSubject, Observable, interval } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { FormsModule } from '@angular/forms';
import { Subject, throwError, timer } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

import { take } from 'rxjs/operators';
declare var H: any;

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
  private platform: any;

  public config: any;
  error = new Subject<string>();
  public BASE_URL: string;
  public base_url: string;
  public BaseUrl: string;
  public headers: any;
  public pageData: any = { standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public TOKEN: any;

  public subsciptionStatusmessage:string = "";
  public company:any = {};
  public companyDriverList:any = [];
  public driver:any={};
  public companyDriverOtherList:any;


  @ViewChild("map", { static: true }) public mapElement: ElementRef;

  private map: any;
  public general_location: any = {
    start_location: '',
    start_latlng: { 'lat': 23.33, 'lng': 72.44 },
    end_location: '',
    end_latlng: { 'lat': 23.33, 'lng': 72.44 }
  };


  public ui: any;
  public pixelRatio: any;
  public defaultLayers: any;
  closeResult: string;

  constructor(public global: Globals, private modalService: BsModalService, private http: HttpClient, private cookieService: CookieService, private router: Router) {
    this.platform = new H.service.Platform({
      "app_id": this.global.HAppId,
      "app_code": this.global.HAppCode,
      useHTTPS: true
    })
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });

    this.base_url = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;

  }

  //Company home
  ngOnInit() {
    this.getPageData() ;
    this.getLocation();
    
    console.log(this.pageData);
    this.getSubscriptionStatus();
    this.getprofile();

    this.getActiveOtherDriverList();

    this.getActiveDriverList();

    this.home_page_key();
    this.home_page();//set data to dashboard

  }

  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "Company home" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));

          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }

          this.global.setPageData(this.pageData);
         
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  
  getprofile () {
    

    this.http.get(this.BASE_URL + 'api/company/profile', {
      headers: this.headers
    }).subscribe(response=> {
      let tmpResponse :any=response;
      this.company = tmpResponse.data;
     
      //return false;

      if (this.company.status == "0") {
        this.router.navigate(['logout']);
      }
      if (this.company.live_status == "0") {
        this.router.navigate(['logout']);
      }
      return false;

    }, function errorCallback(response) {
      return false;
    });
  };
  getSubscriptionStatus () {
    var api_method = 'subsciptionStatus';
    this.http.get(this.BASE_URL + 'api/company/' + api_method, {
      headers: this.headers
    }).subscribe(response=> {
      let tmpResponse :any=response;
      this.subsciptionStatusmessage = tmpResponse.message;
      if (tmpResponse.status) {
     //   $("#TailSubscription").modal("hide");
      }
      else {
       // $("#TailSubscription").modal("show");
      }
      return false;
    }, function errorCallback(response) {
      return false;
    });
  };
  getActiveDriverList () {
    this.http.get(this.BASE_URL + 'api/companies/service/getActiveDriverList', {
      headers: this.headers
    }).subscribe(response=> {
      let tmpResponse :any=response;
      this.companyDriverList = tmpResponse.data;
      this.addInfoBubble(this.map, '', '', this.companyDriverList);

    }, function errorCallback(response) {
      return false;
    });
    return false;
  };
  addInfoBubbleOtherDrivers = function (user_detail)
    {

        var group = new H.map.Group();

        this.map.addObject(group);

        group.addEventListener('tap', function (evt) {

            var bubble = new H.ui.InfoBubble(evt.target.getGeometry(), {
                // read custom data

                content: evt.target.getData()

            });

            this.ui.addBubble(bubble);

        }, false);

        if (user_detail)
        {

            for (var i = 0; i < user_detail.length; i++)
            {

                var driver = user_detail[i];

                if (true){

                    var strInforWindow = ' <div  class="form-group" id="strInforWindow_div"><label style="color:#000;"> Metro Taxi Driver</label>' +
                            '<div style="clear:both"></div></div>';

                    this.addMarkerToGroup(group, {lat: driver.latitude, lng: driver.longitude}, strInforWindow);

                }
            }

        }



    };

    
    /**
     * Creates a new marker and adds it to a group
     * @param {H.map.Group} group       The group holding the new marker
     * @param {H.geo.Point} coordinate  The location of the marker
     * @param {String} html             Data associated with the marker
     */
    addMarkerToGroup (group, coordinate:any, html:string) {
      var svgMarkup = '<svg width="24" height="24" ' +
              'xmlns="http://www.w3.org/2000/svg">' +
              '<rect stroke="white" fill="#1b468d" x="1" y="1" width="22" ' +
              'height="22" /><text x="12" y="18" font-size="12pt" ' +
              'font-family="Arial" font-weight="bold" text-anchor="middle" ' +
              'fill="white">D</text></svg>';
      var icon = new H.map.Icon(svgMarkup);
      var marker = new H.map.Marker(coordinate, {icon: icon});
      // add custom data to the marker
      marker.setData(html);
      group.addObject(marker);
  };



    addInfoBubble(map:any, lat:string, lng:string, user_detail:any) {

        var user_type = "driver";
        var htmlStr = "";
        user_type = 'user';

        htmlStr = '<div>' + user_type +
                'Your Location:' +
                '</div>' +
                '<div >' + '' + '</div>';

        var group = new H.map.Group();

        map.addObject(group);

        // add 'tap' event listener, that opens info bubble, to the group

        group.addEventListener('tap', function (evt) {

            // event target is the marker itself, group is a parent event target

            // for all objects that it contains

            var bubble = new H.ui.InfoBubble(evt.target.getGeometry(), {
                // read custom data

                content: evt.target.getData()

            });

            // show info bubble

            this.ui.addBubble(bubble);

        }, false);



        if (user_detail.role && user_detail.role == 'user')

        {

            user_type = 'user';

            htmlStr = '<div>' +
                    'Your Location:' +
                    '</div>' +
                    '<div >' + this.general_location.start_location + '</div>';
        }

        else {

            if (user_detail) {
                user_type = "driver";
                if (user_detail){
                    for (var i = 0; i < user_detail.length; i++)

                    {



                        htmlStr = "<div>Driver Details </div>";



                        var dLat = user_detail[i].latitude;

                        var dLng = user_detail[i].longitude;

                        this.driver = user_detail[i];

                        var address = this.driver.house + ", " + this.driver.floor + ", " + this.driver.street_name + ", " + this.driver.city + ", " + this.driver.state + ", " + this.driver.zip;



                        var strInforWindow = ' <div  class="form-group" id="strInforWindow_div"> ' +
                                '<span class="driver-image" id="strInforWindow_img">' + '<img src="' + this.BASE_URL + 'uploads/driver/' + this.driver.image + '" height="20" width="20"></span>' +
                                '<ul class="infoWindowStyle">' +
                                '<li><i class="fa fa-id-card" aria-hidden="true"></i>' + this.driver.id_card + ' </li>' +
                                '<li><i class="fa fa-user" aria-hidden="true"></i>' + this.driver.first_name + ' ' + this.driver.last_name + ' </li>' +
                                '<li><i class="fa fa-car" aria-hidden="true"></i> ' + this.driver.license_plate_no + ' </li> ' +
                                '<li><i class="fa fa-phone" aria-hidden="true"></i>' + this.driver.mobile_number + '  </li>' +
                                '<li><i class="fa fa-id-card-o" aria-hidden="true"></i>' + this.driver.driver_company_busness_lic + '  </li>' +
                                '<li><i class="fa fa-home" aria-hidden="true"></i>' + address + '  </li>' +
                                '</div>';

                        this.addMarkerToGroup(group, {lat: dLat, lng: dLng}, strInforWindow);

//                        addMarkerToGroup(group, {lat: dLat, lng: dLng}, compiled[0]);

                    }
                }
            }
            else  {
              user_type = "";
            }
        }

    }
  getActiveOtherDriverList () {
    this.http.get(this.BASE_URL + 'api/companies/service/getActiveOtherDriverList', {
      headers: this.headers
    }).subscribe(response=> {
      let tmpResponse:any = response;
      this.companyDriverOtherList = tmpResponse.data;
      this.addInfoBubbleOtherDrivers(this.companyDriverOtherList);
    }, function errorCallback(response) {
      return false;
    });
    return false;
  };
  getLocation () {
    var formdata = {status:1};
    var api_method = 'getLocation';
    this.http.post(this.BASE_URL + 'api/general/' + api_method, formdata, {
    }).subscribe(response=> {
      console.log(response);
      return false;

    }, function errorCallback(response) {
      return false;
    });

  };
  public total_revenue:string;
  public total_booking:string;
  public total_cars:string;
  public total_driver:string;
  public total_active_driver:string;
  
  home_page () {
    
    this.http.get(this.BASE_URL + 'api/companies/service/getTripStats', {
      headers: this.headers
    }).subscribe(response=> {
      let tmpResponse:any = response;
      this.total_revenue = tmpResponse.data[0];
      this.total_booking = tmpResponse.data[1];
      this.total_cars = tmpResponse.data[2];
      this.total_driver = tmpResponse.data[3];
      this.total_active_driver = tmpResponse.data[4];
      return false;
    }, function errorCallback(response) {
      return false;
    });
  };
  home_page_key () {
  };

  public ngAfterViewInit() {

    this.pixelRatio = window.devicePixelRatio || 1;
    this.defaultLayers = this.platform.createDefaultLayers();

    this.map = new H.Map(this.mapElement.nativeElement,
      this.defaultLayers.normal.map, { pixelRatio: this.pixelRatio });

    var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(this.map));
    var ui = H.ui.UI.createDefault(this.map, this.defaultLayers);

    this.map.setCenter({ lat: this.general_location.start_latlng.lat, lng: this.general_location.start_latlng.lng });
    this.map.setZoom(14);

    var marker = new H.map.Marker({ lat: this.general_location.start_latlng.lat, lng: this.general_location.start_latlng.lng });
    // add custom data to the marker

    this.map.addObject(marker);


  }

}
