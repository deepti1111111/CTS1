import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Globals } from '../global';
import { Subject, throwError, Observable } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { NotifierService } from "angular-notifier";

@Component({
  selector: 'app-advertisement',
  templateUrl: './advertisement.component.html',
  styleUrls: ['./advertisement.component.css']
})
export class AdvertisementComponent implements OnInit {

  public posted: boolean = false;
  public success: boolean = false;
  public fail: boolean = false;
  public BaseUrl: string = '';
  public BASE_URL: string = '';
  public response: any;
  public responseData: any;
  public tmp: any;
  public countryList: any;
  public terms: any = { daily: 'Day(s)', monthly: 'Month(s)', yearly: 'Year(s)' };
  public terms_count: number = 1;
  public pageData: any = { succes: '', fail: '', first_name: 'Contact Us', last_name: 'Login', title: 'Home', select_plan: '', email: 'Service', mobile_number: 'Password', website_url: 'Create New Account', add_image: 'Login', heading: 'heading' };
  public general: any = { first_name: "", last_name: "", image: "", email: "", mobile_number: "", payment_mode: "offline", payable_amount: "1", advertisement_plan_id: 3, advertisement_plan_term: "daily", link_url: "", title: "", term_count: '1' };
  public advertisement_plan: any = {};

  public fileToUpload: File = null;
  public imageerr :string = "";
  public emailerr :string = "";
  public mobileerr:string="";
  public urlerr :string = "";
  private readonly notifier: NotifierService;
  constructor(public global: Globals, private http: HttpClient, notifierService: NotifierService, private cookieService: CookieService, private router: Router) {

    this.getCountry();
    this.notifier = notifierService;
    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
  }
  error = new Subject<string>();

  ngOnInit() {
    this.getPageData();
    this.getAdvetisementPlan();
  }

  getCountry() {
    this.http.get(this.global.APIURL + "api/general/languageList").subscribe(
      responseData => {
        this.global.setCountryList(responseData);
        this.countryList = responseData;
        this.countryList = this.countryList.data;
      },
      error => {
        this.error.next(error.message);
      }
    );
  }
  getPageData() {
    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "advertisementhome" }
    )
      .subscribe(
        responseData => {

          this.tmp = responseData;
          var cookie = JSON.parse(this.cookieService.get('language_code'));
          this.global.country = cookie.language;

          if (this.global.country == 'en') {
            this.pageData = this.tmp.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.tmp.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.tmp.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.tmp.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.tmp.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.tmp.data.content_es;
          }

        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getAdvetisementPlan() {

    this.http.get(
      this.global.APIURL + 'api/general/getAdvertisementPlan')
      .subscribe(responseData => {
        let tmpResponse: any = responseData;
        this.advertisement_plan = tmpResponse.data;

        this.general.advertisement_plan_id = this.advertisement_plan.id;
      },
        error => {
          this.error.next(error.message);
        }
      );
  }
  onFileChanged(event) {
    const file = event.target.files[0];

  }
  handleFileInput(files: FileList, FileName: string) {

    this.fileToUpload = files.item(0);
    const formData: FormData = new FormData();
    formData.append('file', this.fileToUpload, this.fileToUpload.name);
    formData.append('data', 'ads');
    this.http.post(
      this.global.APIURL + "api/users/auth/uploadImage",
      formData
    )
      .subscribe(
        responseData => {

          this.tmp = responseData;
          this.general.image = this.tmp.file_name;

        },
        error => {

          this.error.next(error.message);
        }
      );
  }

  getPayable() {
    let tmpPayable_amount: number = 0;

    if (this.general.advertisement_plan_term == 'daily') {
      tmpPayable_amount = this.advertisement_plan.daily * this.general.term_count;
    }
    if (this.general.advertisement_plan_term == 'monthly') {
      tmpPayable_amount = this.advertisement_plan.monthly * this.general.term_count;
    }
    if (this.general.advertisement_plan_term == 'yearly') {
      tmpPayable_amount = this.advertisement_plan.yearly * this.general.term_count;
    }
    this.general.payable_amount = tmpPayable_amount;
  }
  onSubmit() {
    this.emailerr = "";
    this.mobileerr="";
    this.imageerr = "";
    this.urlerr = "";    
    let flag:boolean = true;    
    if(this.general.email == "")
    {
      this.emailerr = "Please enter email";
      flag = false;
    }
    if(this.general.image == "")
    {
      this.imageerr = "Please select image";
      flag = false;
    }
    if(this.general.link_url == "")
    {
      this.urlerr = "Please enter your website url";
      flag = false;
    }
    
    if(!this.global.ValidateEmail(this.general.email))
    {
      this.emailerr = "Please enter a valid emailID";
      flag = false;
    }
    if(this.general.mobile_number != "" && !this.global.phonenumber(this.general.mobile_number))
    {
      this.mobileerr = "Please enter a valid mobile number";
      flag = false;
    }//phonenumber
    if(!flag)
    {
      return false;
    }
    
    this.http.post(
      this.global.APIURL + "api/general/advertisementRequest",
      this.general
    )
      .subscribe(
        responseData => {
          var res: any;
          res = responseData;
          this.general = { first_name: "", last_name: "", image: "", email: "", mobile_number: "", payment_mode: "offline", payable_amount: "1", advertisement_plan_id: 3, advertisement_plan_term: "daily", link_url: "", title: "", term_count: '1' };
          if (res.message) {
            this.notifier.notify("success", res.message);
          }
          this
          return false;
        },
        error => {
          this.error.next(error.message);//error
          this.notifier.notify("error", error.error.error);
        }
      );
    return false;;
  }
  getPayableAmount() {
    this.getPayable() ;
  }
  checkNum()
  {
    if(this.general.term_count<=0)
    {
      this.general.term_count =1;
      
    }
    this.getPayable() ;
  }
}
