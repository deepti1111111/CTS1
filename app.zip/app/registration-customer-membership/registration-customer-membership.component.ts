import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Globals } from '../global';
import { FormsModule,FormControl,Validators } from '@angular/forms';
import { Subject, throwError,Observable } from 'rxjs';
import { $ } from 'protractor';
import { NavComponent } from '../nav/nav.component';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

import { NotifierService } from "angular-notifier";
@Component({
  selector: 'app-registration-customer-membership',
  templateUrl: './registration-customer-membership.component.html',
  styleUrls: ['./registration-customer-membership.component.css']
})
export class RegistrationCustomerMembershipComponent implements OnInit {

  
  modalRef: BsModalRef; 
  @ViewChild('mobileVerification', { static: true }) mobileVerification: ElementRef;
  
  //===============================================//


  private readonly notifier: NotifierService;
  // toggle webcam on/off
  public showWebcamProfileImage = false;
  public showWebcamIdImage = false;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];
  // latest snapshot
  public webcamImage: WebcamImage = null;

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();



  //================================================//
  public country: string;
  public user = {email:"",password:"",fcm_key:"pwa"};
  public pageCustomerRegData ={    back_button: "Retour",business_connection: "Relation d'affaires",city: "Ville / municipalité",country: "Pays",customer_number: "Numéro de client (généré automatiquement)",date_of_change: "Date de changement",date_of_create: "Date de création",dialing_code: "Code de composition",email: "Email",email_verification_code: "Lien de vérification de courrier électronique",first_name: "Prénom",fisrt_name: "First Name",floor: "Sol",form_title: "Formulaire d'inscription Adhésion client / sur demande",further_information: "Informations complémentaires",house: "Numéro de maison / appartement",id_card: "Carte d'identité",last_name: "Nom de famille",location_of_change: "Lieu de changement",location_of_create: "Lieu de création",mobile_number: "Numéro de portable",mobile_verification_code: "Code de vérification mobile",nationality: "Nationalité",password: "Mot de passe",password_repeat: "Répéter le mot de passe",payment_methods: "Sélectionnez les modes de paiement",state: "Province / État fédéral",street_name: "Nom de rue",street_number: "Numéro de rue",submit_button: "Soumettre",take_a_picture: "Prendre une photo",take_an_id: "Prendre un identifiant",time_of_change: "Temps de changement",time_of_create: "Temps de création",upload_a_picture: "Télécharger une image",upload_an_id: "Télécharger un identifiant",upload_picture: "Charger une photo",username: "Nom d'utilisateur",verification: "Vérification",zip: "zip",  };
  public response :any;
  public tmp:any;
  public countryList:any;
  public mobileError: string;
  public message: string;
  public mobileOTP: string = "";

public id_cardErr:string =  "";

  public password_err: string = "";
  public password_err1: string = "";

  public mobile_verification_code: string = "";
  public fileToUpload: File = null;
  public regForm = {    image: "face-image.png",    id_proof_image: "identity-image.png",    payment_methods:[1],    user_type: "Adhoc",    first_name: "",    last_name: "",    nationality: "Chinese",    username: "",    id_card: "",    password: "",    password_repeat: "",    country: "",    state: "",city: "",    zip: "",    street_number: "",    street_name: "",    house: "",    floor: "",    further_information: "",    email: "",    dialing_code: "",    mobile_number: "",    email_verification_code: true,    mobile_verification_code: true,    role: "user"};
  public regFormErr = {    imageErr: "",    id_proof_imageErr: "",
    first_nameErr: "",    last_nameErr: "",    id_cardErr: "",    passwordErr: "",    password_repeatErr: "",
        email: "",    dialing_codeErr: "",    mobile_number: "" };


    public email_alert:any='';
    public mobile_number_alert:any='';
    
    public BaseUrl:any='';
    public BASE_URL:any='';
    
  constructor(private modalService: BsModalService,
     notifierService: NotifierService,private router: Router,public global: Globals,private http: HttpClient, private cookieService: CookieService) { 

    //this.getCountry();

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.notifier = notifierService;
    console.log(this.global.APIURL);
    // console.log(this.countryList);
  }
  error = new Subject<string>();
  ngOnInit() {
    this.getCustomerRegPageData();  
       
    console.log("countryList") ;
    console.log(this.global.countryList) 
  }

  getCustomerRegPageData() {
    
    this.http.post(
      this.global.APIURL+'api/general/getPageScreen',
      {id:false,screen:"Customer Registration"}
    )
    .subscribe(
      responseData => {
        console.log("Response for customer");
        console.log(this.global.country);
        this.tmp = responseData;
        var cookie = JSON.parse(this.cookieService.get('language_code'));
        this.global.country = cookie.language;
        console.log(this.global.country);
        if(this.global.country == 'en')
        {
          this.pageCustomerRegData = this.tmp.data.content_en;
        }
        else if(this.global.country == 'cn')
        {
          this.pageCustomerRegData = this.tmp.data.content_cn;
        }
        else if(this.global.country == 'de')
        {
          this.pageCustomerRegData = this.tmp.data.content_de;
        }
        else if(this.global.country == 'fr')
        {
          this.pageCustomerRegData = this.tmp.data.content_fr;
        }
        else if(this.global.country == 'hi')
        {
          this.pageCustomerRegData = this.tmp.data.content_hi;
        }
        else if(this.global.country == 'es')
        {
          this.pageCustomerRegData = this.tmp.data.content_es;
        }
       // console.log(this.global.country);
        //console.log(this.pageCustomerRegData);
      },
      error => {
        this.error.next(error.message);
      }
    );
  }
  
  handleFileInput(files: FileList,FileName:string) {
    //console.log(FileName);
    this.fileToUpload = files.item(0);
    const formData: FormData = new FormData();
    formData.append('file', this.fileToUpload, this.fileToUpload.name);
    formData.append('data', 'user');
    this.http.post(
      this.global.APIURL+"api/users/auth/uploadImage",
      formData
    )
    .subscribe(
      responseData => {
        //console.log(responseData);    
        this.tmp = responseData;
        if(FileName == 'image')
        {
          this.regForm.image = this.tmp.file_name;
        }
        else if(FileName == 'id_proof_image'){
          this.regForm.id_proof_image = this.tmp.file_name;
        }
        //console.log(this.regForm); 
      },
      error => {
        //console.log(error.message)
        this.error.next(error.message);
      }
    );
  }
  verifyOTP() {
   
    this.mobileError = "";
    this.message = "";
    if(this.mobile_verification_code.length == 5 )
    {
       if (this.mobileOTP.trim() != this.mobile_verification_code.trim()) {
        this.mobileError = "Code does not matched";       
       
      }
      else
      {        
        this.message = "Mobile number verified successfully";
       
        this.modalRef.hide(); 
        this.onSubmit();
      }
    }
    
  }

validationInputPwdText  (value:string) {
  this.password_err = "";
  var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
  if (value.match(decimal)) {
      this.password_err = "";

  } else {
    this.regForm.password = "";
    this.password_err = "Passwords must contain at least 8 characters, including uppercase, lowercase letters, special characters and numbers.Password";
  }        
};

confirmPass (value1:string, value2:string) {
  
  this.password_err1 = "";

  if (value1 == value2) {
    this.password_err1 = "";
    console.log(value1+","+value2);

  } else {
    this.password_err1 = "Passwords must be matched";
  }
};




validateCheck(checked: any)
{
  console.log(event);
  if(!checked)
  {
    return false;
  }

  if(this.regForm.mobile_number=='')
  {
    this.regForm.mobile_verification_code=false;
    alert("Please enter mobile Number");
   
    return false;
  }
  if(this.regForm.dialing_code=='')
  {
    this.regForm.mobile_verification_code=false;
    alert("Please enter dialing code");
   
    return false;
  }


}

formValidateCheck()
{
  this.regFormErr.first_nameErr = "";
  this.regFormErr.last_nameErr = "";
  this.email_alert = "";
  this.mobile_number_alert = "";
  this.regFormErr.dialing_codeErr = "";
  this.regFormErr.imageErr = "";
  this.regFormErr.id_proof_imageErr = "";
  this.id_cardErr = "";
  
  let result :boolean=true;
  if(this.regForm.id_card=='')
  {
    this.id_cardErr = "Please enter ID Card";
    result =  false;
  }
  if(this.regForm.first_name=='')
  {
    this.regFormErr.first_nameErr = "Please enter first name";
    result =  false;
  }
  if(this.regForm.last_name=='')
  {
    this.regFormErr.last_nameErr = "Please enter last name";
    result =  false;
  }
  if(this.regForm.email=='')
  {
    this.email_alert = "Please enter valid email ID";
    result =  false;
  }
  if(this.regForm.mobile_number=='')
  {
    this.mobile_number_alert = "Please enter a mobile number";
    result =  false;
  }
  if(this.regForm.dialing_code=='')
  {
    this.regFormErr.dialing_codeErr = "Please enter dialing";
    result =  false;
  }
  if( this.regForm.image== "face-image.png")
  {
    this.regFormErr.imageErr = "Please upload picture";
    result =  false;
  }
  if( this.regForm.id_proof_image== "identity-image.png")
  {
    this.regFormErr.id_proof_imageErr = "Please upload ID proof";
    result =  false;
  }
  return result;

}

  onSubmit(){
    this.mobileError = "";
    
    if (  this.mobile_verification_code.trim() == "") {
      this.modalRef = this.modalService.show(this.mobileVerification,{backdrop:'static', keyboard:false});
  
    }
    else{
      //this.modalRef.hide();
    }
    
    if(!this.formValidateCheck())
    {
      console.log(this.regFormErr);
      return false;
    }
    else if(this.regForm.mobile_verification_code == true && this.regForm.mobile_number != "" && this.mobileOTP == "")
    {
      this.http.post(
        this.global.APIURL+"api/general/sendSms",
        {dialing_code:this.regForm.dialing_code,mobile_number:this.regForm.mobile_number}
      )
      .subscribe(
        responseData => {          
          var res: any;
          res = responseData;
          var data = JSON.parse((res.data));
          console.log(data);
          if(data.errors)
          {
            this.mobileError = data.errors[0].description;
          }
          else if(data.body)
          {
            this.mobileOTP = data.body;
            this.message = "Verified successfully";

          }
        },
        error => {
          console.log(error.message)
          this.error.next(error.message);
        }
      );
    }
    else if(this.regForm.mobile_verification_code == true && this.mobileOTP == this.mobile_verification_code)
    {
    this.http.post(
      this.global.APIURL+"api/users/auth/signup",
      this.regForm
    )
    .subscribe(
      responseData => {
        var res: any;
          res = responseData;
          if(res.message)
          {
            this.notifier.notify("success", res.message);
            //alert(res.message);
            setTimeout(
              ()=>{
                this.router.navigate(['/login']).then(() => {
                  //window.location.reload();
                 });
              }, 5000
            );
          }
      },
      error => {
        console.log(error.message)
        this.error.next(error.message);
      }
    );
    }
  }


  search = function (idx: any, value: any) {
    var ins = idx;
    this.email_alert ='';
    this.mobile_number_alert="";
    var formdata: any = {};
    if (idx == "email") {
      if (value == '') {
        this.email_alert = 'Please enter valid email address';
        return false;
      }
      if (!this.global.ValidateEmail(value)) {
        this.email_alert = 'Please enter  a valid email address';
        this.regForm.email = '';
        return false;
      }
      formdata = { email: value, user_type: "user" };
    }
    else if (idx == "mobile_number") {
      if (value == '') {
        this.mobile_number_alert = 'Please enter valid Mobile number';
        return false;
      }
      formdata = { mobile_number: value, user_type: "user" };
    }
    var api_method = 'search';
    this.http.post(this.BASE_URL + 'api/general/' + api_method, formdata, {
    }).
      subscribe(
        response => {

          if (idx == "email") {
            this.email_alert = 'Email already exists';
            this.regForm.email = '';
          }
          else if (idx == "mobile_number") {
            this.mobile_number_alert = 'Mobile number already exists';
            this.regForm.mobile_number = '';
          }
          this.mobile_number_alert
          return false;

        },
        error => {
          return false;
        });

  }



  isNumberKey(idx:any,val: any) {
   // console.log(val);
    var regex = /^[0-9]*(?:\.\d{1,2})?$/;    // allow only numbers [0-9] 
  if( !regex.test(val) ) {
    //console.log(this.regForm);
    if(idx=='zip')
    {
      this.regForm.zip='';
    }
    else if(idx='mobile_number')
    {
      this.regForm.mobile_number='';
    }
     
  }
}



  //========= web cam codes================//

  openCam(imageType: string) {
    if (imageType == 'profile_picture') {
      this.showWebcamProfileImage = true;
      this.showWebcamIdImage = false;
    }
    else {
      this.showWebcamProfileImage = false;
      this.showWebcamIdImage = true;
    }
  }
  saveTofile(snapshotData: any, uploadfr: any) {
    console.log(snapshotData);
    var formdata = { data: snapshotData, user_type: 'user' };
    console.log(formdata);
    this.http.post(this.BASE_URL + 'api/general/base64Tojpeg', formdata, {
    }).
      subscribe(
        response => {
          let tmpResponse: any = response;
          console.log(tmpResponse.data);
          if (uploadfr == "image") {
            this.regForm.image = tmpResponse.data;
            this.showWebcamProfileImage = false;
          }
          else {
            this.regForm.id_proof_image = tmpResponse.data;
            this.showWebcamIdImage = false;
          }
          //$scope.general.location_of_change  = response.data.location;
          return false;

        },
        error => {
          console.log(error);
          return false;
        });
  }


public triggerSnapshot(): void {
  this.trigger.next();
}


public handleInitError(error: WebcamInitError): void {
  this.errors.push(error);
}

public showNextWebcam(directionOrDeviceId: boolean|string): void {
  // true => move forward through devices
  // false => move backwards through devices
  // string => move to device with given deviceId
  this.nextWebcam.next(directionOrDeviceId);
}

public handleImage(webcamImage: WebcamImage): void {
  console.info('received webcam image', webcamImage);
  this.webcamImage = webcamImage;
  if(this.showWebcamProfileImage)
  {
    this.saveTofile (this.webcamImage.imageAsDataUrl,'image');
    //triggerObservable
  }
  else
  {
    this.saveTofile (this.webcamImage.imageAsDataUrl,'id');
  }
}

public cameraWasSwitched(deviceId: string): void {
  console.log('active device: ' + deviceId);
  this.deviceId = deviceId;
}

public get triggerObservable(): Observable<void> {
  return this.trigger.asObservable();
}

public get nextWebcamObservable(): Observable<boolean|string> {
  return this.nextWebcam.asObservable();
}




}
