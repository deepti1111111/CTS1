import { Component, OnInit,Directive ,Input} from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { Router,ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';


@Component({
  selector: 'app-driver-subscription',
  templateUrl: './driver-subscription.component.html',
  styleUrls: ['./driver-subscription.component.css']
})
export class DriverSubscriptionComponent implements OnInit {

 
  public isadhoc: boolean = true;
  public rS1: string = "_21164968305007015906";
  public rS2: string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_000X690979_";

  public country: string;
  public user = { email: "", password: "", fcm_key: "pwa" };
  public pageCustomerRegData = { About: "About", Bookings: "Bookings", Home: "Home", Profile: "Profile", Revenue: "Revenue", Subscription: "Subscription", change_password: "Change Password", contact_us: "Contact Us", create_new_ac: "Create New Account", driver_mgmt: "Driver's Management", email_address: "Email Address", forget_pass_btn: "Forget Password", i_am_not_robot: "I am not a Robot", login: "Login", login_btn: "Login", logout: "Logout", my_vehicles: "My Vehicles", password: "Password", payment_method: "Payment Method", privacy_policy: "Privacy Policy", register_btn: "Register With Us", rides: "Rides", service: "Service", vehicle_mgmt: "Vehicle's Management" };
  public response: any;
  public tmp: any;
  public countryList: any;
  public mobileError: string;
  public message: string;
  public mobileOTP: string = "";
  public mobile_verification_code: string = "";
  public fileToUpload: File = null;
  public general = { payment_methodss: '', image: "face-image.png", id_proof_image: "identity-image.png", payment_methods: [1], user_type: "Adhoc", first_name: "", last_name: "", nationality: "", username: "", id_card: "", password: "", password_repeat: "", country: "", state: "", city: "", zip: "", street_number: "", street_name: "", house: "", floor: "", further_information: "", email: "", dialing_code: "", mobile_number: "", email_verification_code: true, mobile_verification_code: true, role: "user" };
  public pageData = {analytics:'',payment:'',visibility:'', visibility_me:'',competitor:'',customer_show_density:'',driver_business_probability:'',ride:'', tax_invoice:'',msg:'',standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: '/p.m.', rate_year: '/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public TOKEN: string = "";
  error = new Subject<string>();
  public config: any;
  public BaseUrl: string;
  public subscribed: boolean = false;
  public headers: any = {};
  public is_edit: boolean = false;
  public BASE_URL: string = '';
  public paymentMethodDetails: any;
  public paymentMethods: any;
  public subscriptionMessage: string = '';
  public subscription_info:any;
  public standard_monthly: any;
  public standard_yearly: any;

  public exclusive_monthly: any;
  public exclusive_yearly: any;

  public premium_monthly: any;
  public premium_yearly: any;

  public standard: any = {competitor:'',customer_show_density:'', driver_business_probability:'',tax_invoice:'',visibility:'',metropay_ride:'',standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public exclusive: any = {competitor:'',customer_show_density:'', driver_business_probability:'',tax_invoice:'',visibility:'',metropay_ride:'',standard: 'Standard',  exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public premier: any = {competitor:'',customer_show_density:'', driver_business_probability:'',tax_invoice:'',visibility:'',metropay_ride:'',standard: 'Standard',   exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public premium: any = {competitor:'',customer_show_density:'', driver_business_probability:'',tax_invoice:'',visibility:'',metropay_ride:'',standard: 'Standard',   exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };

//premium
  
  constructor(public global: Globals, private http: HttpClient, private cookieService: CookieService,
     private router: Router
     ) {
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;
   
    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });
    this.getPaymentMethods();
  //  console.log("FROM COOKEI");
    //console.log(this.cookieService.get("paylist"));

  }

  ngOnInit() {

    this.getPageData();
    this.getSubscriptionCharge();
    
    //console.log(this.isadhoc);
  }


  ngAfterViewInit()
  {
    this.getSubscriptionInfo();
  }

  getSubscriptionInfo = function () {

    var api_method = "subscriptionInfo";
    this.http.get(this.BASE_URL + 'api/drivers/account/' + api_method, {
      headers: this.headers
    })
      .subscribe(
       response => {
        let tmpResponse:any = response;
        this.subscription_info = tmpResponse.data;
       // console.log(tmpResponse);
        //console.log(tmpResponse.adhoc);
        this.isadhoc = false;//response.adhoc;
          //console.log( this.isadhoc);
          if (response.success == "true") {
            this.subscribed = true;
            this.subscriptionMessage = response.message;
          }
          else {
            this.subscribed = false;
            this.subscriptionMessage = response.message;
          }


          return false;
        },
        error => {
          return false;
        });
  };

  getSubscriptionCharge  () {
  //  console.log("getSubscriptionCharge ");

    var formdata = { user_type: 'Driver' };
    this.http.post(this.BASE_URL + 'api/subscription/subscriptionData', formdata, {
      headers: this.headers
    }).
      subscribe(
        response => {
          let tmpResponse:any = response;
          var subscribe_list = tmpResponse.data1;
          console.log(subscribe_list);
          this.standard_monthly = "";
          this.standard_yearly = "";

          this.exclusive_monthly = "";
          this.exclusive_yearly = "";

          this.premium_monthly = "";
          this.premium_yearly = "";

          this.standard = "";
          this.exclusive = "";
          this.premier = "";

          if (subscribe_list) {
           // console.log(response.data);
           for (var i = 0; i < subscribe_list.length; i++)
           {
               
               if (subscribe_list[i].subscription_term == "Standard")
               {
                   this.standard_monthly = subscribe_list[i].monthly_pay;

                   this.standard_yearly = subscribe_list[i].yearly_pay;
                   this.standard = subscribe_list[i];
               }
               if (subscribe_list[i].subscription_term == "Exclusive")
               {
                   this.exclusive_monthly = subscribe_list[i].monthly_pay;
                   this.exclusive_yearly = subscribe_list[i].yearly_pay;
                   this.exclusive = subscribe_list[i];
                   
               }
               if (subscribe_list[i].subscription_term == "Premier")
               {
                   this.premium_monthly = subscribe_list[i].monthly_pay;
                   this.premium_yearly = subscribe_list[i].yearly_pay;
                   this.premier = subscribe_list[i];
                   this.premium = subscribe_list[i];
               }
           }
          }

          return false;
        }
        , function errorCallback(response) {
          return false;
        });
  };


  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "user-subscription" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
         
          //console.log("Local Storage");
          //console.log(JSON.parse(localStorage.getItem('user')));
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
          //console.log(LOCALSTORAGE);
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;
         
          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
        
          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }




  getPaymentMethods = function () {
    this.http.get(this.BASE_URL + 'api/general/getPaymentMethods', {
      headers: this.headers
    }).
      subscribe(
        response => {
          this.msg = response.data.message;
          this.paymentMethodDetails = response.data1;
          this.paymentMethods = response.data;
        
        },
        error => {
          return false;
        });
  };

  setPaymentInfo(term_yearly:string ,subscription_type:string, currency:string ,term:string,isOne:string)
  {
      let formdata:any={
        term_yearly:term_yearly,
        subscription_type:subscription_type,
        subscription_term:term,
        total_fee:term_yearly,
        Subject:'subsciption for users',
        user_type:'driver',
        currency:currency,
        term:isOne
      }
    
      console.log(formdata);
      this.router.navigate(['payment-page',JSON.stringify(formdata)]);
  }

  

}
