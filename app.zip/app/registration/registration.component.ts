import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject, throwError } from 'rxjs';
import { Globals } from '../global';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  public tmp:any;
  public regPageData = {

    contact_us: "",
    login: "",
    customer_membership: "Customer Membership",
    self_employed_driver: "Self Employed Driver is updated from the admin",
    individual_company_licensed_driver: "Individual Company Licensed Driver",
    company_control_center: "Company control center(Administrator\/Driver\/Vehicle)",
    self_employed_driver_comment: "*(Car Courier, Bike Courier, Others (Food, Postal, Newspaper, Documents))",
    individual_company_licensed_driver_comment: "*(Food, Postal, Newspaper, Others (Food, Postal, Newspaper, Documents))",
    company_control_center_comment: "*(Food, Postal, Newspaper, Others (Food, Postal, Newspaper, Documents))",
    post_ad:"Post Ad"
  };
  error = new Subject<string>();

  constructor(public lang: Globals, private http: HttpClient,public cookieService:CookieService) { }

  ngOnInit() {
    this.getRegPageData();
  }


  getRegPageData() {
    
    this.http.post(
      this.lang.APIURL+'api/general/getPageScreen',
      {id:false,screen:"regsitration"}
    )
    .subscribe(
      responseData => {
        this.tmp = responseData;
        var cookie = JSON.parse(this.cookieService.get('language_code'));
        this.lang.country = cookie.language;
        console.log(this.lang.country);
        if(this.lang.country == 'en')
        {
          this.regPageData = this.tmp.data.content_en;
        }
        else if(this.lang.country == 'cn')
        {
          this.regPageData = this.tmp.data.content_cn;
        }
        else if(this.lang.country == 'de')
        {
          this.regPageData = this.tmp.data.content_de;
        }
        else if(this.lang.country == 'fr')
        {
          this.regPageData = this.tmp.data.content_fr;
        }
        else if(this.lang.country == 'hi')
        {
          this.regPageData = this.tmp.data.content_hi;
        }
        else if(this.lang.country == 'es')
        {
          this.regPageData = this.tmp.data.content_es;
        }
        console.log(this.regPageData);
      },
      error => {
        this.error.next(error.message);
      }
    );
  }


}
