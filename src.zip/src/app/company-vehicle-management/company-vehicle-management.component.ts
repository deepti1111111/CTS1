import { Component, OnInit, ViewChild, ElementRef, OnDestroy, Directive, Input } from '@angular/core';
import { Globals } from '../global';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import * as moment from 'moment';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

import { DataTableDirective } from 'angular-datatables';

declare var $: any;
@Component({
  selector: 'app-company-vehicle-management',
  templateUrl: './company-vehicle-management.component.html',
  styleUrls: ['./company-vehicle-management.component.css']
})
export class CompanyVehicleManagementComponent implements OnInit {

  //==== modal start//
  modalRef: BsModalRef; 
  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective; 
  dtOptions: any = {};
  dtInstance: DataTables.Api;
  dtTrigger: Subject<any> = new Subject();
  isDtInitialized:boolean = false;

  @ViewChild("map", { static: true }) public mapElement: ElementRef;
  @ViewChild('TailSubscription', { static: true }) TailSubscription: ElementRef;
  @ViewChild('modalVehicle', { static: true }) modalVehicle: ElementRef;

  @ViewChild('vehicleDriverModal', { static: true }) vehicleDriverModal: ElementRef;
  @ViewChild('messageModal', { static: true }) messageModal: ElementRef;
  // == modal end ================//

  //=== Start date range picker====//
  selected: any;
  alwaysShowCalendars: boolean;
  showRangeLabelOnInput: boolean;
  keepCalendarOpeningWithRange: boolean;
  maxDate: moment.Moment;
  minDate: moment.Moment;
  invalidDates: moment.Moment[] = [];
  tooltips = [
    {date: moment(), text: 'Today is just unselectable'},
    {date:  moment().add(2, 'days'), text: 'Yeeeees!!!'}
  ];
  inlineDateTime;
  ranges: any = {
    Today: [moment(), moment()],
    Yesterday: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
    'Last Month': [
      moment()
        .subtract(1, 'month')
        .startOf('month'),
      moment()
        .subtract(1, 'month')
        .endOf('month')
    ],
    'Last 3 Month': [
      moment()
        .subtract(3, 'month')
        .startOf('month'),
      moment()
        .subtract(1, 'month')
        .endOf('month')
    ]
  };

  isInvalidDate = (m: moment.Moment) =>  {
    return this.invalidDates.some(d => d.isSame(m, 'day') );
  }
  isTooltipDate = (m: moment.Moment) =>  {
    const tooltip = this.tooltips.find(tt => tt.date.isSame(m, 'day'));
    if (tooltip) {
      return tooltip.text;
    } else {
      return false;
    }
  }

  //==== End date range picker=====//

  
  public TOKEN: string = "";
  error = new Subject<string>();
  public config: any;
  public BaseUrl: string;
  public subscribed: boolean = false;
  public headers: any = {};
  public is_edit: boolean = false;
  public BASE_URL: string = '';
  public subsciptionStatusmessage: string;
  public subscriptionMessage: string;

  public companyDriverList: any = [];
  public companyDriverLists: any = [];
  public company_driver_count: string = "";

  public general: any = { id: false, image: 'face-image.png', id_proof_image: 'identity-image.png', business_connection_type: '5', driver_number: '', first_name: '', last_name: '', username: '', id_card: '', password: '', password_repeat: '', country: 'CN China', state: '', city: '', zip: '', street_number: '', street_name: '', house: '', floor: '', further_information: '', email: '', dialing_code: '', mobile_number: '', driver_taxi_lic_no: '', driver_emp_no: '', social_ins_num: '', license_plate: '', vehicle_type: '1', vehicle_make: '1', make_type: '', powertrain: 'Combustion', driving_mode: 'Driver', email_verification_link: '1', mobile_verification_code: '0', is_mobile_verified: '1', date_of_create: '', time_of_create: '', location_of_create: '', date_of_change: '', time_of_change: '', location_of_change: '', role: 'driver', payment_methods: false };
  public pageData: any = { vehicle_management: 'Vehicle Management ', list_of_vehicle: ' List of vehicles', add_vehicle_btn: 'Add vehicle', start_date: 'Start Date', end_date: 'End Date', submit: 'Go', sno: 'Sr.', vehicle_name: 'Vehicle Name', make: 'Vehicle Brand', brand_type: 'Vehicle Brand Type', lic_plate: 'License Plate', powertrain: 'Powertrain', action: 'Action', vehicle_detail: 'Vehicle Detail', assigned_driver: 'Assigned Driver', driver_name: "Driver's Name", picture: 'Picture' };

  public general_vehicle = { id: '', powertrain: 'Combustion', driving_mode: 'Driver', vehicle_doc: 'doc.jpg', image: 'err.jpg', vehicle_type_id: '1', vehicle_make_id: '1', make_type_id: '', license_plate_no: '' };

  public vehicle: any = {id:'',block_status:1};
  public msg: string = "";
  public companyVehicleList: any = [];
  public ComapanyVehicleLists: any = [];

  public vehicle_driver_modal_msg: string = "";
  public vehicle_driver_modal_err: string = "";
  public index: number = 0;

  constructor(public global: Globals, private modalService: BsModalService, private http: HttpClient, private cookieService: CookieService, private router: Router
  ) {
    this.alwaysShowCalendars = false;
    this.alwaysShowCalendars = false;
    this.maxDate = moment().add(2,  'weeks');
    this.minDate = moment().subtract(3, 'days');

    this.alwaysShowCalendars = true;
    this.keepCalendarOpeningWithRange = true;
    this.showRangeLabelOnInput = true;
    this.selected = {
      startDate: moment().subtract(1, 'days').set({hours: 0, minutes: 0}),
      endDate: moment().subtract(1, 'days').set({hours: 23, minutes: 59})
    };

    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });

  }

  ngOnInit() {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10
    };
    this.getPageData();
    this.getVehicleManagementInfo();
    this.getDriverManagementInfo();
  }
  ngAfterViewInit(): void {
    this.dtTrigger.next();
    this.rerender();
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  rerender(): void {
    try {
      this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        // Destroy the table first
        dtInstance.destroy();
        // Call the dtTrigger to rerender again
        this.dtTrigger.next();
      });
    } catch (err) {
      console.log(err);
    }
  }


  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "company-vehicle-management" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));

          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }

          this.global.setPageData(this.pageData);
          console.log(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }
  getSubscriptionInfo ()
  {
      var api_method = "subscriptionInfo";

      this.http.get(this.BASE_URL + 'api/companies/account/' + api_method, {headers:this.headers
      }).subscribe(response=> {
        let tmpResponse:any = response;
          if (tmpResponse.success == "true")
          {
              this.subscribed = true;
              this.subscriptionMessage = tmpResponse.message;
          }
          else
          {
              this.subscribed = false;
              this.subscriptionMessage = tmpResponse.message;

          }
          return false;

      }, 
      error=>{
          return false;
      });

  };

  viewCompanyVehicle(ob: any) {
    this.vehicle = ob;
    console.log(this.vehicle); 
    this.modalRef = this.modalService.show(this.modalVehicle);
  };

  getVehicleManagementInfo() {
    // getVehicleDetailsDaterange_post
    this.companyVehicleList = [];
    this.http.get(this.BASE_URL + 'api/companies/vehicle/getVehicleDetails', {
      headers: this.headers
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.ComapanyVehicleLists = [];
      this.ComapanyVehicleLists = tmpResponse.data;
      this.rerender();
      return false;
    }, error => {
      if(error.error.error =="Token Expired")
      {
        this.router.navigate(['logout']);
      }

      return false;

    });
  };

  getVehicleDetailsDaterange(date1:string, date2:string) {
    // getVehicleDetailsDaterange_post
    let formdata:any = {date1:date1, date2:date2};
    this.companyVehicleList = [];
    this.http.post(this.BASE_URL + 'api/companies/vehicle/getVehicleDetailsDaterange',formdata, {
      headers: this.headers
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.ComapanyVehicleLists = [];
      this.ComapanyVehicleLists = tmpResponse.data;
      this.rerender();
      return false;
    }, error => {
      if(error.error.error =="Token Expired")
      {
        this.router.navigate(['logout']);
      }

      return false;

    });
  };



  delVehicle(id) {
    if (confirm("Are you sure, you want to delete it?")) {
      this.http.post(this.BASE_URL + 'api/companies/vehicle/delVehicleDetails', { id: id }, {
        headers: this.headers

      }).subscribe(response => {
        let tmpResponse: any = response;
        this.msg = tmpResponse.message;
        this.modalRef = this.modalService.show(this.messageModal);
        setTimeout(() => {
         this.modalRef.hide();
        }, 2000);
        this.getVehicleManagementInfo();
      }, error => {
        this.msg = error.error.error;
        return false;
      });

    }

  };
  blockVehicle(id: string, status: number) {
    var alertMessage = "Are you sure, you want to block the vehicle?";
    if (status == 1) {
      alertMessage = "Are you sure, you want to unblock the vehicle?";
    }
    if (confirm(alertMessage)) {
      this.http.post(this.BASE_URL + 'api/companies/vehicle/blockVehicleDetails', { id: id, block_status: status }, {
        headers: this.headers
      }).subscribe(response => {
        let tmpResponse: any = response;
        this.msg = tmpResponse.message;
        console.log(this.msg);
        this.modalRef = this.modalService.show(this.messageModal);
        setTimeout(() => {
         this.modalRef.hide();
        }, 2000);
        this.getVehicleManagementInfo();

      }, error => {
        this.msg = error.error.error;
        this.modalRef = this.modalService.show(this.messageModal);
        setTimeout(() => {
         this.modalRef.hide();
        }, 2000);
        return false;

      });

    }


  };
  closemodal()
  {
    this.modalRef.hide();
  }
  assignDriverPopupWindow(tmpVehicle: any) {
    this.vehicle_driver_modal_msg = "";
    this.vehicle_driver_modal_err = "";
    this.vehicle = tmpVehicle;
    console.log(this.vehicle);
    console.log(this.companyDriverLists);
    this.modalRef = this.modalService.show(this.vehicleDriverModal);
  };

  assignDriver(vehicle: any) {
    this.http.post(this.BASE_URL + 'api/companies/service/updateVehicleAssignment',
      { id: vehicle.id, user_id: vehicle.user_id }, {
      headers: this.headers

    }).subscribe(response => {
      let tmpResponse: any = response;
      var result = tmpResponse.data;
      this.vehicle_driver_modal_msg = "";
      this.vehicle_driver_modal_err = "";
      if (tmpResponse.status) {
        this.vehicle_driver_modal_msg = tmpResponse.message;
      }
      else {
        this.vehicle_driver_modal_err = tmpResponse.message;
      }
      this.getVehicleManagementInfo();

    }, error => {

      return false;

    });



  };
  add_vehicle() {
    if(this.modalRef)
    {
      this.modalRef.hide();
    }
    console.log(this.subscribed);
   
    this.subscribed = true;
    if (this.subscribed) {
    //this.modalRef = this.modalService.show(this.TailSubscription);
    this.router.navigate(['add-vehicle']);
      // location.href = this.BASE_URL + "add-vehicle";
    }
    else {
      this.modalRef = this.modalService.show(this.TailSubscription);
    }
    console.log("companyDriverManagementCtrl");
  };

  
  getDriverManagementInfo() {
    this.http.get(this.BASE_URL + 'api/companies/service/getDriverDetails', {
      headers: this.headers
    }).subscribe(
      response => {
        let tmpResponse: any = response;
        this.companyDriverList = tmpResponse.data;

        console.log(this.companyDriverList);
        this.companyDriverLists = tmpResponse.data_list;
        this.company_driver_count = this.companyDriverList.length;
      }, error => {
        return false;
      });
  };

  rangeClicked(range:any) {
   //console.log('[rangeClicked] range is : ', range);
  }
  datesUpdated(range: any) {
    if (range.startDate) {
      console.log('[datesUpdated] range is : ', this.global.convert(range.startDate._d));
      console.log('[datesUpdated] range is : ', this.global.convert(range.endDate._d));
      this.getVehicleDetailsDaterange(this.global.convert(range.startDate._d), this.global.convert(range.endDate._d));
    }

  }

}
