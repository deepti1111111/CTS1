import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';



@Component({
  selector: 'app-user-subscription',
  templateUrl: './user-subscription.component.html',
  styleUrls: ['./user-subscription.component.css']
})
export class UserSubscriptionComponent implements OnInit {


  public isadhoc: boolean = false;
  public rS1: string = "_21164968305007015906";
  public rS2: string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_000X690979_";

  public country: string;
  public user = { email: "", password: "", fcm_key: "pwa" };
  public pageCustomerRegData = { About: "About", Bookings: "Bookings", Home: "Home", Profile: "Profile", Revenue: "Revenue", Subscription: "Subscription", change_password: "Change Password", contact_us: "Contact Us", create_new_ac: "Create New Account", driver_mgmt: "Driver's Management", email_address: "Email Address", forget_pass_btn: "Forget Password", i_am_not_robot: "I am not a Robot", login: "Login", login_btn: "Login", logout: "Logout", my_vehicles: "My Vehicles", password: "Password", payment_method: "Payment Method", privacy_policy: "Privacy Policy", register_btn: "Register With Us", rides: "Rides", service: "Service", vehicle_mgmt: "Vehicle's Management" };
  public response: any;
  public tmp: any;
  public countryList: any;
  public mobileError: string;
  public message: string;
  public mobileOTP: string = "";
  public mobile_verification_code: string = "";
  public fileToUpload: File = null;
  public general = { payment_methodss: '', image: "face-image.png", id_proof_image: "identity-image.png", payment_methods: [1], user_type: "Adhoc", first_name: "", last_name: "", nationality: "", username: "", id_card: "", password: "", password_repeat: "", country: "", state: "", city: "", zip: "", street_number: "", street_name: "", house: "", floor: "", further_information: "", email: "", dialing_code: "", mobile_number: "", email_verification_code: true, mobile_verification_code: true, role: "user" };
  public pageData = { standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public TOKEN: string = "";
  error = new Subject<string>();
  public config: any;
  public BaseUrl: string;
  public subscribed: boolean = false;
  public headers: any = {};
  public is_edit: boolean = false;
  public BASE_URL: string = '';
  public paymentMethodDetails: any;
  public paymentMethods: any;
  public subscriptionMessage: string = '';

  public standard_monthly: any;
  public standard_yearly: any;

  public exclusive_monthly: any;
  public exclusive_yearly: any;
  public subscription_info:any;
  public premium_monthly: any;
  public premium_yearly: any;

  public standard: any = { standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public exclusive: any = { standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public premier: any = { standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };


  constructor(public global: Globals, private http: HttpClient, private cookieService: CookieService, private router: Router) {
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;
   
    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });
    this.getPaymentMethods();

  }

  ngOnInit() {

    this.getPageData();
    this.getSubscriptionCharge();
    this.getSubscriptionInfo();
    console.log(this.exclusive);
  }



  getSubscriptionInfo = function () {
    var api_method = "subscriptionInfo";
    this.http.get(this.BASE_URL + 'api/users/account/' + api_method, {
      headers: this.headers
    })
      .subscribe(
        response=> {
          let tmpResponse:any = response;
          console.log(tmpResponse);
          this.subscription_info = tmpResponse.data;
          this.isadhoc = response.adhoc;

          if (response.success == "true") {
            this.subscribed = true;
            this.subscriptionMessage = response.message;
          }
          else {
            this.subscribed = false;
            this.subscriptionMessage = response.message;
          }


          return false;
        },
        error => {
          return false;
        });
  };

  getSubscriptionCharge  () {

    var formdata = { user_type: 'Customer' };
    this.http.post(this.BASE_URL + 'api/subscription/subscriptionData', formdata, {
      headers: this.headers
    }).
      subscribe(
        response => {
          let tmpresponse:any = response;
          console.log(tmpresponse);
          var subscribe_list = tmpresponse.data1;
          console.log(subscribe_list);
          if (subscribe_list) {
            for (var i = 0; i < subscribe_list.length; i++) {
           
              if (subscribe_list[i].subscription_term == "Standard") {
                this.standard_monthly = subscribe_list[i].monthly_pay;
                this.standard_yearly = subscribe_list[i].yearly_pay;
                this.standard = subscribe_list[i];
              }
              if (subscribe_list[i].subscription_term == "Exclusive") {
                this.exclusive_monthly = subscribe_list[i].monthly_pay;
                this.exclusive_yearly = subscribe_list[i].yearly_pay;
                this.exclusive = subscribe_list[i];
              }
              if (subscribe_list[i].subscription_term == "Premier") {
                this.premium_monthly = subscribe_list[i].monthly_pay;
                this.premium_yearly = subscribe_list[i].yearly_pay;
                this.premier = subscribe_list[i];
              }
            }
            console.log(this.exclusive);
          }

          return false;
        }
        , function errorCallback(response) {
          return false;
        });
  };


  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "user-subscription" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
         
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;
          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getUserData() {
    this.http.get(
      this.global.APIURL + 'api/user/profile', {
      headers: this.headers
    })
      .subscribe(
        responseData => {

          var userdata: any = responseData;
          this.general = userdata.data;
         var tempPaymentMethods: any = [];
          for (let i = 0; i < this.general.payment_methods.length; i++) {
            let pay = this.general.payment_methods[i];
            tempPaymentMethods.push(this.paymentMethodDetails[pay].payment_method_name);
          }
          this.general.payment_methodss = tempPaymentMethods;
        },
        error => {
          this.error.next(error.message);

          if (error.error.error.trim() == "Token Expired") {
            this.router.navigate(['logout']);
          }
        }
      );
  }

  setprofile = function () {
    let TOKEN = this.TOKEN;

    if (!TOKEN) {
      return false;
    }
    if (!this.formValidated()) {
      return false;
    }

    this.http.post(this.BASE_URL + 'api/driver/profile', this.general, {
      headers: this.headers
    })
      .subscribe(
        responseData => {
          this.getUserData();
          return false;
        },
        error => {
          this.error.next(error.message);
         
          return false;
        });
  };




  getPaymentMethods = function () {
    this.http.get(this.BASE_URL + 'api/general/getPaymentMethods', {
      headers: this.headers
    }).
      subscribe(
        response => {
         
          this.msg = response.data.message;
          this.paymentMethodDetails = response.data1;
          this.paymentMethods = response.data;
          this.getUserData();
        },
        error => {
          return false;
        });
  };


  setPaymentInfo(term_yearly:string ,subscription_type:string, currency:string ,term:string,isOne:string)
  {
      let formdata:any={
        term_yearly:term_yearly,
        subscription_type:subscription_type,
        subscription_term:term,
        total_fee:term_yearly,
        Subject:'subsciption for users',
        user_type:'user',
        currency:currency,
        term:isOne
      }
    
      console.log(formdata);
      this.router.navigate(['payment-page',JSON.stringify(formdata)]);
  }

}
