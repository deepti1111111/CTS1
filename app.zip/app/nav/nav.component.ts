import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
//import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SwUpdate } from '@angular/service-worker';
import { map, catchError } from 'rxjs/operators';
import { Subject, throwError } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {


  cookieValue = 'UNKNOWN';
  public flagClass = " LanguageBox flagClass1";
  public country: string;
  public langImg: string;
  public is_a_company_driver:boolean=true;
  public is_none : boolean = false;
  public is_driver : boolean = false;
  public is_user : boolean = false;
  public is_company : boolean = false;

  public config: any;
  public pageData = { About: "About", Bookings: "Bookings", Home: "Home", Profile: "Profile", Revenue: "Revenue", Subscription: "Subscription", change_password: "Change Password", contact_us: "Contact Us", create_new_ac: "Create New Account", driver_mgmt: "Driver's Management", email_address: "Email Address", forget_pass_btn: "Forget Password", i_am_not_robot: "I am not a Robot", login: "Login", login_btn: "Login", logout: "Logout", my_vehicles: "My Vehicles", password: "Password", payment_method: "Payment Method", privacy_policy: "Privacy Policy", register_btn: "Register With Us", rides: "Rides", service: "Service", vehicle_mgmt: "Vehicle's Management" };
  public countryList: any=[];
  public countryData: any;
  public user_type: string = '';


  public business_connection_type_list: any = [];

  error = new Subject<string>();
  constructor(public global: Globals, private http: HttpClient, private cookieService: CookieService, private router: Router) {

    this.getCountry();
    if (this.cookieService.get("language_code")) {
      let country: any = JSON.parse(this.cookieService.get("language_code"));
    

      this.global.setLang(country.language, country.flag_image);//sets language & flag to the global
    
      this.langImg = country.flag_image;
    }
    else {
    
      this.global.setLang('en', 'uk.png');//sets language & flag to the global 
      this.langImg = 'uk.png';
      let l :any = {"id":"7","country_name":"United Kingdom","country_code":"uk","nationality":"British","language":"en","flag_image":"uk.png","currency_code":"GBP","currency_image":"gbp.png","status":"1","create_id":"1","create_date":"2019-05-02 13:55:05","edit_id":null,"edit_date":null};
      this.cookieService.set("language_code",JSON.stringify(l));
      //{"id":"7","country_name":"United Kingdom","country_code":"uk","nationality":"British","language":"en","flag_image":"uk.png","currency_code":"GBP","currency_image":"gbp.png","status":"1","create_id":"1","create_date":"2019-05-02 13:55:05","edit_id":null,"edit_date":null}
      
    }
    this.getHeader();
  }

  ngOnInit() {
    this.getCountry();
    this.getHeader();
    this.getBusinessConnectiondriver('driver');
      this.getBusinessConnectioncompany('company');
      this.getBusinessConnection_company_driver();
    
    
    this.getPaymentMethods();
  }


  getHeader() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "header" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
          
          if (JSON.parse(localStorage.getItem('user'))) {

            $('body').css('background','url("")');


            this.user_type = JSON.parse(localStorage.getItem('user')).user_info;
            console.log(this.user_type);
          }
          else{
            $('body').css('background','url("/assets/images/taxi-slider-image.jpg"');
          }
          
          if (this.user_type.trim() == 'user' || this.user_type.trim() == "user") {
            this.is_user = true;

          }
          else if (this.user_type.trim() == '') {

            this.is_none = true;

          }
          else if (this.user_type.trim() == 'driver') {         
            this.is_driver = true;          
           if(LOCALSTORAGE.userDetail.company_id!= '' || LOCALSTORAGE.userDetail.company_id!=null)
           {
              this.is_a_company_driver = true;
           }
          }
          else if (this.user_type.trim() == 'company') {
         
            this.is_company = true;

          }
          if(!this.cookieService.get('language_code'))
          {
            for(var i = 0; i< this.countryList.length; i++)
            {
              if(this.global.country.trim() == this.countryList[i].language.trim())
              {
                var countrydatqa = this.countryList[i];
                this.cookieService.set('language_code', JSON.stringify(countrydatqa));
                
              }
            }
          }
          else{
            //do something when cookie is set
          }


          
          // this.cookieService.set('language_code', JSON.stringify(this.countryData));
          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
          this.global.setPageData(this.pageData);
        },
        error => {
        
          if(error.name=='HttpErrorResponse' && error.statusText=='Unknown Error')
          {
            this.router.navigate(['page-not-found']);
          }
          this.error.next(error.message);
        }
      );
  }
  closeflag()
  {
    if(this.flagClass == 'LanguageBox flagClass1')
    {
      this.flagClass = "LanguageBox flagClass2";
    }
    else{
      this.flagClass = "LanguageBox flagClass1";
    }
  }
  setLang(country: string, img: string, countryobj: any) {
    
    this.country = country;
    this.langImg = img;
    this.countryData = countryobj;
    this.cookieService.set('language_code', JSON.stringify(this.countryData));
    this.global.setLang(country, img);
    this.getHeader();
   
    window.location.reload();
    // this.router.onSameUrlNavigation="reload";
    //this.router.navigate(['/', '']);
  }

  getBusinessConnectiondriver (user_type:string) {

    var formdata = { connection_for: user_type };
    this.http.post(this.global.APIURL + 'api/general/businessConnection', formdata, {
    }).
      subscribe(
        response => {
          var tmpResponse:any = response;
          tmpResponse = tmpResponse.data;

          for (let i = 0; i < tmpResponse.length; i++) {
            this.business_connection_type_list.push(
              { id: tmpResponse[i].id, text: tmpResponse[i].business_connection_name }
            );
          }     
          this.cookieService.set('driver_connection',JSON.stringify(this.business_connection_type_list));
         
          
          return false;
        },
        error => {
          return false;
        });

  };

  getBusinessConnectioncompany (user_type:string) {

    var formdata = { connection_for: user_type };
    this.http.post(this.global.APIURL + 'api/general/businessConnection', formdata, {
    }).
      subscribe(
        response => {
          var tmpResponse:any = response;
          tmpResponse = tmpResponse.data;

          for (let i = 0; i < tmpResponse.length; i++) {
            this.business_connection_type_list.push(
              { id: tmpResponse[i].id, text: tmpResponse[i].business_connection_name }
            );
          }
      
          this.cookieService.set('company_connection',JSON.stringify(this.business_connection_type_list));
         
          
          return false;
        },
        error => {
          return false;
        });

  };


  getBusinessConnection_company_driver = function () {

    var formdata = { connection_for: 'company_driver' };
    this.http.post(this.global.APIURL + 'api/general/businessConnection', formdata, {
    }).
      subscribe(
        response => {
          var tmpResponse = response.data;
          var business_connection_type_list_company_driver :any=[];

          for (let i = 0; i < tmpResponse.length; i++) {
            business_connection_type_list_company_driver.push(
              { id: tmpResponse[i].id, text: tmpResponse[i].business_connection_name }
            );
          }
         
          this.cookieService.set('company_driver_connection',JSON.stringify(business_connection_type_list_company_driver));

          return false;
        },
        error => {
          return false;
        });

  };


  getPaymentMethods = function ()
  {
      this.http.get(this.global.APIURL + 'api/general/getPaymentMethods').
      subscribe(
        response=> {
          
          this.msg = response.data.message;
          this.paymentMethodDetails = response.data1;
          let paymentMethods = response.data;
          this.cookieService.set('pay',JSON.stringify(paymentMethods));
      },
      error=>{
          return false;
      });
  };


  getCountry() {
    this.http.get(this.global.APIURL + "api/general/languageList").subscribe(
      responseData => {
       
        let countryResponseData :any = responseData;
        this.global.setCountryList(responseData);
        this.countryList = responseData;
        this.countryList = countryResponseData.data;
        //console.log(this.countryList);
       
        
      },
      error => {
       
        if(error.name=='HttpErrorResponse' && error.statusText=='Unknown Error')
        {
          this.router.navigate(['page-not-found']);
          //this.router.navigate(['page-not-found', ''])
        }
        this.error.next(error.message);
      }
    );

  }



}
