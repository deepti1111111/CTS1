import { Component, OnInit } from '@angular/core';

import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';


@Component({
  selector: 'app-user-bookings',
  templateUrl: './user-bookings.component.html',
  styleUrls: ['./user-bookings.component.css']
})
export class UserBookingsComponent implements OnInit {

  public isadhoc: boolean = false;
  public p:number=1;
  public rS1: string = "_21164968305007015906";
  public rS2: string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_000X690979_";

  public country: string;
  
  public general = { payment_methodss: '', image: "face-image.png", id_proof_image: "identity-image.png", payment_methods: [1], user_type: "Adhoc", first_name: "", last_name: "", nationality: "", username: "", id_card: "", password: "", password_repeat: "", country: "", state: "", city: "", zip: "", street_number: "", street_name: "", house: "", floor: "", further_information: "", email: "", dialing_code: "", mobile_number: "", email_verification_code: true, mobile_verification_code: true, role: "user" };
  public pageData = {rides: 'Rides', search_btn: 'Search', search_placeholder: 'Seach', ride_list: 'List Of Rides', start_date: 'Start Date', end_date: 'End Date', show_item: 'Show Item', select_all: 'Select All', sno: 'Sr. No', pick_up: 'Pickup Location', drop: 'Drop Location', date: 'Date', fare: 'Fare', driver_name: 'Driver Name', car_no: 'Car Number', action: 'Action', ride_detial: 'Ride Detail', drivername: "Driver's Name", customername: "Customer's Name", pickup: 'Pick-up Location', vehicletype: 'Vehicle Type', series: 'Series', tip: 'Offered Tip', datetime: 'Booking Date & Time', feedback: 'Feedbacks', rating: 'Rating'};
  public TOKEN: string = "";
  error = new Subject<string>();
  public config: any;
  public BaseUrl: string;
  public base_url: string;
  public headers: any = {};
  public BASE_URL: string = '';
  public general_booking: any={rides: 'Rides', search_btn: 'Search', search_placeholder: 'Seach', ride_list: 'List Of Rides', start_date: 'Start Date', end_date: 'End Date', show_item: 'Show Item', select_all: 'Select All', sno: 'Sr. No', pick_up: 'Pickup Location', drop: 'Drop Location', date: 'Date', fare: 'Fare', driver_name: 'Driver Name', car_no: 'Car Number', action: 'Action', ride_detial: 'Ride Detail', drivername: "Driver's Name", customername: "Customer's Name", pickup: 'Pick-up Location', vehicletype: 'Vehicle Type', series: 'Series', tip: 'Offered Tip', datetime: 'Booking Date & Time', feedback: 'Feedbacks', rating: 'Rating'};
  
  constructor(public global: Globals, private http: HttpClient, private cookieService: CookieService, private router: Router) {
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;
   
    this.BaseUrl = this.global.APIURL;
    this.base_url = this.global.APIURL;
    
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });
   }

  ngOnInit() {
    console.log("user componenet for booking");
    this.getPageData();
    this.getBookingInfo();
  }


  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "company-ride" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          console.log(responseData);
          //console.log("Local Storage");
          //console.log(JSON.parse(localStorage.getItem('user')));
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
          //console.log(LOCALSTORAGE);
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;
         console.log(this.global.country);
          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
         console.log(this.pageData);
          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }



  getBookingInfo = function () {
    

    this.http.get(this.BASE_URL + 'api/users/service/getBookingDetails', {headers: this.headers
    }).
    subscribe(
      response=> {
        this.general_booking = response.data;
        console.log(this.general_booking);
    },
    error=> {
        return false;
    });


};



}
