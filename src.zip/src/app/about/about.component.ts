import { Component, OnInit } from '@angular/core';
import { Globals } from '../global';
import { Router } from '@angular/router';


@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  constructor(public global: Globals,private router: Router) { }

  ngOnInit() {
    console.log("Hello");
    console.log(localStorage.getItem('user'));
    
    if(localStorage.getItem('user'))
    {
      var obj = localStorage.getItem('user');
      var user = JSON.parse(obj) ;
      console.log(user.user_info);
      this.router.navigate(['/'+JSON.parse(localStorage.getItem('user')).user_info]).then(() => {
        window.location.reload();
       });
       
    }
  }


}
