import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Globals } from '../global';
import { Subject, throwError, Observable } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { NotifierService } from "angular-notifier";
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';

@Component({
  selector: 'app-driver-profile',
  templateUrl: './driver-profile.component.html',
  styleUrls: ['./driver-profile.component.css']
})
export class DriverProfileComponent implements OnInit {

  //===============================================//


  // toggle webcam on/off
  public showWebcamProfileImage = false;
  public showWebcamIdImage = false;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];
  // latest snapshot
  public webcamImage: WebcamImage = null;

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();



  //================================================//

  public country: string;
  public user = { email: "", password: "", fcm_key: "pwa" };
  public pageDriverRegData = {delete:'', payment_methods: '', id_verification_text: 'Upload An IDUnlock Account (Fingerprint / gestures / Private Information)', back_button: 'Back', take_a_picture: 'Take A Picture', upload_a_picture: 'Upload a picture', upload_an_id: 'Upload An ID', form_title: 'Registration Form Selfemployeed Drivers', business_connection: 'Business Connection (selfemployeed - Rental Car Driver, Counter/Service Provider)', business_conection_type: 'Business Connection (selfemployeed - Rental Car Driver, Counter/Service Provider)', driver_number: 'Driver Number ( Automatic Generated)', first_name: 'Driver Given Name', last_name: 'Driver Family Name', nationality: 'Nationality', 'username': 'Username', id_card: 'Driver ID Card Number', password: 'Password', password_repeat: 'Password-Repeat', country: 'Country', 'state': 'Province / Federal State', city: 'City / Municipality', 'zip': 'ZIP', 'street_number': 'Street Number', street_name: 'Driver Address - Street Name ', house: 'Address Driver - House / Apartment No.', floor: 'Address Driver -Floor', further_information: 'Address Driver - Further Information', email: 'Driver-Email', dialing_code: 'Dialing Code', mobile_number: 'Driver-Mobile Number', verification: 'Verification', driver_taxi_lic_no: 'Driver - Taxi License No.', driver_emp_no: 'Driver Employee Number', social_ins_num: 'Driver Social Insurance Number', license_plate: 'Driver Car - License Plate', vehicle_type: 'Vehicle Type', vehicle_make: 'Vehicle Make', make_type: 'Vehicle Brand Type', powertrain: 'Powertrain', combustion: 'Combustion', hybrid: 'Hybrid', fullemp: 'Full Electric', driver_mode: 'Driver Mode', autonom_mode: 'Autonom Mode', manpower: 'Man Power', email_verification_link: 'Email Verification Link', mobile_verification_code: 'Mobile Verification Code', date_of_create: 'Date of Create', time_of_create: 'Time of Create', location_of_create: 'Location of Create', date_of_change: 'Date of Change', time_of_change: 'Time of Change', location_of_change: 'Location of Change', submit_button: 'Submit' };
  public response: any;
  public tmp: any;
  public countryList: any;
  public mobileError: string;
  public message: string;
  public mobileOTP: string = "";

  public vehicleTypeList: any;
  public vehicleMakeList: any;
  public vehicleModelList: any;
  public vehicleModelListAll: any;

  public password_err: string = "";
  public password_err1: string = "";
  public isedit: boolean = false;
  public mobile_verification_code: string = "";
  public fileToUpload: File = null;
  public id_proof_imageErr:string = "";
  public general = {
    id: false,
    image: 'face-image.png',
    id_proof_image: 'identity-image.png',
    business_connection_type: '1',
    driver_number: '',
    first_name: '',
    last_name: '',
    username: '',
    id_card: '',
    password: '',
    password_repeat: '',
    country: '',
    state: '',
    city: '',
    zip: '',
    street_number: '',
    street_name: '',
    house: '',
    floor: '',
    further_information: '',
    email: '',
    dialing_code: '',
    mobile_number: '',
    driver_taxi_lic_no: '',
    driver_emp_no: '',
    social_ins_num: '',
    license_plate: '',
    vehicle_type: '1',
    vehicle_make: '1',
    make_type: '',
    powertrain: 'Combustion',
    driving_mode: 'Driver',
    email_verification_link: true,
    mobile_verification_code: true,
    is_mobile_verified: true,
    date_of_create: '',
    time_of_create: '',
    location_of_create: '',
    date_of_change: '',
    time_of_change: '',
    location_of_change: '',
    role: 'driver',
    payment_methods: []
  };
  public business_connection_type_list: any = [];
  public mcities: any = [];
  public paymentmcities: any = [];
  disabled = false;
  showFilter = false;
  limitSelection = false;
  selectedItems: any = [];
  selectedPayItems: any = [];
  dropDownSettings: any = {};
  dropDownSettingspay: any = {};
  public paymentMethodDetails: any = [];
  public paymentMethods: any = [];


  //================================================================//
  public first_nameErr :string  = "";
  public last_nameErr :string  = "";
  public id_cardErr :string  = "";
  public business_connection_typeErr:string = "";

 
  public BaseUrl: string = '';
  public BASE_URL: string = '';
  public TOKEN: string = '';
  public headers: any = {};
  public business_connection_name = "";
  public tempUserMobile_number: string = "";


  //=============== ALERT INTITIALIZATION ===================================//
  public email_alert: string = '';
  public mobile_number_alert: string = '';
  public tmpCounter: number = 0;
  public business_connection_list: any = [];


  private readonly notifier: NotifierService;
  constructor(public global: Globals, private http: HttpClient, notifierService: NotifierService, private cookieService: CookieService, private router: Router) {

    this.getCountry();
    this.notifier = notifierService;

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;

    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;
    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({ "token": this.TOKEN, "Content-Type": "application/json" });

    this.getPaymentMethods();



  }
  error = new Subject<string>();

  ngOnInit() {

    let driverdata = JSON.parse(localStorage.getItem("user")).userDetail;

    let conn: any = [];
    console.log(driverdata.company_id);
    if (driverdata.commpany_id!="" || driverdata.driver_company!="") {
      conn = JSON.parse(this.cookieService.get('company_driver_connection'));
      this.business_connection_list = conn;


    }
    else {
      conn = JSON.parse(this.cookieService.get('driver_connection'));
      this.business_connection_list = conn;

    }
    this.general.business_connection_type = conn[0].id;
    console.log(this.business_connection_list);

    this.mcities = conn;
    let pay_conn = JSON.parse(this.cookieService.get('pay'));
    this.getPaymentMethods();

    this.paymentmcities = pay_conn;


    this.dropDownSettings = {
      singleSelection: false,
      id_field: 'id',
      textField: 'text',
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: this.showFilter
    };
    this.dropDownSettingspay = {
      singleSelection: false,
      id_field: 'id',
      textField: 'payment_method_name',
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: this.showFilter
    };
    this.getCountry();
    this.getDriverRegPageData();
    this.getVehicleType();
    this.getVehicleMake();
    this.getVehicleMakeModel();


    console.log(this.business_connection_name);


  }


  getPaymentMethods = function () {
    this.http.get(this.BASE_URL + 'api/general/getPaymentMethods', {
      headers: this.headers
    }).
      subscribe(
        response => {


          this.msg = response.data.message;
          this.paymentMethodDetails = response.data1;
          this.paymentMethods = response.data;

          this.getUserData();
        },
        error => {
          return false;
        });
  };



  getDriverRegPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "Self Employee Registration" }
    )
      .subscribe(
        responseData => {

          this.tmp = responseData;
          var cookie = JSON.parse(this.cookieService.get('language_code'));
          this.global.country = cookie.language;

          if (this.global.country == 'en') {
            this.pageDriverRegData = this.tmp.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageDriverRegData = this.tmp.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageDriverRegData = this.tmp.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageDriverRegData = this.tmp.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageDriverRegData = this.tmp.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageDriverRegData = this.tmp.data.content_es;
          }

        },
        error => {
          this.error.next(error.message);
        }
      );
  }



  public ngAfterViewInit() {
    this.getBusinessConnection();
    // this.getUserData();

  }
  onItemSelect(item: any) {

  }
  onSelectAll(items: any) {

  }

  getCountry() {
    this.http.get(this.global.APIURL + "api/general/languageList").subscribe(
      responseData => {
        this.global.setCountryList(responseData);
        this.countryList = responseData;
        this.countryList = this.countryList.data;
      },
      error => {
        this.error.next(error.message);
      }
    );

  }

  getDriverRegPageDataa() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "Self Employee Registration" }
    )
      .subscribe(
        responseData => {
          this.tmp = responseData;
          if (this.global.country == 'en') {
            this.pageDriverRegData = this.tmp.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageDriverRegData = this.tmp.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageDriverRegData = this.tmp.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageDriverRegData = this.tmp.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageDriverRegData = this.tmp.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageDriverRegData = this.tmp.data.content_es;
          }
        },
        error => {
          this.error.next(error.message);
        }
      );
  }


  getVehicleType() {

    // this.cookieValue = this.cookieService.get('Test');

    this.http.get(this.global.APIURL + "api/general/getVehicleType").subscribe(
      responseData => {
        let vehicletemp: any = responseData;
        vehicletemp = vehicletemp.data;
        this.vehicleTypeList = vehicletemp;
      },
      error => {
        this.error.next(error.message);
      }
    );

  }

  getVehicleMake() {
    this.http.get(this.global.APIURL + "api/general/getVehicleMake").subscribe(
      responseData => {
        let vehicletemp: any = responseData;
        vehicletemp = vehicletemp.data;
        this.vehicleMakeList = vehicletemp;
      },
      error => {
        this.error.next(error.message);
      }
    );

  }

  changeModel() {


    this.vehicleModelList = this.vehicleModelListAll[this.general.vehicle_make];

    this.general.make_type = this.vehicleMakeList[0].id;

  }

  getVehicleMakeModel() {
    this.http.get(this.global.APIURL + "api/general/getVehiclemodelBrand").subscribe(
      responseData => {
        let vehicletemp: any = responseData;
        vehicletemp = vehicletemp.data2;
        this.vehicleModelListAll = vehicletemp;
        this.vehicleModelList = this.vehicleModelListAll[this.general.vehicle_make];

        this.general.make_type = this.vehicleModelList[0].id;
      },
      error => {
        this.error.next(error.message);
      }
    );

  }

  handleFileInput(files: FileList, FileName: string) {

    this.fileToUpload = files.item(0);
    const formData: FormData = new FormData();
    formData.append('file', this.fileToUpload, this.fileToUpload.name);
    formData.append('data', 'driver');
    this.http.post(
      this.global.APIURL + "api/users/auth/uploadImage",
      formData
    )
      .subscribe(
        responseData => {

          this.tmp = responseData;
          if (FileName == 'image') {
            this.general.image = this.tmp.file_name;
          }
          else if (FileName == 'id_proof_image') {
            this.general.id_proof_image = this.tmp.file_name;
          }

        },
        error => {

          this.error.next(error.message);
        }
      );
  }
  verifyOTP() {
    if (this.mobileOTP == this.mobile_verification_code) {

      this.onSubmit();
    }
  }
  checkPasswords(pass: string, confirmPass: string) { // here we have the 'passwords' group
    return pass === confirmPass ? null : { notSame: true }
  }

  validationInputPwdText(value: string) {
    this.password_err = "";
    var mediumRegularExp = new RegExp("^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9])))(?=.{6,})");

    if (mediumRegularExp.test(value)) {
      this.password_err = "";

    } else {
      this.password_err = "Passwords must contain at least 8 characters, including uppercase, lowercase letters and numbers.Password";
    }
  };

  confirmPass(value1: string, value2: string) {

    this.password_err1 = "";

    if (value1 == value2) {
      this.password_err1 = "";


    } else {
      this.password_err1 = "Passwords must be matched";
    }
  };



  getBusinessConnection = function () {

    var formdata = { connection_for: 'driver' };
    this.http.post(this.global.APIURL + 'api/general/businessConnection', formdata, {
    }).
      subscribe(
        response => {
          this.business_connection_type_list = response.data1;

          return false;
        },
        error => {
          return false;
        });

  };




  validateCheck(checked: any) {

    if (!checked) {
      return false;
    }

    if (this.general.mobile_number == '') {
      this.general.mobile_number = '';
      alert("Please enter mobile Number");

      return false;
    }
    if (this.general.dialing_code == '') {
      this.general.dialing_code = '';
      alert("Please enter dialing code");

      return false;
    }


  }
  smsCodeEntry() {
    //console.log(this.tmpCounter++);
    console.log(this.mobile_verification_code);
  }

  formValidate()
  {
    this.first_nameErr = "";
    this.last_nameErr = "";
    this.id_cardErr = "";  
    this.business_connection_typeErr = ""; 
    
    let isFormValid = true;
    if(this.general.business_connection_type == "")
    {
      this.business_connection_typeErr = "please select business connection";
    }
    if(this.general.first_name =="")
    {
      this.first_nameErr = "Please enter first name";
      isFormValid = false;
    }
    if(this.general.last_name =="")
    {
      this.last_nameErr = "Please enter last name";
      isFormValid = false;
    }
    if(this.general.id_card =="")
    {
      this.id_cardErr = "Please enter ID card number";
      isFormValid = false;
    }
    return isFormValid;

  }

  onSubmit() {

 
    if (!this.formValidate()) {
      return false;
    }
    else {
      this.http.post(
        this.global.APIURL + "api/driver/profile",
        this.general, {
        headers: this.headers
      }
      )
        .subscribe(
          responseData => {
            var res: any;
            res = responseData;
            if (res.message) {
              this.notifier.notify("success", res.message);
              this.isedit = false;
              this.mobileOTP = "";
              this.mobile_verification_code = "";

            }
            return false;
          },
          error => {
            console.log(error.message)
            this.error.next(error.message);
          }
        );
      return false;;
    }
   
  }




  search = function (idx: any, value: any) {

    var ins = idx;
    this.email_alert = '';
    var formdata: any = {};
    if (idx == "email") {
      if (value == '') {
        this.email_alert = 'Please enter  email address';
        return false;
      }
      if (!this.ValidateEmail(value)) {
        this.email_alert = 'Please enter  a valid email address';
        this.general.email = '';
        return false;
      }
      formdata = { email: value, user_type: "driver" };
    }
    else if (idx == "mobile_number") {
      if (value == '') {
        this.mobile_number_alert = 'Please enter valid Mobile number';
        return false;
      }
      formdata = { mobile_number: value, user_type: "driver" };
    }
    var api_method = 'search';
    this.http.post(this.BASE_URL + 'api/general/' + api_method, formdata, {
    }).
      subscribe(
        response => {

          if (idx == "email") {
            this.email_alert = 'Email already exists';
            this.general.email = '';
          }
          else if (idx == "mobile_number") {
            this.mobile_number_alert = 'Mobile number already exists';
            this.general.mobile_number = '';
          }
          this.mobile_number_alert
          return false;

        },
        error => {
          return false;
        });

  }

  ValidateEmail(inputEmailTxt: any) {

    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (inputEmailTxt.match(mailformat)) {

      return true;
    }
    else {
      //alert("You have entered an invalid email address!");

      return false;
    }
  }
  isNumberKey(idx: any, val: any) {

    var regex = /^[0-9]*(?:\.\d{1,2})?$/;    // allow only numbers [0-9] 
    if (!regex.test(val)) {

      if (idx == 'zip') {
        this.general.zip = '';
      }
      else if (idx = 'mobile_number') {
        this.general.mobile_number = '';
      }

    }
  }


  getUserData() {


    this.http.get(
      this.global.APIURL + 'api/driver/profile', {
      headers: this.headers
    })
      .subscribe(
        responseData => {

          var userdata: any = responseData;
          this.general = userdata.data;
          this.tempUserMobile_number = this.general.mobile_number;
          var tempPaymentMethods: any = [];
          var tmpBusinessConnectionType: any = [];
          

          for (let i = 0; i < this.general.payment_methods.length; i++) {
            let pay = this.general.payment_methods[i];

            tempPaymentMethods.push(this.paymentMethodDetails[pay]);

          }
          for (let i = 0; i < this.business_connection_list.length; i++) {
            console.log(this.business_connection_list[i]);
            console.log(this.general.business_connection_type);

            if (this.general.business_connection_type == this.business_connection_list[i].id) {
              this.business_connection_name = this.business_connection_list[i].text;
              break;
            }
          }
          this.selectedPayItems = tempPaymentMethods;

        },
        error => {
          this.error.next(error.message);

          if (error.error.error.trim() == "Token Expired") {
            this.router.navigate(['logout']);
          }
        }
      );
  }




  //========= web cam codes================//

  openCam(imageType: string) {
    if (imageType == 'profile_picture') {
      this.showWebcamProfileImage = true;
      this.showWebcamIdImage = false;
    }
    else {
      this.showWebcamProfileImage = false;
      this.showWebcamIdImage = true;
    }
  }
  saveTofile(snapshotData: any, uploadfr: any) {

    var formdata = { data: snapshotData, user_type: 'driver' };

    this.http.post(this.BASE_URL + 'api/general/base64Tojpeg', formdata, {
    }).
      subscribe(
        response => {
          let tmpResponse: any = response;

          if (uploadfr == "image") {
            this.general.image = tmpResponse.data;
            this.showWebcamProfileImage = false;
          }
          else {
            this.general.id_proof_image = tmpResponse.data;
            this.showWebcamIdImage = false;
          }
          //$scope.general.location_of_change  = response.data.location;
          return false;

        },
        error => {

          return false;
        });
  }


  public triggerSnapshot(): void {
    this.trigger.next();
  }


  public handleInitError(error: WebcamInitError): void {
    this.errors.push(error);
  }

  public showNextWebcam(directionOrDeviceId: boolean | string): void {
    // true => move forward through devices
    // false => move backwards through devices
    // string => move to device with given deviceId
    this.nextWebcam.next(directionOrDeviceId);
  }

  public handleImage(webcamImage: WebcamImage): void {
    this.webcamImage = webcamImage;
    if (this.showWebcamProfileImage) {
      this.saveTofile(this.webcamImage.imageAsDataUrl, 'image');
      //triggerObservable
    }
    else {
      this.saveTofile(this.webcamImage.imageAsDataUrl, 'id');
    }
  }

  public cameraWasSwitched(deviceId: string): void {

    this.deviceId = deviceId;
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public get nextWebcamObservable(): Observable<boolean | string> {
    return this.nextWebcam.asObservable();
  }

  toggleFunction() {
    if (this.isedit) {
      this.isedit = false;
    }
    else {
      this.isedit = true;
    }
  }

  delete (user_type:any)
  {
      var confirmers = confirm("Are you sure, you want to delete it?");
            
      if (confirmers)
      {
             console.log(user_type);
          var formdata = {
              user_type: user_type,
              user_detail: localStorage.getItem('user_id')
          };
          this.http.post(this.BASE_URL + 'api/user/deactivateuser', formdata, 
          {headers:this.headers
          }).
          subscribe(
            response=> {
              // $scope.getprofile();
             // console.log(response.data);
           
            //  localStorage.removeItem('user_id');
            //  console.log(localStorage.getItem('user_id'));
             this.router.navigate(['logout']);

              return false;

          },
          error=> {
              //  console.log(response);
              // $scope.errMessage = response.data.message;
              return false;
          });
      }
      else
      {

      }

      return false;


  };

}
