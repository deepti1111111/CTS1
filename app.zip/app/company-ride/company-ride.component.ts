import { Component, OnInit, ViewChild, ElementRef, OnDestroy, Directive, Input } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { Globals } from '../global';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import * as moment from 'moment';
import { CompileShallowModuleMetadata } from '@angular/compiler';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';


@Component({
  selector: 'app-company-ride',
  templateUrl: './company-ride.component.html',
  styleUrls: ['./company-ride.component.css']
})
export class CompanyRideComponent implements OnDestroy, OnInit {

  modalRef: BsModalRef;
  //====================================================== DATATABLE ========================================//

  @ViewChild(DataTableDirective, {static: false})
  @ViewChild('modalRide', { static: true }) modalRide: ElementRef;

  @ViewChild('messageModal', { static: true }) messageModal: ElementRef;

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective; 
  dtOptions: any = {};
  dtInstance: DataTables.Api;
  dtTrigger: Subject<any> = new Subject();
  isDtInitialized:boolean = false;
  //=== Start date range picker====//
  selected: any;
  alwaysShowCalendars: boolean;
  ranges: any = {
    'Today': [moment(), moment()],
    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
  }
  invalidDates: moment.Moment[] = [moment().add(2, 'days'), moment().add(3, 'days'), moment().add(5, 'days')];

  isInvalidDate = (m: moment.Moment) => {

    return this.invalidDates.some(d => d.isSame(m, 'day'))
  }

  //==== End date range picker=====//

  public TOKEN: string = "";
  error = new Subject<string>();
  public config: any;
  public BaseUrl: string;
  public subscribed: boolean = false;
  public headers: any = {};
  public is_edit: boolean = false;
  public BASE_URL: string = '';
  public companyDriverList: any = [];
  public driverVehicleList: any = [];
  public companyDriverLists: any = [];
  public company_driver_count: number = 0;

  public ride: any;
  public vehicleTypeList: any;
  public vehicleMakeList: any;
  public make_typeList: any;

  public pageData: any = {
    rides: "Rides",
    search_btn: "Search",
    search_placeholder: "Seach",
    ride_list: "List Of Rides",
    start_date: "Start Date",
    end_date: "End Date",
    show_item: "Show Item",
    select_all: "Select All",
    sno: "Booking-ID",
    pick_up: "Pickup Location",
    drop: "Drop Location",
    date: "Date",
    fare: "Fare",
    driver_name: "Driver Name",
    car_no: "Car Number",
    action: "Action",
    ride_detial: "Ride Detail",
    drivername: "Driver's Name",
    customername: "Customer's Name",
    pickup: "Pick-up Location",
    vehicletype: "Vehicle Type",
    series: "Series",
    tip: "Offered Tip",
    datetime: "Booking Date & Time",
    feedback: "Feedbacks",
    rating: "Rating",
    revenues: "Revenues",
    week: "Weekly Total",
    month: "Mothly Total",
    year: "Yealy Total",
    make: "Make",
    booking_id: ''
  };

  public msg: string = "";
  public paymentMethodDetails: any;
  public paymentMethods: any;

  public driverVehicleLists: any = [];
  public isadhoc: boolean = true;
  public country: string;
  public rideList: any = [];

  public date1: string = "";
  public date2: string = "";


  public general; any = { id: false, image: 'face-image.png', id_proof_image: 'identity-image.png', business_connection_type: '5', driver_number: '', first_name: '', last_name: '', username: '', id_card: '', password: '', password_repeat: '', country: 'CN China', state: '', city: '', zip: '', street_number: '', street_name: '', house: '', floor: '', further_information: '', email: '', dialing_code: '', mobile_number: '', driver_taxi_lic_no: '', driver_emp_no: '', social_ins_num: '', license_plate: '', vehicle_type: '1', vehicle_make: '1', make_type: '', powertrain: 'Combustion', driving_mode: 'Driver', email_verification_link: '1', mobile_verification_code: '0', is_mobile_verified: '1', date_of_create: '', time_of_create: '', location_of_create: '', date_of_change: '', time_of_change: '', location_of_change: '', role: 'driver', payment_methods: false };



  constructor(public global: Globals,  private modalService: BsModalService,private http: HttpClient, private cookieService: CookieService, private router: Router
  ) {
    this.alwaysShowCalendars = false;

    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });

  }


  ngOnInit() {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10
    };
    this.getPageData();
    this.getRideInfo();
    this.getVehicleTypeDetails();
    this.getVehicleMake();
    this.getVehiclemodelBrand();
    
  }
  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  rerender(): void {
    try {
      this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        // Destroy the table first
        dtInstance.destroy();
        // Call the dtTrigger to rerender again
        this.dtTrigger.next();
      });
    } catch (err) {
      console.log(err);
    }
  }



  rangeClicked(range: any) {
  }
  datesUpdated(range) {
    if (range) {
     
      this.getRideByTimeFilter(this.global.convert(range.startDate._d), this.global.convert(range.endDate._d))
    }
  } 
  getPageData() {
    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "company-ride" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));

          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
          console.log(this.pageData);
          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getRideInfo() {
    this.http.get(this.BASE_URL + 'api/companies/service/getBookingDetails', {
      headers: this.headers
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.rideList = tmpResponse.data;
      this.rerender();
    }, error => {
      if (error.error.error == "Token Expired") {
        this.router.navigate(['logout']);
      }
      return false;
    });
  };

  getRideByTimeFilter(date1, date2) {
    this.http.post(this.BASE_URL + 'api/companies/service/getBookingDetails',
      { date1: date1, date2: date2 },
      {
        headers: this.headers

      }).subscribe(response => {
        let tmpResponse: any = response;
        this.rideList = tmpResponse.data;       
      }, error => {

        return false;

      });
  };
  getVehicleTypeDetails () {
    var api_method = 'vehicleTypeList';
   
    this.http.get(this.BASE_URL + 'api/vehicle/' + api_method, {
        headers: this.headers
    }).subscribe(response=> {
      let tmpResponse:any = response;
       this.vehicleTypeList = tmpResponse.dataList;
        return false;
    }, error=> {
        return false;
    });
  };
  getVehicleMake()  {
    var formdata = {};
    var api_method = 'getVehicleMake';
    this.http.post(this.BASE_URL + 'api/general/' + api_method, formdata, {}).subscribe(
      response=> {
        let tmpResponse:any = response;
        this.vehicleMakeList = tmpResponse.datalist;
        return false;
    }, error=> {
        return false;
    });
};

getVehiclemodelBrand () {
  
  this.http.get(this.BASE_URL + 'api/general/getVehiclemodelBrand').subscribe(
    response=> {
      let tmpResponse:any = response;
      this.make_typeList = tmpResponse.data3;
      
      return false;
  }, 
  error=> {
      this.make_typeList = false;
      this.general.make_type = false;
      return false;
  });
};


  viewRide(ob: any) { 
    this.ride = ob;


    for (let i = 0; i < this.vehicleTypeList.length; i++) {
      if (ob.vehicle_type_id == this.vehicleTypeList[i].ID) {
        this.ride.vehicle_type_name = this.vehicleTypeList[i].type_name;
      }
    }

    for (let i = 0; i < this.vehicleMakeList.length; i++) {
      if (ob.vehicle_make_id == this.vehicleMakeList[i].id) {
        this.ride.vehicle_make = this.vehicleMakeList[i].make;
      }

    }


    for (let i = 0; i < this.make_typeList.length; i++) {
      if (ob.make_type_id == this.make_typeList[i].id) {
        this.ride.make_type_model = this.make_typeList[i].model_name;
      }

    }


    this.modalRef = this.modalService.show(this.modalRide);

    // $("#modalRide").modal("show");

  };

  delRide(id) {
    if (confirm("Are you sure, you want to delete it?")) {
      this.http.post(this.BASE_URL + 'api/companies/service/delBookingDetails', { id: id },
        {
          headers: this.headers

        }).subscribe(response => {
          let tmpResponse: any = response;
          this.msg = tmpResponse.message;
          // $("#message_modal").modal("show");
          this.modalRef = this.modalService.show(this.messageModal);

          setTimeout(() => {
            ///  $("#message_modal").modal("hide");
            this.modalRef.hide();
          }, 2000);
          this.getRideInfo();

        }, error => {
          this.msg = error.error.error;
          return false;

        });

    }
    

  };
  closeeModal()
  {
    this.modalRef.hide();
  }
 

}