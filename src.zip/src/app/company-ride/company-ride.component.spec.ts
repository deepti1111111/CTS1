import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyRideComponent } from './company-ride.component';

describe('CompanyRideComponent', () => {
  let component: CompanyRideComponent;
  let fixture: ComponentFixture<CompanyRideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanyRideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyRideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
