import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
  public country: string = 'uk';
  public langImg: string = 'flagicon6.jpg';
  public APIURL: string = "https://www.chawtechsolutions.co.in/metrotaxi/";
  public AD_URL: string = "https://www.chawtechsolutions.co.in/metrotaxi/uploads/ads/";

  public pageData = { About: "About", Bookings: "Bookings", Home: "Home", Profile: "Profile", Revenue: "Revenue", Subscription: "Subscription", change_password: "Change Password", contact_us: "Contact Us", create_new_ac: "Create New Account", driver_mgmt: "Driver's Management", email_address: "Email Address", forget_pass_btn: "Forget Password", i_am_not_robot: "I am not a Robot", login: "Login", login_btn: "Login", logout: "Logout", my_vehicles: "My Vehicles", password: "Password", payment_method: "Payment Method", privacy_policy: "Privacy Policy", register_btn: "Register With Us", rides: "Rides", service: "Service", vehicle_mgmt: "Vehicle's Management" };
  public User: any;
  public paymentMethodDetails: any;
  private Token: string;

  public reCaptchaSiteKey: string = '6LfVqckUAAAAAKT9IyfObpZQHz2uBxir9-awy8D-';
  public reCaptchaSecretKey: string = '6LfVqckUAAAAAIo2KpAxSoSpVoISaAQwpvnSyEhP';

  public HAppId = "gHUYOloMc1XQ7h4uE3dr";
  public HAppCode = "MD1AUWEKC9MrP8r1rXH49Q";

  public HAPIKEY = "V9o5pMc99HUiKxYzRWf5NwULNjDBVEjuF_7pA8HTPBk";
  public actionClass: string = "panel-collapse collapse out";
  public expandeClass: string = "panel-collapse collapse in";
  public collapseClass: string = "panel-collapse collapse out";
  public countryList: any;
  setLang(country: string, img: string) {
    this.country = country;
    this.langImg = img;
  }

  getAPIURL() {
    return this.APIURL;
  }

  getToken() {
    return this.Token;
  }
  setToken(tk: string) {
    this.Token = tk;
  }

  setUserData(tmp: any) {
    this.User = tmp;
  }
  getUserData() {
    return this.User;
  }


  setPageData(tmp: any) {
    this.pageData = tmp;
  }
  getPageData() {
    return this.pageData;
  }
  getLang() {
    return this;
  }
  setCountryList(ob) {
    this.countryList = ob.data;
  }
  getCountryList() {
    return this.countryList;
  }


  getPaymentMethodList() {
    return this.paymentMethodDetails;
  }
  setPaymentMethodList(val: any) {
    this.paymentMethodDetails = val;
  }
  convert(str: any) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  ValidateEmail(inputEmailTxt: any) {

    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (inputEmailTxt.match(mailformat)) {

      return true;
    }
    else {
      //alert("You have entered an invalid email address!");

      return false;
    }
  }

  phonenumber(inputtxt: any) {
    var phoneno1 = /^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/;
    var phoneno2 = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    var phoneno3 = /^\d{10}$/;
    if (inputtxt.match(phoneno1) || inputtxt.match(phoneno2) || inputtxt.match(phoneno3)) {
      return true;
    }
    else {
      return false;
    }
  }
  appnedClassexpandCollapse(btn: any, div_id: string, booking_id: string) {

    let plusBtns = document.getElementsByClassName("plusbtnClass");//plus btn
    let minusBtns = document.getElementsByClassName("minusbtnClass");//minus button//className//panel-collapse collapse
    let panel_collapse = document.getElementsByClassName("panel-collapse collapse");//minus button//className//panel-collapse collapse
    console.log(panel_collapse);
    for (let i = 0; i < plusBtns.length; i++) {
      plusBtns[i].className = "plusbtnClass show";

    }
    for (let i = 0; i < minusBtns.length; i++) {
      minusBtns[i].className = "minusbtnClass hide";

    }
    for (let i = 0; i < panel_collapse.length; i++) {
      panel_collapse[i].className = this.collapseClass;

    }
    // return false;
    if (btn == 1) {
      //plus button is clicked.
      // add class 'hide' in plus button
      // add clsss show in minus button
      document.getElementById("plusbtn" + booking_id).className = " plusbtnClass hide";//plus btn
      document.getElementById("minusbtn" + booking_id).className = " minusbtnClass show";//minus button
      document.getElementById(div_id + booking_id).className = this.expandeClass;//expand div

    }
    else {
      //minus button is clicked.
      // add class 'hide' in minus button
      // add clsss show in show button
      document.getElementById("plusbtn" + booking_id).className = " plusbtnClass show";//plus btn
      document.getElementById("minusbtn" + booking_id).className = " minusbtnClass hide";//minus button
      document.getElementById(div_id + booking_id).className = this.collapseClass;//collpase div
    }

  }

}