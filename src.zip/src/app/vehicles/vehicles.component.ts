import { Component, OnInit, Directive, Input, ViewChild, ElementRef, TemplateRef, ContentChild } from '@angular/core';
import { BehaviorSubject, Observable, interval } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { FormsModule } from '@angular/forms';
import { Subject, throwError, timer } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { DataTableDirective } from 'angular-datatables';

declare var $: any;

@Component({
  selector: 'app-vehicles',
  templateUrl: './vehicles.component.html',
  styleUrls: ['./vehicles.component.css']
})
export class VehiclesComponent implements OnInit {
  modalRef: BsModalRef;
  @ViewChild('modalVehicle', { static: true }) modalVehicle: ElementRef;
  @ViewChild('messageModal', { static: true }) messageModal: ElementRef;
  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective; 
  dtOptions: any = {};
  dtInstance: DataTables.Api;
  dtTrigger: Subject<any> = new Subject();
  isDtInitialized:boolean = false;
  public config: any;
  error = new Subject<string>();
  public BASE_URL: string;
  public TOKEN: any
  public pageData = { vehicle_management: 'Vehicle Management ', list_of_vehicle: ' List of vehicles', add_vehicle_btn: 'Add vehicle', start_date: 'Start Date', end_date: 'End Date', submit: 'Go', sno: 'Sr.', vehicle_name: 'Vehicle Name', make: 'Vehicle Brand', brand_type: 'Vehicle Brand Type', lic_plate: 'License Plate', powertrain: 'Powertrain', action: 'Action', vehicle_detail: 'Vehicle Detail', assigned_driver: 'Assigned Driver', driver_name: "Driver's Name", picture: 'Picture' };
  public base_url: string;
  public BaseUrl: string;
  public headers: any;

  public general_vehicle = { id: '', powertrain: 'Combustion', vehicle_doc: 'doc.jpg', image: 'err.jpg', vehicle_type_id: '1', vehicle_make_id: '1', make_type_id: '137', license_plate_no: '', driving_mode: 'Driver' };
  public vehicle: any = {};
  public content_vehicle: any = {};
  public subscribed: boolean = true;
  public subscriptionMessage: string = "";
  public general: any = {};
  public vehicleTypeList: any;
  public vehicleMakeList: any;
  public make_typeList: any;
  public msg: string = "";
  public driverVehicleList: any = [];
  public driverVehicleLists: any = [];

  constructor(public global: Globals, private modalService: BsModalService, private http: HttpClient, private cookieService: CookieService, private router: Router) {
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });

    this.base_url = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
  }

  ngOnInit() {
    this.getPageData();
    this.getPageDataAddVehicle();



    this.getprofile();
    this.getSubscriptionInfo();
    this.getVehicleManagementInfo();

    this.getVehicleType();
    this.getVehicleMake();
    this.getVehiclemodelBrand(this.general.vehicle_make);

  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  rerender(): void {
    try {
      this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        // Destroy the table first
        dtInstance.destroy();
        // Call the dtTrigger to rerender again
        this.dtTrigger.next();
      });
    } catch (err) {
      console.log(err);
    }
  }




  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "company-vehicle-management" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));

          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }

          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  uploadVehicleImageDoc(img: any, upfr: string) {
    //return 0;
    var varFile = img.files[0];
    var fd = new FormData();
    fd.append('file', varFile);
    fd.append('data', 'vehicle');

    //console.log(fd); return false;
    this.http.post(this.BASE_URL + 'api/users/auth/uploadImage', fd, {

      headers: {
        'Content-Type': undefined
        //'token': TOKEN
      }
    }).subscribe(
      response => {
        let tmpResponse: any = response;

        if (tmpResponse.success === 'true') {
          if (upfr == 'image') {
            this.general_vehicle.image = tmpResponse.file_name;
          }
          else {
            this.general_vehicle.vehicle_doc = tmpResponse.file_name;
          }
        }


      },
      error => {

      });
  };
  getSubscriptionInfo() {
    console.log("getSubscriptionInfo info");
    var api_method = "subscriptionInfo";
    this.http.get(this.BASE_URL + 'api/companies/account/' + api_method,
      {
        headers: this.headers
      }).subscribe(
        response => {
          console.log('getSubscriptionInfo');
          let tmpResponse: any = response;
          if (tmpResponse.success == "true") {
            this.subscribed = true;
            this.subscriptionMessage = tmpResponse.message;
           // this.modalRef = this.modalService.show(this.TailSubscription);
           // $("#TailSubscription").modal("hide");
          }
          else {
            this.subscribed = false;
            this.subscriptionMessage = tmpResponse.message;
          //  $("#TailSubscription").modal("show");
          }
          console.log(this.subscribed);

          return false;
        }
        , error => {
          return false;
        });
  };
  viewCompanyVehicle(ob: any) {
    console.log(this.pageData);

    this.vehicle = ob;
    this.modalRef = this.modalService.show(this.modalVehicle);
    //console.log(ob);
  };
  closeModal()
  {
    this.modalRef.hide();
  }

  getPageDataAddVehicle() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "add-vehicle" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));

          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.content_vehicle = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.content_vehicle = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.content_vehicle = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.content_vehicle = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.content_vehicle = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.content_vehicle = this.config.data.content_es;
          }
          console.log(this.content_vehicle);

          //  this.global.setPageData(this.content_vehicle);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getprofile() {

    this.http.get(this.BASE_URL + 'api/driver/profile',
      { headers: this.headers }
    ).subscribe(response => {
      let tmpResponse: any = response;
      this.general = tmpResponse.data;
      return false;
    }, error => {
      return false;
    });
  };


  getVehicleType() {
    var formdata = { status: 1 };
    var api_method = 'getVehicleType';

    this.http.post(this.BASE_URL + 'api/general/' + api_method, formdata, {
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.vehicleTypeList = tmpResponse.data;
      return false;

    }, error => {
      return false;
    });
  };

  getVehicleMake() {
    var formdata = { status: 1 };
    var api_method = 'getVehicleMake';

    this.http.post(this.BASE_URL + 'api/general/' + api_method, formdata, {
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.vehicleMakeList = tmpResponse.data;
      return false;

    }, error => {
      return false;
    });
  };

  getVehiclemodelBrand(val: string) {
    var formdata = { make_id: val };
    this.http.post(this.BASE_URL + 'api/general/getVehiclemodelBrand', formdata, {
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.make_typeList = tmpResponse.data;
      this.general_vehicle.make_type_id = tmpResponse.selected_id;

      ////this.vehicleMakeBrandList = tmpResponse.data;
      return false;

    }, error => {
      this.make_typeList = false;
      this.general.make_type = false;
      return false;
    });
  };


  blockVehicle(id: string, status: number) {

    if (confirm("Are you sure")) {

      this.http.post(this.BASE_URL + 'api/drivers/vehicle/blockVehicleDetails',
        { id: id, block_status: status },
        {
          headers: this.headers
        }).subscribe(response => {
          let tmpResponse: any = response;
          this.msg = tmpResponse.message;
          this.modalRef = this.modalService.show(this.messageModal);
          setTimeout(()=> {
            this.modalRef.hide();
          }, 2000);

          this.getVehicleManagementInfo();
        }, error => {
          this.msg = error.error.error;

          return false;
        });
    }




  };
  delVehicle(id:string) {

    if (confirm("Are you sure, you want to delete it?")) {

      this.http.post(this.BASE_URL + 'api/drivers/vehicle/delVehicleDetails', { id: id }, {
        headers: this.headers
      }).subscribe(response => {
        let tmpResponse: any = response;
        this.msg = tmpResponse.message;
        this.modalRef = this.modalService.show(this.messageModal);
        setTimeout(  ()=> {
         this.modalRef.hide();
        }, 2000);

        this.getVehicleManagementInfo();
      }, error => {

        this.msg = error.error.error;

        return false;
      });
    }




  };
  

  public errlicense_plate_no: string = "";

  getVehicleManagementInfo() {

    this.driverVehicleList = [];

    this.http.get(this.BASE_URL + 'api/drivers/vehicle/getVehicleDetails',
      {
        headers: this.headers
      }).subscribe(response => {
        let tmpResponse: any = response;
        console.log(tmpResponse.data);
        this.driverVehicleLists = [];
        this.driverVehicleLists = tmpResponse.data;
        this.rerender();
        return false;


      }, error => {
        return false;
      });


  };

  validation() {
    if (this.general_vehicle.license_plate_no == '') {
      this.errlicense_plate_no = 'Please Enter License Plate number';
      return false;
    }
    return true;

  };
  add_vehicle() {
    this.errlicense_plate_no = "";
    if (!this.validation()) {
      this.errlicense_plate_no = "Please enter license plate number";
      return false;
    }
    //console.log(TOKEN);
    if (confirm("Are you sure, you want to Add")) {
      this.http.post(this.BASE_URL + 'api/drivers/vehicle/addVehicle', this.general_vehicle, {
        headers: this.headers
      }).subscribe(response => {
        let tmpResponse: any = response;
        this.msg = tmpResponse.message;
        this.modalRef = this.modalService.show(this.messageModal);
       
        setTimeout(() => {
        this.modalRef.hide();
        }, 2000);
        this.router.navigate(['vehicles']);

      }, error => {

        this.errlicense_plate_no = error.error.error;

        return false;
      });
    }
  };




}
