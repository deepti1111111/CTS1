import { Component, OnInit } from '@angular/core';
import { Globals } from '../global';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(public global: Globals,private router: Router) { }

  ngOnInit() {
   
    if(localStorage.getItem('user'))
    {
      var obj = localStorage.getItem('user');
      var user = JSON.parse(obj) ;
      console.log(user.user_info);
      this.router.navigate(['/'+JSON.parse(localStorage.getItem('user')).user_info]).then(() => {
        window.location.reload();
       });
       
    }
  }

}
