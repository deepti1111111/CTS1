import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-payment-page',
  templateUrl: './driver-payment-page.component.html',
  styleUrls: ['./driver-payment-page.component.css']
})
export class DriverPaymentPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
