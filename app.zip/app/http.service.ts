import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Globals } from './global';
import { map, catchError } from 'rxjs/operators';
import { Subject, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class HttpService {
  error = new Subject<string>();
  res:any;
  constructor(private http: HttpClient,public  conf: Globals) { 
    
  }
  public postData: string
  getHeader() {
    console.log('getHeader 1');
    //const postData = {id:false,screen:"header"};
    return this.http.post(
      'https://www.chawtechsolutions.co.in/metrotaxi/api/general/getPageScreen',
      {id:false,screen:"header"}
    )
    .subscribe(
      responseData => {
        //console.log(responseData);
        return responseData;
      },
      error => {
        this.error.next(error.message);
      }
    );
    console.log('getHeader 2');
    console.log(this.res);
  }

  myMethod() {
    console.log('myMethod');
    return this.http.get('https://api.chucknorris.io/jokes/random').subscribe(
      responseData => {
        console.log(responseData);
        return responseData;
      },
      error => {
        this.error.next(error.message);
      }
    );;
  }
}