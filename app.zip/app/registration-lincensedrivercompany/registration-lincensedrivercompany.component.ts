import { Component, OnInit ,ViewChild,ElementRef} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Globals } from '../global';
import { Subject, Observable,throwError } from 'rxjs';
import { $ } from 'protractor';
import { NavComponent } from '../nav/nav.component';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { identifierModuleUrl } from '@angular/compiler';
import { resolve } from 'url';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

import { NotifierService } from "angular-notifier";

@Component({
  selector: 'app-registration-lincensedrivercompany',
  templateUrl: './registration-lincensedrivercompany.component.html',
  styleUrls: ['./registration-lincensedrivercompany.component.css']
})
export class RegistrationLincensedrivercompanyComponent implements OnInit {
  modalRef: BsModalRef; 
  @ViewChild('mobileVerification', { static: true }) mobileVerification: ElementRef;
  //===============================================//
  private readonly notifier: NotifierService;

  // toggle webcam on/off
  public showWebcamProfileImage = false;
  public showWebcamIdImage = false;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public driver_company_busness_licErr:string = "";
  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];
  // latest snapshot
  public webcamImage: WebcamImage = null;

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();



  //================================================//
  public country: string;
  public user = { email: "", password: "", fcm_key: "pwa" };
  public pageDriverRegData = { autonom_mode: "Autonom", back_button: "Back", business_conection_type: "Business Connection (Rental Car Driver, Counter/Service Provider)", business_connection: "Business Connection (selfemployeed - Rental Car Driver, Counter/Service Provider)", city: "City / Municipality", combustion: "Combustion", country: "Country", date_of_change: "Date of Change", date_of_create: "Date of Create", dialing_code: "Dialing Code", driver_company: "Driver - Company", driver_company_busness_lic: "Driver Company - Business License", driver_company_vat: "Driver Company - VAT, tax number", driver_emp_no: "Driver Employee Number", driver_mode: "Driver", driver_number: "Driver Number ( Automatic Generated)", driver_taxi_lic_no: "Driver - Taxi License No.", driving_mode: "Driving Mode", email: "Driver-Email", email_verification_link: "Email Verification Link", first_name: "Driver Given Name", floor: "Address Driver -Floor", form_title: "Licensed Company Driver Registration", fullemp: "Full Electric", further_information: "Address Driver - Further Information", house: "Address Driver - House / Apartment No.", hybrid: "Hybrid", id_card: "Driver ID Card Number", id_verification_text: "Upload An IDUnlock Account (Fingerprint / gestures / Private Information)", last_name: "Driver Family Name", license_plate: "Driver Car - License Plate", location_of_change: "Location of Change", location_of_create: "Location of Create", make_type: "Vehicle Brand Type", manpower: "Man Power", mobile_number: "Driver-Mobile Number", mobile_verification_code: "Mobile Verification Code", nationality: "Nationality", password: "Password", password_repeat: "Password-Repeat", payment_methods: "Select Payment Methods", powertrain: "Powertrain", social_ins_num: "Driver Social Insurance Number", state: "Province / Federal State", street_name: "Driver Address - Street Name ", street_number: "Street Number", submit_button: "Submit", take_a_picture: "Take A Picture", take_an_id: "Take An ID", time_of_change: "Time of Change", time_of_create: "Time of Create", upload_a_picture: "Upload A Picture", upload_an_id: "Upload An ID", upload_picture: "Upload Picture", username: "Username", vehicle_make: "Vehicle Make", vehicle_type: "Vehicle Type", verification: "Verification", zip: "ZIP" };
  public response: any;
  public tmp: any;
  public countryList: any;
  public mobileError: string;
  public message: string;
  public mobileOTP: string = "";

  public vehicleTypeList: any;
  public vehicleMakeList: any;
  public vehicleModelList: any;
  public vehicleModelListAll: any;

  public password_err: string = "";
  public password_err1: string = "";
  public business_connection_list:any = [];

  public mobile_verification_code: string = "";
  public fileToUpload: File = null;
  public general = { id: false, image: 'face-image.png', id_proof_image: 'identity-image.png', business_connection_type: '8', driver_number: '', first_name: '', last_name: '', username: '', id_card: '', password: '', password_repeat: '', country: 'CN China', state: '', city: '', zip: '', street_number: '', street_name: '', house: '', floor: '', further_information: '', email: '', dialing_code: '', mobile_number: '', driver_taxi_lic_no: '', driver_emp_no: '', social_ins_num: '', license_plate: '', vehicle_type: '1', vehicle_make: '1', make_type: '', powertrain: 'Combustion', driving_mode: 'Driver', email_verification_link: true, mobile_verification_code: true, is_mobile_verified: true, date_of_create: '', time_of_create: '', location_of_create: '', date_of_change: '', time_of_change: '', location_of_change: '', role: 'driver', driver_company: '', driver_company_busness_lic: '', driver_company_vat: '', payment_methods: false };
  public business_connection_type_list: any = [];
  public mcities: any = [];
  disabled = false;
  showFilter = false;
  limitSelection = false;
  selectedItems: any = [];
  dropDownSettings: any = {};

  //================================================================//

  public BaseUrl: string = '';
  public BASE_URL: string = '';

  //=============== ALERT INTITIALIZATION ===================================//
  public email_alert: string = '';
  public mobile_number_alert: string = '';
  public tmpCounter: number = 0;
  public zipErr:string = "";
  public first_nameErr:string = "";
  public last_nameErr:string = "";
  public license_plateErr:string = "";
  
  public dialing_codeErr:string = "";
  public imageErr:string = "";
  public id_proof_imageErr:string = "";
  public id_cardErr:string = "";
  public driver_emp_noErr:string = "";
  public stateErr:string= "";
  public cityErr:string="";
   





  constructor(private modalService: BsModalService,notifierService: NotifierService,public global: Globals, private http: HttpClient, private cookieService: CookieService, private router: Router) {

    this.getCountry();

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;

    this.notifier = notifierService;
  }
  error = new Subject<string>();

  ngOnInit() {
    console.log(this.cookieService.getAll());
    let conn = JSON.parse(this.cookieService.get('company_driver_connection'));
    this.business_connection_list = conn;
    console.log(this.business_connection_list);




    this.mcities = conn;

    console.log(this.mcities);
    this.selectedItems = [this.mcities[0]];
    //this.selectedItems = this.mcities[0];
    console.log("selectedItems");
    console.log(this.selectedItems);

    console.log(this.general);

    this.dropDownSettings = {
      singleSelection: false,
      id_field: 'id',
      textField: 'text',
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: this.showFilter
    };
    this.getCountry();
    this.getDriverRegPageData();
    console.log(this.cookieService.getAll());
    this.getVehicleType();
    this.getVehicleMake();
    this.getVehicleMakeModel();


  }


  getDriverRegPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "Licensed Company Employee Driver Registration" }
    )
      .subscribe(
        responseData => {
          //  console.log("Response for Driver");
          //console.log(this.global.country);
          this.tmp = responseData;
          var cookie = JSON.parse(this.cookieService.get('language_code'));
          this.global.country = cookie.language;
          console.log(this.global.country);
          if (this.global.country == 'en') {
            this.pageDriverRegData = this.tmp.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageDriverRegData = this.tmp.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageDriverRegData = this.tmp.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageDriverRegData = this.tmp.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageDriverRegData = this.tmp.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageDriverRegData = this.tmp.data.content_es;
          }
          // console.log(this.global.country);
          //          console.log(this.pageDriverRegData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }



  public ngAfterViewInit() {
    var promise = new Promise(
      (resolve, reject) => {
        // setTimeout(this.getBusinessConnection,2000);
        resolve();
      });
    // this.getBusinessConnection();
  }

  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    console.log(items);
  }

  getCountry() {
    this.http.get(this.global.APIURL + "api/general/languageList").subscribe(
      responseData => {
        this.global.setCountryList(responseData);
        this.countryList = responseData;
        this.countryList = this.countryList.data;
        //console.log(this.countryList);
      },
      error => {
        this.error.next(error.message);
      }
    );

  }

  getVehicleType() {

    // this.cookieValue = this.cookieService.get('Test');

    this.http.get(this.global.APIURL + "api/general/getVehicleType").subscribe(
      responseData => {
        let vehicletemp: any = responseData;
        vehicletemp = vehicletemp.data;
        this.vehicleTypeList = vehicletemp;
      },
      error => {
        this.error.next(error.message);
      }
    );

  }

  getVehicleMake() {
    this.http.get(this.global.APIURL + "api/general/getVehicleMake").subscribe(
      responseData => {
        let vehicletemp: any = responseData;
        vehicletemp = vehicletemp.data;
        this.vehicleMakeList = vehicletemp;
      },
      error => {
        this.error.next(error.message);
      }
    );

  }

  changeModel() {

    //console.log("HELO HUSBHUSBUSSHUSHUSHSUHSIUSH");
    this.vehicleModelList = this.vehicleModelListAll[this.general.vehicle_make];
    //console.log(this.vehicleModelList);
    this.general.make_type = this.vehicleModelList[0].id;

  }

  getVehicleMakeModel() {
    this.http.get(this.global.APIURL + "api/general/getVehiclemodelBrand").subscribe(
      responseData => {
        let vehicletemp: any = responseData;
        vehicletemp = vehicletemp.data2;
        this.vehicleModelListAll = vehicletemp;
        this.vehicleModelList = this.vehicleModelListAll[this.general.vehicle_make];
        console.log(this.vehicleModelList);
        this.general.make_type = this.vehicleModelList[0].id;
      },
      error => {
        this.error.next(error.message);
      }
    );

  }


  getBusinessConnection = function () {

    var formdata = { connection_for: 'driver' };
    this.http.post(this.global.APIURL + 'api/general/businessConnection', formdata, {
    }).
      subscribe(
        response => {
          var tmpResponse:any = response.data;
          this.business_connection_list = tmpResponse.data;
          console.log(tmpResponse);
          for (let i = 0; i < tmpResponse.length; i++) {
            this.business_connection_type_list.push(
              { id: tmpResponse[i].id, text: tmpResponse[i].business_connection_name }
            );
          }
          console.log(this.business_connection_type_list);

          return false;
        },
        error => {
          return false;
        });

  };



  handleFileInput(files: FileList, FileName: string) {
    //console.log(FileName);
    this.fileToUpload = files.item(0);
    const formData: FormData = new FormData();
    formData.append('file', this.fileToUpload, this.fileToUpload.name);
    formData.append('data', 'driver');
    this.http.post(
      this.global.APIURL + "api/drivers/auth/uploadImage",
      formData
    )
      .subscribe(
        responseData => {
          //console.log(responseData);    
          this.tmp = responseData;
          if (FileName == 'image') {
            this.general.image = this.tmp.file_name;
          }
          else if (FileName == 'id_proof_image') {
            this.general.id_proof_image = this.tmp.file_name;
          }
          //console.log(this.general); 
        },
        error => {
          //console.log(error.message)
          this.error.next(error.message);
        }
      );
  }
  verifyOTP() {
   
    this.mobileError = "";
    this.message = "";
    if(this.mobile_verification_code.length == 5 )
    {
       if (this.mobileOTP.trim() != this.mobile_verification_code.trim()) {
        this.mobileError = "Code does not matched";       
       
      }
      else
      {        
        this.message = "Mobile number verified successfully";
       
        this.modalRef.hide(); 
        this.onSubmit();
      }
    }
    
  }
  checkPasswords(pass: string, confirmPass: string) { // here we have the 'passwords' group
    return pass === confirmPass ? null : { notSame: true }
  }

  validationInputPwdText(value: string) {
    this.password_err = "";
    var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
  
    if (value.match(decimal)) {
      this.password_err = "";

    } else {
      this.general.password = "";
      this.password_err = "Passwords must contain at least 8 characters, including uppercase, lowercase letters , special characters and numbers.Password";
    }
  };

  confirmPass(value1: string, value2: string) {

    this.password_err1 = "";

    if (value1 == value2) {
      this.password_err1 = "";
      console.log(value1 + "," + value2);

    } else {
      console.log(value1 + "," + value2);
      this.password_err1 = "Passwords must be matched";
    }
  };




  validateCheck(checked: any) {
    console.log(event);
    if (!checked) {
      return false;
    }

    if (this.general.mobile_number == '') {
      this.general.mobile_number = '';
      alert("Please enter mobile Number");

      return false;
    }
    if (this.general.dialing_code == '') {
      this.general.dialing_code = '';
      alert("Please enter dialing code");

      return false;
    }


  }
  smsCodeEntry() {
    //console.log(this.tmpCounter++);
    console.log(this.mobile_verification_code);
  }



  formValidateCheck()
  {  
    this.first_nameErr = "";
    this.license_plateErr="";
    this.last_nameErr = "";
    this.email_alert = "";
    this.mobile_number_alert = "";
    this.dialing_codeErr = "";
    this.imageErr = "";
    this.id_proof_imageErr = "";
    this.id_cardErr = "";
    this.driver_emp_noErr ="";
    this.stateErr ="";
    this.cityErr ="";
    this.password_err1 = "";
    this.password_err = "";
    
    let result :boolean=true;

    if(this.general.password.trim()=='')
    {
      this.password_err = "Please enter password";
      result =  false;
    }
    if(this.general.password_repeat=='')
    {
      this.password_err1 = "Please enter password repeat";
      result =  false;
    }
    if(this.general.state=='')
    {
      this.stateErr = "Please enter Province / Federal State";
      result =  false;
    }
    if(this.general.city=='')
    {
      this.cityErr = "Please enter City / Municipality";
      result =  false;
    }

    if(this.general.first_name=='')
    {
      this.first_nameErr = "Please enter first name";
      result =  false;
    }
    if(this.general.last_name=='')
    {
      this.last_nameErr = "Please enter last name";
      result =  false;
    }
    if(this.general.id_card=='')
    {
      this.id_cardErr = "Please enter ID card number";
      result =  false;
    }
    if(this.general.driver_emp_no=='')
    {
      this.driver_emp_noErr = "Please enter driver_emp_no";
      result =  false;
    }
    if(this.general.license_plate=='')
    {
      this.license_plateErr = "Please enter license  no.";
      result =  false;
    }
//license_plateErr

    if(this.general.email=='')
    {
      this.email_alert = "Please enter valid email ID";
      result =  false;
    }
    if(this.general.mobile_number=='')
    {
      this.mobile_number_alert = "Please enter mobile number";
      result =  false;
    }
    if(this.general.dialing_code=='')
    {
      this.dialing_codeErr = "Please enter dialing code";
      result =  false;
    }
    if(this.general.zip=='')
    {
      this.zipErr = "Please enter Zip/Postal code";
      result =  false;
    }
    if( this.general.image== "face-image.png")
    {
      this.imageErr = "Please upload picture";
      result =  false;
    }
    if( this.general.id_proof_image== "identity-image.png")
    {
      this.id_proof_imageErr = "Please upload ID proof";
      result =  false;
    }
    return result;
  
  }
  






  onSubmit() {

    if (  this.mobile_verification_code.trim() == "") {
      this.modalRef = this.modalService.show(this.mobileVerification,{backdrop:'static', keyboard:false});
  
    }
    else{
      //this.modalRef.hide();
    }
    this.mobileError = "";
    if (!this.formValidateCheck()) {
     return false;
    }
    else if (this.general.mobile_verification_code == true && this.general.mobile_number != "" && this.mobileOTP == "") {
      this.http.post(
        this.global.APIURL + "api/general/sendSms",
        { dialing_code: this.general.dialing_code, mobile_number: this.general.mobile_number }
      )
        .subscribe(
          responseData => {
            var res: any;
            res = responseData;
            var data = JSON.parse((res.data));

            console.log(data);
            if (data.errors) {
              this.mobileError = data.errors[0].description;
            }
            else if (data.body) {
              this.mobileOTP = data.body;
              
              this.message = "Verified successfully";

            }
          },
          error => {
            console.log(error.message)
            this.error.next(error.message);
          }
        );
    }
    else if (this.general.mobile_verification_code == true && this.mobileOTP == this.mobile_verification_code) {
      
      this.http.post(
        this.global.APIURL + "api/drivers/auth/signup",
        this.general
      )
        .subscribe(
          responseData => {
            var res: any;
            res = responseData;
            if (res.message) {
              this.notifier.notify("success", res.message);
              //alert(res.message);
              setTimeout(
                ()=>{
                  this.router.navigate(['/login']).then(() => {
                    //window.location.reload();
                   });
                }, 5000
              );
            }
          },
          error => {
            console.log(error.message)
            this.error.next(error.message);
          }
        );
    }
  }




  search = function (idx: any, value: any) {

    //console.log(idx+","+value); return false;
    var ins = idx;
    this.email_alert = '';
    this.mobile_number_alert = '';
    var formdata: any = {};
    if (idx == "email") {
      if (value == '') {
        this.email_alert = 'Please enter  email address';
        return false;
      }
      if (!this.ValidateEmail(value)) {
        this.email_alert = 'Please enter  a valid email address';
        this.general.email = '';
        return false;
      }
      formdata = { email: value, user_type: "driver" };
    }
    else if (idx == "mobile_number") {
      if (value == '') {
        this.mobile_number_alert = 'Please enter valid Mobile number';
        return false;
      }
      formdata = { mobile_number: value, user_type: "driver" };
    }
    var api_method = 'search';
    this.http.post(this.BASE_URL + 'api/general/' + api_method, formdata, {
    }).
      subscribe(
        response => {

          if (idx == "email") {
            this.email_alert = 'Email already exists';
            this.general.email = '';
          }
          else if (idx == "mobile_number") {
            this.mobile_number_alert = 'Mobile number already exists';
            this.general.mobile_number = '';
          }
          this.mobile_number_alert
          return false;

        },
        error => {
          return false;
        });

  }

  ValidateEmail(inputEmailTxt: any) {
    console.log(inputEmailTxt);
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (inputEmailTxt.match(mailformat)) {

      return true;
    }
    else {
      //alert("You have entered an invalid email address!");

      return false;
    }
  }




  isNumberKey(idx: any, val: any) {
    console.log(val);
    var regex = /^[0-9]*(?:\.\d{1,2})?$/;    // allow only numbers [0-9] 
    if (!regex.test(val)) {

      if (idx == 'zip') {
        this.general.zip = '';
      }
      else if (idx = 'mobile_number') {
        this.general.mobile_number = '';
      }

    }
  }


  //========= web cam codes================//

  openCam(imageType: string) {
    if (imageType == 'profile_picture') {
      this.showWebcamProfileImage = true;
      this.showWebcamIdImage = false;
    }
    else {
      this.showWebcamProfileImage = false;
      this.showWebcamIdImage = true;
    }
  }
  saveTofile(snapshotData: any, uploadfr: any) {
    console.log(snapshotData);
    var formdata = { data: snapshotData, user_type: 'driver' };
    console.log(formdata);
    this.http.post(this.BASE_URL + 'api/general/base64Tojpeg', formdata, {
    }).
      subscribe(
        response => {
          let tmpResponse: any = response;
          console.log(tmpResponse.data);
          if (uploadfr == "image") {
            this.general.image = tmpResponse.data;
            this.showWebcamProfileImage = false;
          }
          else {
            this.general.id_proof_image = tmpResponse.data;
            this.showWebcamIdImage = false;
          }
          return false;

        },
        error => {
          console.log(error);
          return false;
        });
  }


public triggerSnapshot(): void {
  this.trigger.next();
}


public handleInitError(error: WebcamInitError): void {
  this.errors.push(error);
}

public showNextWebcam(directionOrDeviceId: boolean|string): void {
  // true => move forward through devices
  // false => move backwards through devices
  // string => move to device with given deviceId
  this.nextWebcam.next(directionOrDeviceId);
}

public handleImage(webcamImage: WebcamImage): void {
  console.info('received webcam image', webcamImage);
  this.webcamImage = webcamImage;
  if(this.showWebcamProfileImage)
  {
    this.saveTofile (this.webcamImage.imageAsDataUrl,'image');
    //triggerObservable
  }
  else
  {
    this.saveTofile (this.webcamImage.imageAsDataUrl,'id');
  }
}

public cameraWasSwitched(deviceId: string): void {
  console.log('active device: ' + deviceId);
  this.deviceId = deviceId;
}

public get triggerObservable(): Observable<void> {
  return this.trigger.asObservable();
}

public get nextWebcamObservable(): Observable<boolean|string> {
  return this.nextWebcam.asObservable();
}




}
