import { Component, OnInit, Directive, Input, ViewChild, ElementRef, TemplateRef, ContentChild } from '@angular/core';
import { BehaviorSubject, Observable, interval } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { FormsModule } from '@angular/forms';
import { Subject, throwError, timer } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

declare var $: any;
@Component({
  selector: 'app-add-vehicle',
  templateUrl: './add-vehicle.component.html',
  styleUrls: ['./add-vehicle.component.css']
})
export class AddVehicleComponent implements OnInit {

  modalRef: BsModalRef;


  @ViewChild('messageModal', { static: true }) messageModal: ElementRef;
  @ViewChild('modalVehicle',{static:true}) modalVehicle:ElementRef;
  public config: any;
  error = new Subject<string>();
  public BASE_URL: string;
  public TOKEN: any
  public pageData = { vehicle_management: 'Vehicle Management ', list_of_vehicle: ' List of vehicles', add_vehicle_btn: 'Add vehicle', start_date: 'Start Date', end_date: 'End Date', submit: 'Go', sno: 'Sr.', vehicle_name: 'Vehicle Name', make: 'Vehicle Brand', brand_type: 'Vehicle Brand Type', lic_plate: 'License Plate', powertrain: 'Powertrain', action: 'Action', vehicle_detail: 'Vehicle Detail', assigned_driver: 'Assigned Driver', driver_name: "Driver's Name", picture: 'Picture' };
  public base_url: string;
  public BaseUrl: string;
  public headers: any;
  public user_type:string = "driver";

  public general_vehicle = { id: '', powertrain: 'Combustion', vehicle_doc: 'doc.jpg', image: 'err.jpg', vehicle_type_id: '1', vehicle_make_id: '1', make_type_id: '137', license_plate_no: '', driving_mode: 'Driver' };
  public vehicle: any = {};
  public content_vehicle: any = {};
  public subscribed: boolean = true;
  public subscriptionMessage: string = "";
  public general: any = {};
  public vehicleTypeList: any;
  public vehicleMakeList: any;
  public make_typeList: any;
  public msg: string = "";
  public driverVehicleList: any = [];
  public driverVehicleLists: any = [];
  public fileToUpload: File = null;
  public errlicense_plate_no: string = "";

  constructor(public global: Globals, private modalService: BsModalService, private http: HttpClient, private cookieService: CookieService, private router: Router) {
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;
    
    

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });

    this.base_url = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
  }


  ngOnInit() {
    this.getPageData();
    this.getPageDataAddVehicle();



    this.getprofile();
    this.getSubscriptionInfo();
    this.getVehicleManagementInfo();

    this.getVehicleType();
    this.getVehicleMake();
    this.getVehiclemodelBrand(this.general.vehicle_make);
  }
  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "company-vehicle-management" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));

          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }

          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }



  uploadVehicleImageDoc(files: FileList,FileName:string) {
    //console.log(FileName);
    this.fileToUpload = files.item(0);
    const formData: FormData = new FormData();
    formData.append('file', this.fileToUpload, this.fileToUpload.name);
    formData.append('data', 'vehicle');
    this.http.post(
      this.global.APIURL+"api/users/auth/uploadImage",
      formData
    )
    .subscribe(
      responseData => {
        //console.log(responseData);    
        let tmp:any = responseData;
        if(FileName == 'image')
        {
          this.general_vehicle.image = tmp.file_name;
        }
        else if(FileName == 'doc'){
          this.general_vehicle.vehicle_doc = tmp.file_name;
        }
        //console.log(this.general); 
      },
      error => {
        //console.log(error.message)
        this.error.next(error.message);
      }
    );
  }


  getSubscriptionInfo() {
    console.log("getSubscriptionInfo info");
    var api_method = "subscriptionInfo";
    this.http.get(this.BASE_URL + 'api/companies/account/' + api_method,
      {
        headers: this.headers
      }).subscribe(
        response => {
          console.log('getSubscriptionInfo');
          let tmpResponse: any = response;
          if (tmpResponse.success == "true") {
            this.subscribed = true;
            this.subscriptionMessage = tmpResponse.message;
           // $("#TailSubscription").modal("hide");
          }
          else {
            this.subscribed = false;
            this.subscriptionMessage = tmpResponse.message;
          }
          console.log(this.subscribed);

          return false;
        }
        , error => {
          return false;
        });
  };
  viewCompanyVehicle(ob: any) {

    this.vehicle = ob;
    this.modalRef = this.modalService.show(this.modalVehicle);
    
  };

  getPageDataAddVehicle() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "add-vehicle" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));

          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.content_vehicle = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.content_vehicle = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.content_vehicle = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.content_vehicle = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.content_vehicle = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.content_vehicle = this.config.data.content_es;
          }
          console.log(this.content_vehicle);
          //  this.global.setPageData(this.content_vehicle);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getprofile() {
    console.log(JSON.parse(localStorage.getItem('user')));
    this.user_type = JSON.parse(localStorage.getItem('user')).user_info;
    console.log(this.user_type);
    this.http.get(this.BASE_URL + 'api/'+this.user_type+'/profile',
      { headers: this.headers }
    ).subscribe(response => {
      let tmpResponse: any = response;
      this.general = tmpResponse.data;
      return false;
    }, error => {
      return false;
    });
  };


  getVehicleType() {
    var formdata = { status: 1 };
    var api_method = 'getVehicleType';

    this.http.post(this.BASE_URL + 'api/general/' + api_method, formdata, {
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.vehicleTypeList = tmpResponse.data;
      return false;

    }, error => {
      return false;
    });
  };

  getVehicleMake() {
    var formdata = { status: 1 };
    var api_method = 'getVehicleMake';

    this.http.post(this.BASE_URL + 'api/general/' + api_method, formdata, {
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.vehicleMakeList = tmpResponse.data;
      return false;

    }, error => {
      return false;
    });
  };

  getVehiclemodelBrand(val: string) {
    var formdata = { make_id: val };
    this.http.post(this.BASE_URL + 'api/general/getVehiclemodelBrand', formdata, {
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.make_typeList = tmpResponse.data;
      this.general_vehicle.make_type_id = tmpResponse.selected_id;

      ////this.vehicleMakeBrandList = tmpResponse.data;
      return false;

    }, error => {
      this.make_typeList = false;
      this.general.make_type = false;
      return false;
    });
  };




  getVehicleManagementInfo() {

    this.driverVehicleList = [];

    this.http.get(this.BASE_URL + 'api/drivers/vehicle/getVehicleDetails',
      {
        headers: this.headers
      }).subscribe(response => {
        let tmpResponse: any = response;
        console.log(tmpResponse.data);
        this.driverVehicleLists = [];
        this.driverVehicleLists = tmpResponse.data;

        return false;


      }, error => {
        return false;
      });


  };

  validation() {
    if (this.general_vehicle.license_plate_no == '') {
      this.errlicense_plate_no = 'Please Enter License Plate number';
      return false;
    }
    return true;

  };
  add_vehicle() {
    this.errlicense_plate_no = "";
    if (!this.validation()) {
      this.errlicense_plate_no = "Please enter license plate number";
      return false;
    }
    //console.log(TOKEN);
    if (confirm("Are you sure, you want to Add")) {
      let api_user:string = "drivers";
      let routerUrl:string = "vehicle"
      if(this.user_type == "company")
      {
        api_user = "companies";
        routerUrl = "company-vehicle-management";
      }
      console.log("hello ");

      this.http.post(this.BASE_URL + 'api/'+api_user+'/vehicle/addVehicle', this.general_vehicle, {
        headers: this.headers
      }).subscribe(response => {
        let tmpResponse: any = response;
        this.msg = tmpResponse.message;
        this.modalRef = this.modalService.show(this.messageModal);
        setTimeout(() => {
          this.modalRef.hide();
        }, 2000);
        this.router.navigate([routerUrl]);

      }, error => {
        this.errlicense_plate_no = error.error.error;
        return false;
      });
    }
  };


}
