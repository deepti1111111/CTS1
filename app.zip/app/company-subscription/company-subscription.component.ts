import { Component,ElementRef,ViewChild, OnInit, Directive, Input } from '@angular/core';
import { Globals } from '../global';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject, throwError } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-company-subscription',
  templateUrl: './company-subscription.component.html',
  styleUrls: ['./company-subscription.component.css']
})
export class CompanySubscriptionComponent implements OnInit {
  modalRef: BsModalRef;

  @ViewChild('messageModal', { static: true }) messageModal: ElementRef;
  public subscriptionMessage: string = "";
  public pageData = {own_driver:'',car:'', analytics: '', payment: '', visibility: '', visibility_me: '', competitor: '', customer_show_density: '', driver_business_probability: '', ride: '', tax_invoice: '', msg: '', standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: '/p.m.', rate_year: '/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  
  public TOKEN: string = "";
  error = new Subject<string>();
  public config: any;
  public BaseUrl: string;
  public subscribed: boolean = false;
  public headers: any = {};
  public is_edit: boolean = false;
  public BASE_URL: string = '';
  public companyDriverList: any = [];
  public driverVehicleList: any = [];
  public companyDriverLists: any = [];
  public company_driver_count: number = 0;

  public msg: string = "";
  public paymentMethodDetails: any;
  public paymentMethods: any;

  public driverVehicleLists: any = [];
  public isadhoc: boolean = true;
  public country: string;

  public standard_monthly: any;
  public standard_yearly: any;

  public exclusive_monthly: any;
  public exclusive_yearly: any;

  public premium_monthly: any;
  public premium_yearly: any;
  public subscription_info:any;
  public standard: any = { 
  driver_business_probability: "",
  tax_invoice: "",
  visibility: "",
  metropay_ride: "",
  standard: "Standard",
  exclusive: "Exclusive",
  premium: "Premium",
  free: "Free",
  rate_month: "USD/p.m.",
  rate_year: "USD/p.a.",
  autonom: "Autonom",
  eco: "ECO",
  taxi: "TAXI",
  chauffer: "CHAUFFER",
  rental_car: "RENTAL CAR",
  self_employed: "SELF EMPLOYED",
  visibility_me:'visibility_me',
  transport: "TRANSPORT",competitor: '', customer_show_density: '',
    };


  public exclusive: any = {visibility_me:'', competitor: '', customer_show_density: '', driver_business_probability: '', tax_invoice: '', visibility: '', metropay_ride: '', standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public premium: any = { competitor: '', customer_show_density: '', driver_business_probability: '', tax_invoice: '', visibility: '', metropay_ride: '', standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
 
  public standard_range:string = "range500";
  public exclusive_range:string = "range500";
  public premium_range:string = "range500";



  constructor(public global: Globals, private http: HttpClient, private cookieService: CookieService,private modalService: BsModalService,
    private router: Router
  ) {
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });

  }


  ngOnInit() {

    this.getPageData();
    this.getSubscriptionCharge();
    this.getDriverManagementInfo();
    this.getVehicleManagementInfo();
    
  }


  getVehicleManagementInfo() {
    this.driverVehicleList = [];
    this.http.get(this.BASE_URL + 'api/companies/vehicle/getVehicleDetails', {
      headers: this.headers
    }).subscribe(response => {
      let tmpResponse: any = response;
      this.driverVehicleLists = tmpResponse.data;

      return false;


    }, error => {

      return false;

    });





  };

  getDriverManagementInfo() {

    this.http.get(this.BASE_URL + 'api/companies/service/getDriverDetails', {
      headers: this.headers

    }).subscribe(response => {
      let tmpResponse: any = response;
      this.companyDriverList = tmpResponse.data;
      this.companyDriverLists = tmpResponse.data_list;
      this.company_driver_count = this.companyDriverList.length;
    }, error => {

      return false;

    });
  };

  ngAfterViewInit() {
    this.getSubscriptionInfo();
  }

  getSubscriptionInfo() {

    var api_method = "subscriptionInfo";
    this.http.get(this.BASE_URL + 'api/companies/account/' + api_method, {
      headers: this.headers
    })
      .subscribe(
        response => {
          let tmpResponse: any = response;
          this.subscription_info = tmpResponse.data;
          this.isadhoc = false;//response.adhoc;
          if (tmpResponse.success == "true") {
            this.subscribed = true;
            this.subscriptionMessage = tmpResponse.message;
          }
          else {
            this.subscribed = false;
            this.subscriptionMessage = tmpResponse.message;
          }


          return false;
        },
        error => {
          return false;
        });
  };

  getSubscriptionCharge() {
    var formdata = { user_type: 'Company' };
    this.http.post(this.BASE_URL + 'api/subscription/subscriptionData', formdata, {
      headers: this.headers
    }).
      subscribe(
        response => {
          let tmpResponse :any = response;
          var subscribe_list = tmpResponse.data;
          if (subscribe_list) {
            for (var i = 0; i < subscribe_list.length; i++) {

              if (subscribe_list[i].subscription_term == "Standard") {
                this.standard_monthly = JSON.parse(subscribe_list[i].monthly_pay);

                this.standard_yearly = JSON.parse(subscribe_list[i].yearly_pay);
                this.standard = subscribe_list[i];
              }
              if (subscribe_list[i].subscription_term == "Exclusive") {
                this.exclusive_monthly = JSON.parse(subscribe_list[i].monthly_pay);
                this.exclusive_yearly = JSON.parse(subscribe_list[i].yearly_pay);
                this.exclusive = subscribe_list[i];

              }
              if (subscribe_list[i].subscription_term == "premium") {
                this.premium_monthly = JSON.parse(subscribe_list[i].monthly_pay);
                this.premium_yearly = JSON.parse(subscribe_list[i].yearly_pay);
                this.premium = subscribe_list[i];
                this.premium = subscribe_list[i];
              }
            }
          }

          return false;
        }
        , error => {
          return false;
        });
  };


  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "user-subscription" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;

          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
          
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }

          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }




  getPaymentMethods() {
    this.http.get(this.BASE_URL + 'api/general/getPaymentMethods', {
      headers: this.headers
    }).
      subscribe(
        response => {
          let tmpResponse: any = response;
          this.msg = tmpResponse.message;
          this.paymentMethodDetails = tmpResponse.data1;
          this.paymentMethods = tmpResponse.data;

        },
        error => {
          return false;
        });
  };

  setPaymentInfo(term_yearly: string, subscription_type: string, currency: string, term: string, isOne: string, car_range:string) {
    let formdata: any = {
      term_yearly: term_yearly,
      subscription_type: subscription_type,
      subscription_term: term,
      total_fee: term_yearly,
      Subject: 'monthly subsciption for usrss',
      user_type: 'driver',
      currency: currency,
      term: isOne,
      car_range:car_range
    }

    this.router.navigate(['payment-page', JSON.stringify(formdata)]);
  }

  getRatebyRange (val:any, lowerbound:any, upperbound:any)
    {

        this.msg = '';
        if (upperbound <= this.driverVehicleLists.length)
        {

            this.msg = 'You have selected wrong subscription plan as you have more cars';
            this.standard_range = "range500";
            this.exclusive_range = "range500";
            this.modalRef = this.modalService.show(this.messageModal);
           // $("#message_modal").modal("show");
            setTimeout(()=> {
              this.modalRef.hide();
              this.standard_range = "range500";
             //   $("#message_modal").modal("hide");
            }, 3000);

        }

    };



}
