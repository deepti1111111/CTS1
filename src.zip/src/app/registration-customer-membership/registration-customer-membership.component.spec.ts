import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationCustomerMembershipComponent } from './registration-customer-membership.component';

describe('RegistrationCustomerMembershipComponent', () => {
  let component: RegistrationCustomerMembershipComponent;
  let fixture: ComponentFixture<RegistrationCustomerMembershipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationCustomerMembershipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationCustomerMembershipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
