import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';

import { CookieService } from 'ngx-cookie-service';



@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  public pageData ={delete:'', business_connection:'',    first_name:'',    last_name:'',    nationality:'',    street_number:'',    street_name:'',    floor:'',    house:'',    further_information:'',    customer_number:'',    id_card:'',    country:'',    state:'',    zip:'',   mobile_number:'',   payment_methods:'',   dialing_code:'',   city:''};
  public TOKEN :string = "";
  error = new Subject<string>();
  public response :any;
  public config:any;
  public BaseUrl :string;
  public general:any = {
    payment_methods:''
  };
  public headers:any = {};
  public is_edit : boolean = false
  public BASE_URL :string='';
  public paymentMethodDetails :any ;
  public paymentMethods :any ;

  constructor(public global: Globals,private http: HttpClient,private router: Router,private cookieService: CookieService,) {
    this.TOKEN =JSON.parse(localStorage.getItem('user')).token;
    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({      "token":this.TOKEN,      "Content-Type":"application/json"    });
    this.getPaymentMethods();    
   }

  
  ngOnInit() {   
    this.getPageData();
      }


  getPageData() {
    
    this.http.post(
      this.global.APIURL+'api/general/getPageScreen',
      {id:false,screen:"Customer Registration"}
    )
    .subscribe(
      responseData => {
        this.config = responseData;
        
        var LOCALSTORAGE  = JSON.parse(localStorage.getItem('user'));
      let countryTmp = JSON.parse(this.cookieService.get("language_code"));
      let vv = JSON.parse(this.cookieService.get('language_code'));
      this.global.country = countryTmp.language;
        if(this.global.country == 'en')
        {
          this.pageData = this.config.data.content_en;
        }
        else if(this.global.country == 'cn')
        {
          this.pageData = this.config.data.content_cn;
        }
        else if(this.global.country == 'de')
        {
          this.pageData = this.config.data.content_de;
        }
        else if(this.global.country == 'fr')
        {
          this.pageData = this.config.data.content_fr;
        }
        else if(this.global.country == 'hi')
        {
          this.pageData = this.config.data.content_hi;
        }
        else if(this.global.country == 'es')
        {
          this.pageData = this.config.data.content_es;
        }
        console.log(this.pageData);
        this.global.setPageData(this.pageData);
      },
      error => {
        this.error.next(error.message);
      }
    );
  }

  getUserData() {

    
    this.http.get(
      this.global.APIURL+'api/user/profile',{
        headers:  this.headers
      })
    .subscribe(
      responseData => {
     
        var userdata : any= responseData; 
        this.general = userdata.data;
        var tempPaymentMethods:any =[];
        for(let i = 0 ; i<this.general.payment_methods.length; i++)        
        {
          let pay = this.general.payment_methods[i];
          tempPaymentMethods.push(this.paymentMethodDetails[pay].payment_method_name);
        }
        this.general.payment_methodss = tempPaymentMethods;
     
      },
      error => {
        this.error.next(error.message);
       
        if(error.error.error.trim() =="Token Expired")
        {
          this.router.navigate(['logout']);
        }
      }
    );
  }

  setprofile = function ()
  {
      let TOKEN = this.TOKEN;

      if (!TOKEN)
      {
          return false;
      }
      if (!this.formValidated())
      {
          return false;
      }

      this.http.post(this.BASE_URL + 'api/driver/profile', this.general, {headers: this.headers
      })
      .subscribe(
        response => {
            
          this.getUserData();
          return false;
      }, 
      error =>{
        this.error.next(error.message);
          return false;
      });
  };


  toggleFunction = function ()
    {
        if (this.is_edit)
        {
            this.is_edit = false;
        }
        else
        {
            this.is_edit = true;
        }
    };


    getPaymentMethods = function ()
    {
        this.http.get(this.BASE_URL + 'api/general/getPaymentMethods', {headers: this.headers
        }).
        subscribe(
          response=> {
       

            this.msg = response.data.message;
            this.paymentMethodDetails = response.data1;
            this.paymentMethods = response.data;
        
            this.getUserData();
        },
        error=>{
            return false;
        });
    };


    delete (user_type:any)
    {
        var confirmers = confirm("Are you sure, you want to delete it?");
              
        if (confirmers)
        {
               console.log(user_type);
            var formdata = {
                user_type: user_type,
                user_detail: localStorage.getItem('user_id')
            };
            this.http.post(this.BASE_URL + 'api/user/deactivateuser', formdata, 
            {headers:this.headers
            }).
            subscribe(
              response=> {
                // $scope.getprofile();
               // console.log(response.data);
             
              //  localStorage.removeItem('user_id');
              //  console.log(localStorage.getItem('user_id'));
               this.router.navigate(['logout']);
  
                return false;
  
            },
            error=> {
                //  console.log(response);
                // $scope.errMessage = response.data.message;
                return false;
            });
        }
        else
        {
  
        }
  
        return false;
  
  
    };
  
  





}
