import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyDriverManagementComponent } from './company-driver-management.component';

describe('CompanyDriverManagementComponent', () => {
  let component: CompanyDriverManagementComponent;
  let fixture: ComponentFixture<CompanyDriverManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanyDriverManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyDriverManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
