import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationSelfemployeedriverComponent } from './registration-selfemployeedriver.component';

describe('RegistrationSelfemployeedriverComponent', () => {
  let component: RegistrationSelfemployeedriverComponent;
  let fixture: ComponentFixture<RegistrationSelfemployeedriverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationSelfemployeedriverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationSelfemployeedriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
