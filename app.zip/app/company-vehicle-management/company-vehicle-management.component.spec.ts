import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyVehicleManagementComponent } from './company-vehicle-management.component';

describe('CompanyVehicleManagementComponent', () => {
  let component: CompanyVehicleManagementComponent;
  let fixture: ComponentFixture<CompanyVehicleManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanyVehicleManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyVehicleManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
