import { Component, OnInit, Directive, Input, ViewChild, ElementRef, TemplateRef, ContentChild } from '@angular/core';
import { BehaviorSubject, Observable, interval } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { FormsModule } from '@angular/forms';
import { Subject, throwError, timer } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

import { take } from 'rxjs/operators';
declare var H: any;

declare var $: any;
@Component({
  selector: 'app-driver',
  templateUrl: './driver.component.html',
  styleUrls: ['./driver.component.css']
})
export class DriverComponent implements OnInit {
  modalRef: BsModalRef;
  private platform: any;

  public config: any;
  error = new Subject<string>();
  public BASE_URL: string;
  public pageDataSubscription: any = { standard: 'Standard', exclusive: 'Exclusive', premium: 'Premium', free: 'Free', rate_month: 'USD/p.m.', rate_year: 'USD/p.a.', autonom: 'Autonom', eco: 'ECO', taxi: 'TAXI', chauffer: 'CHAUFFER', rental_car: 'RENTAL CAR', self_employed: 'SELF EMPLOYED', transport: 'TRANSPORT' };
  public TOKEN: any
  public pageData = { 'confirm_payment': '', 'confirm_payment_message': '', 'reject_ride': 'reject_ride', 'confirm_ride': 'confirm_ride', 'end_ride_popup_message': 'end_ride_popup_message', 'request_popup_header': 'request_popup_header', 'ride_popup_header': 'ride_popup_header', 'cancel_ride_msg': 'cancel_ride_msg', 'okay': 'Okay', 'total_distance': 'total_distance', 'end_ride': 'end_ride', 'start_ride': 'end_ride', 'total_revenue': 'total_revenue', 'total_booking': '', 'pick_up_from': 'Pick Up From', 'start_ride_popup_message': 'start_ride_popup_message', 'destination': 'Destination', 'provided_service': 'Provided Service', 'all_btn': 'All', 'service': 'Service', 'taxi_platform': 'Taxi Platform', 'tip': 'TIP (in total currency equal on top the transport fare)' };
  public pageDataRevenue: any = { week: 'Weekly Total', month: 'Monthly Total', year: 'Yearly Total', revenues: 'Revenues' };
  public pageDataBooking = { 'booking_datetime': '', customer_name: 'customer_name', pickup_location: 'pickup_location', drop_location: 'drop_location', start_date: 'Start Date', end_date: 'End Date', payment_mode: 'payment_mode', select_all: 'Select All', sno: 'Sr. No', pick_up: 'Pickup Location', drop: 'Drop Location', date: 'Date', fare: 'Fare', driver_name: 'Driver Name', car_no: 'Car Number', action: 'Action', ride_detial: 'Ride Detail', drivername: "Driver's Name", customername: "Customer's Name", pickup: 'Pick-up Location', vehicletype: 'Vehicle Type', series: 'Series', tip: 'Offered Tip', datetime: 'Booking Date & Time', feedback: 'Feedbacks', rating: 'Rating' };

  public base_url: string;
  public BaseUrl: string;
  public headers: any;
  public driverList: any;
  public countrydata: any = { label: '' };
  public geolocation: any;
  public valid: any;
  public addressListObjects: any;
  public distance_unit = 'km';
  public startLocationListHide: boolean = false;
  public endLocationListHide: boolean = false;

  public distance: string = '';
  public revenue: string = '';
  public booking: string = '';
  public booking_id: string;
  public msg: string = '';
  public start: boolean = true;
  public end: boolean = false;
  public cancelled: boolean = false;
  public startRideFlag: boolean = false;
  public routeInfo: string = '';
  public bookedRideStatus: number = -1;
  public chatSessionId:string = "";
  public message:string = "";
  public cash: boolean = true;
  public chatText:string="";
  public ChatId:string="";
  public value:string="";
  public request_info: any = {}
  public request_status: boolean = false;
  public driverMsg:string = "";
  public customerMsg:string = "";
  @ViewChild("map", { static: true }) public mapElement: ElementRef;
  @ViewChild('templateRideConfirmReject', { static: true }) templateRideConfirmReject: ElementRef;
  @ViewChild('templateRideStartEnd', { static: true }) templateRideStartEnd: ElementRef;
  @ViewChild('templateConfirmPAyment', { static: true }) templateConfirmPAyment: ElementRef;

  private map: any;
  public general_location: any = {
    start_location: '',
    start_latlng: { 'lat': 23.33, 'lng': 72.44 },
    end_location: '',
    end_latlng: { 'lat': 23.33, 'lng': 72.44 }
  };


  public ui: any;
  public pixelRatio: any;
  public defaultLayers: any;
  closeResult: string;

  constructor(public global: Globals, private modalService: BsModalService, private http: HttpClient, private cookieService: CookieService, private router: Router) {
    this.platform = new H.service.Platform({
      "app_id": this.global.HAppId,
      "app_code": this.global.HAppCode,
      useHTTPS: true
    })
    this.TOKEN = JSON.parse(localStorage.getItem('user')).token;

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      "token": this.TOKEN,
      "Content-Type": "application/json"
    });

    this.base_url = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;

  }

  ngOnInit() {
    this.getPageData();
    this.getPageDataRevenue();
    this.getBookingPageData();
    this.getPageDataSubscription();
    this.getIntervalFunction();
    this.getPosition().then(pos => {

      this.general_location.start_latlng.lat = pos.coords.latitude;
      this.general_location.start_latlng.lng = pos.coords.longitude;

      this.getDriverOnLocation(pos.coords.latitude, pos.coords.longitude);
      this.home_page_ride();

      this.getAddressFromCoordinates(this.general_location.start_latlng.lat, this.general_location.start_latlng.lng, 'start');

    });
    this.getCurrentOngoingRide();

  }
  confirmOrCancelRide(booking_id: string, status: string, request_info: any) {
    this.booking_id = booking_id;
    this.http.post(this.BASE_URL + 'api/drivers/booking/confirmCancelRide',
      { booking_id: booking_id, booking_status: status }, {
      headers: this.headers
    }).subscribe(
      response => {
        let tmpResponse: any = response;
        this.msg = tmpResponse.message;
        if (status == '4') {
          this.start = true;
          this.end = false;
          this.cancelled = false;
          this.modalRef.hide();
          this.modalRef = this.modalService.show(this.templateRideStartEnd);
        }
        if (status == '0') {
          this.end = false;
          this.start = false;
          this.cancelled = true;
          this.modalRef.hide();
          if (!this.modalRef) {
           
            this.modalRef = this.modalService.show(this.templateRideStartEnd);
          }


        }


      }, error => {
        return false;
      });
  };
  resetriderequest() {

    this.http.post(this.BASE_URL + 'api/drivers/booking/rideCancelSeen', { booking_id: this.booking_id }, {
      headers: this.headers
    }).subscribe(
      response => {
        console.log(response);

        setTimeout(() => {


          this.modalRef.hide();
        }, 2000);
        window.location.reload();

      },
      error => {
        console.log(error);
        console.log(error.error.error);
        if ( error.error.error.message == "Token Expired") {
          this.router.navigate(['logout']);
          // this.logout();
        }
        return false;

      });




  };

  startRide(booking_id: string) {
    var today = new Date();
    var datetime = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate() + " " + today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var formdata = {
      booking_id: booking_id,
      booking_status: 1,
      ride_start: datetime,
      edit_date: datetime
    };

    this.http.post(this.BASE_URL + 'api/drivers/booking/rideStartEnd', formdata, {
      headers: this.headers
    }).subscribe(
      response => {

        console.log(response);
        let tmpResponse: any = response;
        this.routeInfo = "";
        this.end = true;
        this.start = false;
        this.startRideFlag = true;
        this.msg = tmpResponse.message;
        var request_info = tmpResponse.request_info;
        // this.drawRouteHereMap(request_info.latitude, request_info.longitude, request_info.end_latitude, request_info.end_longitude, this.distance_unit);
        /// document.getElementById('loader').className = 'hide';

      }, error => {
        return false;
      });



  };
  endRide(booking_id, request_info) {
    this.modalRef.hide();
    console.log(request_info);
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var datetime = date + ' ' + time;
    var formdata = {
      booking_id: booking_id,
      booking_status: 2,
    };
    this.http.post(this.BASE_URL + 'api/drivers/booking/rideStartEnd', formdata, {
      headers: this.headers
    }).
      subscribe(
        response => {
          let tmpResponse: any = response;
          console.log(response);
          this.end = false;
          this.start = false;
          this.startRideFlag = false;
          this.msg = tmpResponse.message;
          this.startRideFlag = false;
          this.rideEndFunction(tmpResponse, formdata, request_info);
        },
        error => {
          return false;
        });


  };
  rideEndFunction(response: any, formdata: any, booking_info: any) {

    this.cash = false;
    if (booking_info.requested_payment_mode_id == "1") {
      this.cash = true;
    }
    if (booking_info.requested_payment_mode_id != "1") {
      this.cash = false;
    }


    this.modalRef = this.modalService.show(this.templateConfirmPAyment);
    if (response.pay_status == 1) {
    }
  };
  setPaymentConfirmation(booking_id: String, pay_status, request_info: any) {
    this.msg = "";
    this.http.post(this.BASE_URL + 'api/drivers/booking/confirmRidePayment',
      { booking_id: booking_id, complete_status: 1, pay_status: pay_status, transaction_amount: request_info.total_amount },
      {
        headers: this.headers
      }).subscribe(
        response => {
          console.log(response);
          let tmpResponse: any = response;
          this.msg = tmpResponse.message;
          this.msg = "Paid, looking for new ride.Thank you.";
          setTimeout(function () {


            this.modalRef.hide();


          }, 2000);
          window.location.reload();



        }, error => {
          return false;
        });
  };
  getCurrentOngoingRide() {

    this.http.get(this.BASE_URL + 'api/drivers/booking/recentRide', {
      headers: this.headers
    }).subscribe(
      response => {
        console.log(response);
        let tmpResponse: any = response;
        let booking_details: any = tmpResponse.data;
        this.booking_id = booking_details.booking_id;
        this.request_info = booking_details;
        var booking_status = booking_details.booking_status;
        this.bookedRideStatus = booking_details.booking_status;
        if (booking_status == '0' || booking_status == 0) {
          this.modalRef = this.modalService.show(this.templateRideStartEnd);
          this.request_status = false;
          this.request_info = {};
          this.msg = "Ride is cancelled.";
          this.start = false;
          this.end = false;
          this.cancelled = true;
        }
        if (booking_status == '1' || booking_status == 1) {
          this.booking_id = booking_details.booking_id;
          this.modalRef = this.modalService.show(this.templateRideStartEnd);
          this.end = true;
          this.start = false;
          this.startRideFlag = true;
          this.msg = tmpResponse.message;
        }

        if (booking_status == '2' || booking_status == 2) {
          this.modalRef.hide();
          if (booking_details.pay_status == '0') {
            this.request_info = booking_details;

            this.booking_id = booking_details.booking_id;
            this.cash = true;
            this.modalRef = this.modalService.show(this.templateConfirmPAyment);

          }
          else {

          }

          return false;
          //completed ride
        }

        if (booking_status == '4' || booking_status == 4) {
          this.modalRef = this.modalService.show(this.templateRideStartEnd);
          this.end = false;
          this.start = true;
          this.startRideFlag = true;
          this.msg = tmpResponse.message;
          //accepted ride
        }

        if (booking_status == '5' || booking_status == 5) {
          this.modalRef = this.modalService.show(this.templateRideStartEnd);

          this.request_status = false;
          this.request_info = {};
          this.cancelled = true;
          //rejected ride
        }
        this.requestStatusConfig(booking_status, booking_details, tmpResponse);
      },
      error => {
        console.log(error);
        console.log(error.error.error);
        if ( error.error.error == "Token Expired") {
          this.router.navigate(['logout']);
          // this.logout();
        }

        if (!error.error.status && error.error.error.message == "Token Expired") {

        }
        return false;

      });
  };
  requestStatusConfig(booking_status, booking_details: any, tmpResponse: any) {

    if (booking_status == '0' || booking_status == 0) {

      if (this.bookedRideStatus != booking_status) {
        this.modalRef = this.modalService.show(this.templateRideStartEnd);
      }


      this.request_status = false;
      this.request_info = {};
      this.msg = "Ride is cancelled.";

      this.start = false;
      this.end = false;
      this.cancelled = true;
    }
    if (booking_status == '1' || booking_status == 1) {
      this.booking_id = booking_details.booking_id;
      this.modalRef = this.modalService.show(this.templateRideStartEnd);

      this.end = true;
      this.start = false;
      this.startRideFlag = true;
      this.msg = tmpResponse.message;
    }

    if (booking_status == '2' || booking_status == 2) {
      if (booking_details.pay_status == '0') {
        this.request_info = booking_details;

        this.booking_id = booking_details.booking_id;
        this.cash = true;

        this.modalRef = this.modalService.show(this.templateConfirmPAyment);

      }
      else {

      }

      return false;
      //completed ride
    }

    if (booking_status == '4' || booking_status == 4) {
      this.modalRef = this.modalService.show(this.templateRideStartEnd);
      this.end = false;
      this.start = true;
      this.startRideFlag = true;
      this.msg = tmpResponse.message;
      //accepted ride
    }

    if (booking_status == '5' || booking_status == 5) {
      this.modalRef = this.modalService.show(this.templateRideStartEnd);

      this.request_status = false;
      this.request_info = {};
      this.msg = "Ride is cancelled.";
      this.start = false;
      this.end = false;
      this.cancelled = true;
      //rejected ride
    }
  }
  public ngAfterViewInit() {

    this.pixelRatio = window.devicePixelRatio || 1;
    this.defaultLayers = this.platform.createDefaultLayers();

    this.map = new H.Map(this.mapElement.nativeElement,
      this.defaultLayers.normal.map, { pixelRatio: this.pixelRatio });

    var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(this.map));
    var ui = H.ui.UI.createDefault(this.map, this.defaultLayers);

    this.map.setCenter({ lat: this.general_location.start_latlng.lat, lng: this.general_location.start_latlng.lng });
    this.map.setZoom(14);

    var marker = new H.map.Marker({ lat: this.general_location.start_latlng.lat, lng: this.general_location.start_latlng.lng });
    // add custom data to the marker

    this.map.addObject(marker);


  }
  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "driver home" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));

          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }

          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getBookingPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "driver-booking" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;

          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
          //console.log(LOCALSTORAGE);
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.pageDataBooking = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageDataBooking = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageDataBooking = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageDataBooking = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageDataBooking = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageDataBooking = this.config.data.content_es;
          }


        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  getPageDataRevenue() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "company-driver-management" }
    )
      .subscribe(
        responseData => {

          this.config = responseData;

          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));

          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.pageDataRevenue = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageDataRevenue = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageDataRevenue = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageDataRevenue = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageDataRevenue = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageDataRevenue = this.config.data.content_es;
          }

          this.global.setPageData(this.pageDataRevenue);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }


  getPageDataSubscription() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "user-subscription" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;

          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));

          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;

          if (this.global.country == 'en') {
            this.pageDataSubscription = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageDataSubscription = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageDataSubscription = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageDataSubscription = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageDataSubscription = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageDataSubscription = this.config.data.content_es;
          }
          this.global.setPageData(this.pageDataSubscription);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }



  HgetAutocompleteAddressSugestion(searchKeyWord: any, type: any) {

    if (type == "start") {
      this.startLocationListHide = false;
      this.endLocationListHide = true;
    }
    if (type == "end") {
      this.endLocationListHide = false;
      this.startLocationListHide = true;
    }
    var http_url = "  https://autocomplete.geocoder.api.here.com/6.2/suggest.json?query=" + searchKeyWord + "&app_id=" + this.global.HAppId + "&app_code=" + this.global.HAppCode + "";
    this.http.get(http_url).subscribe(
      function successCallback(response) {

        var tmpResponse: any = response;

        this.addressListObjects = tmpResponse.suggestions;

      },
      error => {

      }
    );

  };

  fillTextbox = function (address, type) {
    if (type == "start") {
      this.general_location.start_location = address;
      this.startLocationListHide = true;
    }
    if (type == "end") {
      this.general_location.end_location = address;
      this.endLocationListHide = true;
    }

    var http_url = "https://geocoder.api.here.com/6.2/geocode.json?app_id=" + this.global.HAppId + "&app_code=" + this.global.HAppCode + "&searchtext=" + address;

    this.http.get(http_url).subscribe(
      function successCallback(response) {


        var location = response.data.Response.View[0].Result[0].Location.DisplayPosition;
        if (type == "start") {
          this.general_location.start_latlong.lat = location.Latitude;
          this.general_location.start_latlong.lng = location.Longitude;
        }
        if (type == "end") {
          this.general_location.end_latlong.lat = location.Latitude;
          this.general_location.end_latlong.lng = location.Longitude;


        }
        this.Hmapfunction(type);
        this.getDriverOnLocation(this.general_location.end_latlong.lat, this.general_location.end_latlong.lng);


      },
      error => {

      }
    );



  };

  addMarkerToGroup = function (group: any, coordinate: any, html: any) {
    var svgMarkup = '<svg width="24" height="24" ' +
      'xmlns="http://www.w3.org/2000/svg">' +
      '<rect stroke="white" fill="#1b468d" x="1" y="1" width="22" ' +
      'height="22" /><text x="12" y="18" font-size="12pt" ' +
      'font-family="Arial" font-weight="bold" text-anchor="middle" ' +
      'fill="white">D</text></svg>';
    var icon = new H.map.Icon(svgMarkup);
    var marker = new H.map.Marker(coordinate, { icon: icon });
    // add custom data to the marker
    marker.setData(html);
    group.addObject(marker);
  };

  addInfoBubble(user_detail: any, except_driver: any) {

    var group = new H.map.Group();
    this.map.addObject(group);
    group.addEventListener('tap', function (evt) {
      var bubble = new H.ui.InfoBubble(evt.target.getGeometry(), {
        // read custom data
        content: evt.target.getData()
      });
      this.ui.addBubble(bubble);
    }, false);
    if (user_detail) {
      for (var i = 0; i < user_detail.length; i++) {
        var driver = user_detail[i];
        if (driver.user_id != except_driver) {
          var strInforWindow = ' <div  class="form-group" id="strInforWindow_div"><label style="color:#000;"> Metro Taxi Driver</label>' +
            '<div style="clear:both"></div></div>';
          this.addMarkerToGroup(group, { lat: driver.latitude, lng: driver.longitude }, strInforWindow);
        }

      }
    }
  };


  getDriverOnLocation(lat: any, lng: any) {

    var formdata = {
      latitude: lat,
      longitude: lng,
      radius: 5,
      unit_type: this.distance_unit,
    };
    var api_method = 'getDriversByLocation';
    this.http.post(this.BASE_URL + 'api/users/service/' + api_method,
      formdata, {
      headers: this.headers
    }).
      subscribe(
        resposne => {
          var tmpResponse: any = resposne;
          this.driverList = tmpResponse.data;

          if (this.driverList) {
            this.addInfoBubble(this.driverList, tmpResponse.user_id);
          }

          return false;

        },
        error => {

          return false;
        });

  };

  createheremap(maplat, maplang, user_detail) {
    this.map.setCenter({ lat: maplat, lng: maplang });
    this.map.setZoom(14);
    this.map.removeObjects(this.map.getObjects());
  };

  updateUserLocation = function (value: any) {
    var formdata = { tmp_country: value };

    this.http.post(this.BASE_URL + 'api/driver/editLocation', formdata, {
      headers: this.headers
    }).subscribe(
      response => {
        return false;

      }, error => {

        return false;
      });

  };

  getPosition(): Promise<any> {
    return new Promise((resolve, reject) => {
      var geolocation = require('geolocation');


      geolocation.getCurrentPosition(function (err, position) {
        if (err) throw err

        let lat = position.coords.latitude;
        let lng = position.coords.longitude;
        resolve(position);


      })
    });

  };

  getAddressFromCoordinates(lat: string, lng: string, state: string) {

    var http_rest_api_url = "https://reverse.geocoder.api.here.com/6.2/reversegeocode.json?prox=" + lat + "," + lng + "&mode=retrieveAddresses&maxresults=1&app_id=" + this.global.HAppId + "&app_code=" + this.global.HAppCode;
    this.http.get(http_rest_api_url).
      subscribe(
        response => {
          var tmpResponse: any;
          tmpResponse = response;

          tmpResponse = tmpResponse.Response.View[0].Result[0].Location.Address.Label;
          var address = tmpResponse;
          if (state == 'start') {
            this.general_location.start_latlng.lat = lat;
            this.general_location.start_latlng.lng = lng;

            this.general_location.start_location = address;
          }
          return address;
        },
        error => {

        }
      );
  };


  home_page_ride() {
    this.http.get(this.BASE_URL + 'api/drivers/service/getTripStats',
      { headers: this.headers }
    ).
      subscribe(
        response => {

          let tmpResponse: any = response;
          this.distance = tmpResponse.data[0];
          this.revenue = tmpResponse.data[1];
          this.booking = tmpResponse.data[2];

          return false;

        }, function errorCallback(response) {
          return false;
        });

  };


  //======  RIDE REQEST==============================///

  getIntervalFunction() {
    interval(5000).subscribe(x => {
      if (!this.request_status) {
        this.getRideRequest();
      }

      if (this.booking_id) {
        this.getRideRequestStatus(this.booking_id);
        this.getChatInfo();

      }
      this.getPosition().then(pos => {
        this.driverLocationSave(pos.coords.latitude, pos.coords.longitude);
      });

    });


  }

  driverLocationSave(lat: string, long: string) {
    var formdata = { 'latitude': lat, 'longitude': long };
    this.http.post(this.BASE_URL + 'api/drivers/account/location', formdata, {
      headers: this.headers
    }).subscribe(
      response => {
      },
      error => {
        return false;
      });
  };

  getRideRequestStatus(booking_id: string) {
    if (!booking_id) {
      return false;
    }
    this.http.get(this.BASE_URL + 'api/drivers/booking/requestStatus/' + this.booking_id, {
      headers: this.headers
    }).subscribe(
      response => {

        let tmpResponse: any = response;
        let booking_details: any = tmpResponse.dataList;
        this.booking_id = booking_details.booking_id;
        this.request_info = booking_details;
        var booking_status = booking_details.booking_status;
        if (booking_status == '0' || booking_status == 0) {
          this.request_status = false;
          this.request_info = {};
          this.msg = "Ride is cancelled.";
          this.start = false;
          this.end = false;
          this.cancelled = true;
          if (this.modalRef) {
            this.modalRef.hide();
          }
          this.chatSessionId = "";
          this.modalRef = this.modalService.show(this.templateRideStartEnd);


        }
        if (booking_status == '1' || booking_status == 1) {
          this.booking_id = booking_details.booking_id;
          if (!this.modalRef) {
            this.modalRef = this.modalService.show(this.templateRideStartEnd);
          }
          this.end = true;
          this.start = false;
          this.startRideFlag = true;
          this.msg = tmpResponse.message;
          this.chatSessionId = booking_details.chat_session_id;
        }

        if (booking_status == '2' || booking_status == 2) {
          if (booking_details.pay_status == '0') {
            this.request_info = booking_details;
            this.chatSessionId = "";
            this.booking_id = booking_details.booking_id;
            this.cash = true;
            if (!this.modalRef) {
              this.modalRef = this.modalService.show(this.templateConfirmPAyment);
            }
          }
          else {
          }

          return false;
          //completed ride
        }

        if (booking_status == '4' || booking_status == 4) {

          if (!this.modalRef) {
            this.modalRef = this.modalService.show(this.templateRideStartEnd);
          }

          this.end = false;
          this.start = true;
          this.startRideFlag = true;
          this.msg = tmpResponse.message;
          this.chatSessionId = booking_details.chat_session_id;
          //accepted ride
        }

        if (booking_status == '5' || booking_status == 5) {

          this.request_status = false;
          this.request_info = {};
          this.msg = "Ride is cancelled.";
          this.start = false;
          this.end = false;
          this.cancelled = true;
          if (!this.modalRef) {
            this.modalRef = this.modalService.show(this.templateRideStartEnd);
          }
          this.chatSessionId = "";
          //rejected ride
        }

      }, error => {
        return false;
      });
  };

  onEnter(value: string) {
    this.chatText = "";
    this.value = value;
    this.appenMessage(this.value);
  }

  getRideRequest() {
    this.http.get(this.BASE_URL + 'api/drivers/booking/request', {
      headers: this.headers
    }).subscribe(
      response => {
        let tmpResponse: any = response;
        if (tmpResponse.data.length != 0) {
          this.request_info = tmpResponse.data;
          this.request_status = true;
          this.modalRef = this.modalService.show(this.templateRideConfirmReject);
          this.booking_id = this.request_info.booking_id;

        }

      }, eror => {
        return false;
      });
  };

  appenMessage (text:string) {
    //console.log(this.chatText);
    this.http.post(this.BASE_URL + 'api/drivers/booking/saveChat', {text: text, chatSessionId:this.chatSessionId}, 
    {headers: this.headers
}).subscribe(
  response=> {
}, error=> {
  this.message = error.error.error;
});
this.chatText = "";

};

getChatTextByUser  (chatSessionId:string, chatCountId:string)
{
    if (!this.ChatId)
    {
        this.ChatId = '0';
    }
    var formdata = {
        // user: user,
        chat_session_id: chatSessionId,
        id: this.ChatId
    };
//        console.log(formdata);
    this.http.post(this.BASE_URL + 'api/drivers/booking/chatInfo', formdata, {headers: this.headers
    }).subscribe(
      response=> {
        // console.log("ChatINfo");
        let tmpResponse:any = response;
        if (tmpResponse.success)
        {
         
          
            var user = tmpResponse.data.user_type;
            var yaz = "<div class='o'>" + this.driverMsg;
            var yazi = "<div class='sen'>" + img + this.customerMsg;
            var output = $('.mesaj-gecmisi');
            var sil = "<div class='sil'></div>";


            var img = '<i class="fa fa-user" aria-hidden="true"></i>';
            var driverimg = "<img align='right' src='" + this.BASE_URL + "images/taxi-driver.svg' width='30px'>";

            if (user == 'driver')
            {
                this.ChatId = tmpResponse.data.id;
                this.driverMsg = tmpResponse.data.chat_text;

                var yaz = "<div class='o'>" + this.driverMsg;
                var yazi = "<div class='sen'>" + img + this.customerMsg;
                var output = $('.mesaj-gecmisi');
                var sil = "<div class='sil'></div>";

                $("#sonuc").append("<div class='sen'>");
                $("#sonuc").append("</div>");

                $("#sonuc").append(yaz + driverimg + sil);
                $("#sonuc").append("</div>");
            }
            if (user == 'customer')
            {
                this.ChatId = tmpResponse.data.id;
                this.customerMsg = tmpResponse.data.chat_text;


                var yaz = "<div class='o'>" + this.driverMsg;
                var yazi = "<div class='sen'>" + img + this.customerMsg;
                var output = $('.mesaj-gecmisi');
                var sil = "<div class='sil'></div>";


                $("#sonuc").append("<div class='sen'>");
                $("#sonuc").append("</div>");
                $("#sonuc").append(yazi + sil);
                //$("#sonuc").append(yazi + sil);
                $("#sonuc").append("</div>");

            }

            output.scrollTop(
                    output[0].scrollHeight - output.height()
                    );

        }
        else
        {
            this.driverMsg = "";
            this.customerMsg = "";
//                console.log("================   NOT  Found Customers " + user + " tesxt");
        }


    }, error=> {
        this.message = error.error.error;
    });
};
//this.customerChatCountId= 0;
getChatInfo  () {
    if (!this.chatSessionId)
    {

        this.ChatId = "";
        return false;

    }
    this.getChatTextByUser(this.chatSessionId, this.ChatId);

};





}
