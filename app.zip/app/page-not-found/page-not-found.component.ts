import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
//import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SwUpdate } from '@angular/service-worker';
import { map, catchError } from 'rxjs/operators';
import { Subject, throwError } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.css']
})
export class PageNotFoundComponent implements OnInit {

  cookieValue = 'UNKNOWN';

  public country: string;
  public langImg: string;

  public is_none: boolean = false;
  public is_driver: boolean = false;
  public is_user: boolean = false;

  public config: any;
  public pageData = { About: "About", Bookings: "Bookings", Home: "Home", Profile: "Profile", Revenue: "Revenue", Subscription: "Subscription", change_password: "Change Password", contact_us: "Contact Us", create_new_ac: "Create New Account", driver_mgmt: "Driver's Management", email_address: "Email Address", forget_pass_btn: "Forget Password", i_am_not_robot: "I am not a Robot", login: "Login", login_btn: "Login", logout: "Logout", my_vehicles: "My Vehicles", password: "Password", payment_method: "Payment Method", privacy_policy: "Privacy Policy", register_btn: "Register With Us", rides: "Rides", service: "Service", vehicle_mgmt: "Vehicle's Management" };
  public countryList: any=[];
  public countryData: any;
  public user_type: string = '';

  error = new Subject<string>();
  constructor(public global: Globals, private http: HttpClient, private cookieService: CookieService, private router: Router) {

   
    if (this.cookieService.get("language_code")) {
      let country: any = JSON.parse(this.cookieService.get("language_code"));
    

      this.global.setLang(country.language, country.flag_image);//sets language & flag to the global
    
      this.langImg = country.flag_image;
    }
    else {
    
      this.global.setLang('en', 'uk.png');//sets language & flag to the global 
      this.langImg = 'uk.png';

    }
    this.getHeader();
  }


  ngOnInit() {
    this.getHeader();
  }

  getHeader() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "header" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
         
          console.log(LOCALSTORAGE);
          if(LOCALSTORAGE.user_info)
          {
            console.log("Loged in");
            this.router.navigate(['/'+JSON.parse(localStorage.getItem('user')).user_info]).then(() => {
              window.location.reload();
             });
          }
          else
          {
            console.log("Not Yettt Balt");
          }
        },
        error => {
          console.log(error);
          console.log("Hello Headers error");
          console.log(error);
          console.log(error.name);
          console.log(error.statusText);
          console.log(error.status);
          if(error.name=='HttpErrorResponse' && error.statusText=='Unknown Error')
          {
            this.router.navigate(['page-not-found']);
            //this.router.navigate(['page-not-found', ''])
          }
          this.error.next(error.message);
        }
      );
  }

}
