import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationControlcenterComponent } from './registration-controlcenter.component';

describe('RegistrationControlcenterComponent', () => {
  let component: RegistrationControlcenterComponent;
  let fixture: ComponentFixture<RegistrationControlcenterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationControlcenterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationControlcenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
