import { Component, OnInit } from '@angular/core';
import { Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { Globals } from '../global';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {

  public email: string = ""
  public errMessage: string = "";
  public forgetPasswordPageMessage: string = '';
  public pageData = { 'mail_text': 'Enter Your Mail ID', 'type_here': 'Type here', 'proceed': 'Proceed' };
  public TOKEN: string = "";
  public isEmail: boolean = true;
  error = new Subject<string>();
  public config: any;
  public BaseUrl: string;
  public BASE_URL: string;
  public base_url: string;
  public headers: any;

  constructor(public global: Globals, private http: HttpClient,
    private cookieService: CookieService,
    private router: Router) {
    // this.TOKEN = JSON.parse(localStorage.getItem('user')).token;

    this.BaseUrl = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
    this.headers = new HttpHeaders({
      //  "token": this.TOKEN,
      "Content-Type": "application/json"
    });

    this.base_url = this.global.APIURL;
    this.BASE_URL = this.global.APIURL;
  }

  ngOnInit() {
    this.getPageData();
  }
  getPageData() {

    this.http.post(
      this.global.APIURL + 'api/general/getPageScreen',
      { id: false, screen: "Forget Password" }
    )
      .subscribe(
        responseData => {
          this.config = responseData;
          console.log(responseData);
          console.log("Local Storage");
          //console.log(JSON.parse(localStorage.getItem('user')));
          var LOCALSTORAGE = JSON.parse(localStorage.getItem('user'));
          //console.log(LOCALSTORAGE);
          this.global.country = JSON.parse(this.cookieService.get("language_code")).language;
          console.log(this.global.country);

          if (this.global.country == 'en') {
            this.pageData = this.config.data.content_en;
          }
          else if (this.global.country == 'cn') {
            this.pageData = this.config.data.content_cn;
          }
          else if (this.global.country == 'de') {
            this.pageData = this.config.data.content_de;
          }
          else if (this.global.country == 'fr') {
            this.pageData = this.config.data.content_fr;
          }
          else if (this.global.country == 'hi') {
            this.pageData = this.config.data.content_hi;
          }
          else if (this.global.country == 'es') {
            this.pageData = this.config.data.content_es;
          }
         console.log(this.pageData);
          this.global.setPageData(this.pageData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  submit() {
    console.log(this.email);
  }



  ValidateEmail = function (inputText: string) {
    this.isEmail = true;
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (!inputText.match(mailformat)) {
      this.isEmail = false;
    }
    return this.isEmail;
  };

  forgetPassword = function (email: string, user_type: string) {

    //        console.log(email);
    this.errMessage = "";
    this.http.post(this.BASE_URL + "api/" + user_type + "/auth/forget_password",
      { email: email }).
      subscribe(
        response => {
          let tmpResponse: any = response;
          this.forgetPasswordPageMessage = tmpResponse.message;
          if (tmpResponse.status == "success") {

          }
          console.log(this.forgetPasswordPageMessage);
        },
        error => {

          console.log(error.error.message);
          this.errMessage = error.error.message;
          return false;
        });
  };
  check_email = function () {
    this.errMessage = "";
    this.forgetPasswordPageMessage = "";
    this.ValidateEmail(this.email);

    if (!this.isEmail) {
      this.errMessage = "Please enter a valid email ID";
      return false;
    }

    var user_type = "user";
    // console.log(this.email);
    this.http.post(this.BASE_URL + "api/auth/checkUser", { email: this.email })
      .subscribe(
        response => {
          //console.log(response.data.data);
          let tmpResponse: any = response;
          if (tmpResponse.data) {
            user_type = response.data;
            this.forgetPassword(this.email, user_type);
          }
          else {
            this.errMessage = "Email ID does not exist."
          }
        },
        error => {
          console.log("");
          console.log(error);
          this.errMessage = "Something Went wrong";
          return false;
        });
  };

}
