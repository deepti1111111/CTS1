import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component'; 
import { AboutComponent } from './about/about.component'; 
import { ContactUsComponent } from './contact-us/contact-us.component'; 
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component'; 
import { ServiceComponent } from './service/service.component'; 
import { RegistrationComponent } from './registration/registration.component'; 
import { LoginComponent } from './login/login.component'; 
import { RegistrationControlcenterComponent } from './registration-controlcenter/registration-controlcenter.component'; 
import { RegistrationCustomerMembershipComponent } from './registration-customer-membership/registration-customer-membership.component'; 
import { RegistrationLincensedrivercompanyComponent } from './registration-lincensedrivercompany/registration-lincensedrivercompany.component'; 
import { RegistrationSelfemployeedriverComponent } from './registration-selfemployeedriver/registration-selfemployeedriver.component'; 
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { LogoutComponent } from './logout/logout.component';
import { UserComponent } from './user/user.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { UserSubscriptionComponent } from './user-subscription/user-subscription.component';
import { BookingsComponent } from './bookings/bookings.component';
import { UserBookingsComponent } from './user-bookings/user-bookings.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { UserPaymentPageComponent } from './user-payment-page/user-payment-page.component';
import { DriverBookingsComponent } from './driver-bookings/driver-bookings.component';
import { DriverPaymentPageComponent } from './driver-payment-page/driver-payment-page.component';
import { DriverProfileComponent } from './driver-profile/driver-profile.component';
import { DriverSubscriptionComponent } from './driver-subscription/driver-subscription.component';
import { DriverComponent } from './driver/driver.component';
import { RevenueComponent } from './revenue/revenue.component';
import { VehiclesComponent } from './vehicles/vehicles.component';
import { PaymentPageComponent } from './payment-page/payment-page.component'
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AddVehicleComponent } from './add-vehicle/add-vehicle.component';
import { CompanyComponent } from './company/company.component';
import { CompanyProfileComponent } from './company-profile/company-profile.component';
import { CompanySubscriptionComponent } from './company-subscription/company-subscription.component';
import { CompanyDriverManagementComponent } from './company-driver-management/company-driver-management.component';
import { CompanyVehicleManagementComponent } from './company-vehicle-management/company-vehicle-management.component';
import { CompanyRideComponent } from './company-ride/company-ride.component';
import { CompanyDriverComponent } from './company-driver/company-driver.component';
import { CompanyViewDriverComponent } from './company-view-driver/company-view-driver.component';
import { AdvertisementComponent } from './advertisement/advertisement.component';


const routes: Routes = [
  { path: '', component: HomeComponent },              
  { path: 'about', component: AboutComponent },           
  { path: 'service', component: ServiceComponent },           
  { path: 'contact-us', component: ContactUsComponent },          
  { path: 'privacy-policy', component: PrivacyPolicyComponent },    
  { path: 'registration', component: RegistrationComponent },    
  { path: 'registration/control-center', component: RegistrationControlcenterComponent },    
  { path: 'registration/customer-membership', component: RegistrationCustomerMembershipComponent },    
  { path: 'registration/lincensed-driver-company', component: RegistrationLincensedrivercompanyComponent },    
  { path: 'registration/self-employed-driver', component: RegistrationSelfemployeedriverComponent },    
  { path: 'login', component: LoginComponent }, 
 
  { path: 'user', component: UserComponent },   
  { path: 'user-profile', component: UserProfileComponent },   
  { path: 'user-subscription', component: UserSubscriptionComponent },   
  { path: 'user-bookings', component: UserBookingsComponent },   
  { path: 'change-password', component: ChangePasswordComponent },   
  { path: 'driver', component: DriverComponent },  
  { path: 'logout', component: LogoutComponent },  
  {path: 'edit-profile',component: EditProfileComponent},
  {path:'user-payment-page/:data',component:UserPaymentPageComponent},
  {path:'forget-password',component:ForgetPasswordComponent},
    {path:'driver-bookings',component:DriverBookingsComponent},
  {path:'driver-subscription',component:DriverSubscriptionComponent},
  {path:'driver-payment-page/:data',component:DriverPaymentPageComponent},
  {path:'driver-profile',component:DriverProfileComponent},
  {path:'revenue',component:RevenueComponent},
  {path:'vehicles',component:VehiclesComponent},
  {path:'payment-page/:info',component:PaymentPageComponent},
  {path: 'page-not-found', component: PageNotFoundComponent},
  {path: 'add-vehicle', component: AddVehicleComponent},
  {path: 'company', component: CompanyComponent},
  {path: 'company-profile', component: CompanyProfileComponent},
  {path: 'company-subscription', component: CompanySubscriptionComponent},
  {path: 'company-driver-management', component: CompanyDriverManagementComponent},
  {path: 'company-vehicle-management', component: CompanyVehicleManagementComponent},
  {path: 'company-ride', component: CompanyRideComponent},
  {path: 'company-driver/:user_id', component: CompanyDriverComponent},
  {path: 'company-view-driver/:user_id', component: CompanyViewDriverComponent},
  {path: 'advertisement', component: AdvertisementComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
