import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userdemo',
  templateUrl: './userdemo.component.html',
  styleUrls: ['./userdemo.component.css']
})
export class UserdemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
