import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationLincensedrivercompanyComponent } from './registration-lincensedrivercompany.component';

describe('RegistrationLincensedrivercompanyComponent', () => {
  let component: RegistrationLincensedrivercompanyComponent;
  let fixture: ComponentFixture<RegistrationLincensedrivercompanyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationLincensedrivercompanyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationLincensedrivercompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
