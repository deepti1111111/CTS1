import { Component, OnInit } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Globals } from '../global';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { NavComponent } from '../nav/nav.component';


@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(public global: Globals,private http: HttpClient,private router: Router)  { }

  ngOnInit() {

    
           
   this.global.setUserData("");    
    localStorage.removeItem('user' );
    this.router.navigate(['/']).then(() => {
      window.location.reload();
     });
    //this.router.navigate(['/']);

  }

}
