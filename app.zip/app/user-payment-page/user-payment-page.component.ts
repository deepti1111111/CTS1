import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Globals } from '../global';
import { NavComponent } from '../nav/nav.component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';


@Component({
  selector: 'app-user-payment-page',
  templateUrl: './user-payment-page.component.html',
  styleUrls: ['./user-payment-page.component.css']
})
export class UserPaymentPageComponent implements OnInit {

  constructor(public global: Globals, private http: HttpClient, private cookieService: CookieService, private router: Router) { 
    console.log(router);
  }

  ngOnInit() {
    
  }

}
