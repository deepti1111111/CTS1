import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Globals } from './global';
import { RecaptchaModule, RecaptchaFormsModule } from 'ng-recaptcha';
import { RouterModule } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ServiceComponent } from './service/service.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { RegistrationComponent } from './registration/registration.component';
import { RegistrationCustomerMembershipComponent } from './registration-customer-membership/registration-customer-membership.component';
import { RegistrationSelfemployeedriverComponent } from './registration-selfemployeedriver/registration-selfemployeedriver.component';
import { RegistrationLincensedrivercompanyComponent } from './registration-lincensedrivercompany/registration-lincensedrivercompany.component';
import { RegistrationControlcenterComponent } from './registration-controlcenter/registration-controlcenter.component';
import { LoginComponent } from './login/login.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { NavComponent } from './nav/nav.component';
import { UserComponent } from './user/user.component';
import { UserdemoComponent } from './userdemo/userdemo.component';
import { DriverComponent } from './driver/driver.component';
import { LogoutComponent } from './logout/logout.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { UserSubscriptionComponent } from './user-subscription/user-subscription.component';
import { BookingsComponent } from './bookings/bookings.component';
import { UserBookingsComponent } from './user-bookings/user-bookings.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { UserPaymentPageComponent } from './user-payment-page/user-payment-page.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { DriverBookingsComponent } from './driver-bookings/driver-bookings.component';
import { DriverPaymentPageComponent } from './driver-payment-page/driver-payment-page.component';
import { DriverProfileComponent } from './driver-profile/driver-profile.component';
import { DriverSubscriptionComponent } from './driver-subscription/driver-subscription.component';
import { RevenueComponent } from './revenue/revenue.component';
import { VehiclesComponent } from './vehicles/vehicles.component';
import { ChartModule } from 'angular-highcharts';
import { Module as StripeModule } from "stripe-angular";
import { PaymentPageComponent } from './payment-page/payment-page.component'
import { NotifierModule, NotifierOptions } from 'angular-notifier';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import {WebcamModule} from 'ngx-webcam';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import {ModalModule} from 'ngx-bootstrap/modal';

import {RatingModule} from "ngx-rating";
import { AddVehicleComponent } from './add-vehicle/add-vehicle.component';
import { CompanyComponent } from './company/company.component';
import { CompanyProfileComponent } from './company-profile/company-profile.component';
import { CompanySubscriptionComponent } from './company-subscription/company-subscription.component';
import { CompanyDriverManagementComponent } from './company-driver-management/company-driver-management.component';
import { CompanyVehicleManagementComponent } from './company-vehicle-management/company-vehicle-management.component';
import { CompanyRideComponent } from './company-ride/company-ride.component';

import { DataTablesModule } from 'angular-datatables';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { CompanyDriverComponent } from './company-driver/company-driver.component';
import { CompanyViewDriverComponent } from './company-view-driver/company-view-driver.component';
import { AdvertisementComponent } from './advertisement/advertisement.component';
import {SlideshowModule} from 'ng-simple-slideshow';

import { NgxPaginationModule } from 'ngx-pagination';

/**
 * Custom angular notifier options
 */
const customNotifierOptions: NotifierOptions = {
  position: {
		horizontal: {
			position: 'right',
			distance: 12
		},
		vertical: {
			position: 'top',
			distance: 12,
			gap: 10
		}
	},
  theme: 'material',
  behaviour: {
    autoHide: 5000,
    onClick: 'hide',
    onMouseover: 'pauseAutoHide',
    showDismissButton: true,
    stacking: 4
  },
  animations: {
    enabled: true,
    show: {
      preset: 'slide',
      speed: 300,
      easing: 'ease'
    },
    hide: {
      preset: 'fade',
      speed: 300,
      easing: 'ease',
      offset: 50
    },
    shift: {
      speed: 300,
      easing: 'ease'
    },
    overlap: 150
  }
};


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ServiceComponent,
    ContactUsComponent,
    PrivacyPolicyComponent,
    RegistrationComponent,
    RegistrationCustomerMembershipComponent,
    RegistrationSelfemployeedriverComponent,
    RegistrationLincensedrivercompanyComponent,
    RegistrationControlcenterComponent,
    LoginComponent,
    ForgetPasswordComponent,
    NavComponent,
    UserComponent,
    UserdemoComponent,
    DriverComponent,
    LogoutComponent,
    UserProfileComponent,
    UserSubscriptionComponent,
    BookingsComponent,
    UserBookingsComponent,
    ChangePasswordComponent,
    EditProfileComponent,
    UserPaymentPageComponent,
    DriverBookingsComponent,
    DriverPaymentPageComponent,
    DriverProfileComponent,
    DriverSubscriptionComponent,
    RevenueComponent,
    VehiclesComponent,
    PaymentPageComponent,
    PageNotFoundComponent,
    AddVehicleComponent,
    CompanyComponent,
    CompanyProfileComponent,
    CompanySubscriptionComponent,
    CompanyDriverManagementComponent,
    CompanyVehicleManagementComponent,
    CompanyRideComponent,
    CompanyDriverComponent,
    CompanyViewDriverComponent,
    AdvertisementComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
    RecaptchaModule,
    RecaptchaFormsModule,
    RouterModule,
    ChartModule,
    NgMultiSelectDropDownModule.forRoot(),
    StripeModule.forRoot(),
    NotifierModule.withConfig(customNotifierOptions),
    WebcamModule,
    AutocompleteLibModule,
    ModalModule.forRoot(),
    RatingModule,
    DataTablesModule,
    NgxDaterangepickerMd.forRoot(),
    SlideshowModule,
    NgxPaginationModule
  ],
  providers: [Globals,CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
